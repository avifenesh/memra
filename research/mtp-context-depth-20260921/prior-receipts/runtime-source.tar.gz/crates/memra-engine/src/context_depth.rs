//! Research policy conditioned on the prompt and already committed output.
//!
//! Context names do not prescribe depths. Calibration supplies the same measured
//! cost curves to the frozen-context control and the online policy. No model,
//! sampler, cache, benchmark label, or future token is inspected here.
use std::collections::VecDeque;
use std::io::{self, Write};
use std::sync::Arc;
use std::time::{Duration, Instant};

pub const MAX_K: usize = 7;
const BLOCK: u64 = 8;
const PROBE_INTERVAL: u64 = 128;
const PROBE_ROUNDS: u64 = 4;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SpanKind {
    Prose,
    Code,
    Numeric,
}

impl SpanKind {
    pub const ALL: [Self; 3] = [Self::Prose, Self::Code, Self::Numeric];
    pub fn name(self) -> &'static str {
        match self {
            Self::Prose => "prose",
            Self::Code => "code",
            Self::Numeric => "numeric",
        }
    }
    fn index(self) -> usize {
        self as usize
    }
}

/// Incremental byte classifier. It handles fences split across token boundaries.
/// Short output prefixes use a prompt-derived hint; observed bytes then take over.
#[derive(Clone, Debug)]
pub struct SpanTracker {
    window: VecDeque<u8>,
    fenced: bool,
    ticks: usize,
    hint: SpanKind,
}

impl SpanTracker {
    pub fn new(prompt: &str) -> Self {
        // Use the last user instruction, not the long reference prefix.
        let tail: String = prompt
            .chars()
            .rev()
            .take(1024)
            .collect::<String>()
            .chars()
            .rev()
            .collect();
        let lower = tail
            .rsplit("\n\n")
            .next()
            .unwrap_or(&tail)
            .trim()
            .to_ascii_lowercase();
        let hint = if ["calculate", "compute a table", "tabulate"]
            .iter()
            .any(|s| lower.starts_with(s))
        {
            SpanKind::Numeric
        } else if [
            "write code",
            "write a python",
            "write a rust",
            "implement",
            "return a json",
        ]
        .iter()
        .any(|s| lower.starts_with(s))
        {
            SpanKind::Code
        } else {
            SpanKind::Prose
        };
        Self {
            window: VecDeque::with_capacity(128),
            fenced: false,
            ticks: 0,
            hint,
        }
    }

    pub fn observe(&mut self, bytes: &[u8]) {
        for &b in bytes {
            if b == b'`' {
                self.ticks += 1;
                if self.ticks == 3 {
                    self.fenced = !self.fenced;
                    self.window.clear();
                    self.hint = SpanKind::Prose;
                }
            } else {
                self.ticks = 0;
            }
            if self.window.len() == 128 {
                self.window.pop_front();
            }
            self.window.push_back(b);
        }
    }

    pub fn kind(&self) -> SpanKind {
        let digits = self.window.iter().filter(|b| b.is_ascii_digit()).count();
        let letters = self
            .window
            .iter()
            .filter(|b| b.is_ascii_alphabetic())
            .count();
        let math = self
            .window
            .iter()
            .filter(|&&b| b"+-*/=.,:%".contains(&b))
            .count();
        if digits >= 4 && digits + math > letters {
            return SpanKind::Numeric;
        }
        if self.fenced {
            return SpanKind::Code;
        }
        if self.window.len() < 24 {
            return self.hint;
        }
        SpanKind::Prose
    }
}

#[derive(Clone, Copy, Debug, Default)]
pub struct Estimate {
    pub tokens_per_round: f64,
    pub ns_per_round: f64,
    pub rounds: u64,
}

impl Estimate {
    fn cost(self) -> f64 {
        self.ns_per_round / self.tokens_per_round
    }
}

#[derive(Clone, Debug)]
pub struct Priors {
    pub global_k: usize,
    pub cap: usize,
    pub estimates: [[Estimate; MAX_K]; 3],
}

impl Priors {
    /// Rows: `context k rounds tokens elapsed_ns`, tab separated. A context with
    /// fewer than 32 calibration rounds backs off to the measured global curve.
    pub fn parse(text: &str, cap: usize) -> Result<Self, &'static str> {
        if !(1..=MAX_K).contains(&cap) {
            return Err("invalid context depth cap");
        }
        let mut lines = text.lines();
        let first: Vec<_> = lines
            .next()
            .ok_or("missing prior header")?
            .split('\t')
            .collect();
        if first.len() != 2 || first[0] != "global_k" {
            return Err("invalid prior header");
        }
        let global_k: usize = first[1].parse().map_err(|_| "invalid global K")?;
        if !(1..=cap).contains(&global_k)
            || lines.next() != Some("context\tk\trounds\ttokens\telapsed_ns")
        {
            return Err("invalid prior schema or global K");
        }
        let mut cells = [[None; MAX_K]; 4];
        for line in lines {
            let f: Vec<_> = line.split('\t').collect();
            if f.len() != 5 {
                return Err("invalid prior row");
            }
            let c = match f[0] {
                "all" => 3,
                "prose" => 0,
                "code" => 1,
                "numeric" => 2,
                _ => return Err("unknown prior context"),
            };
            let k: usize = f[1].parse().map_err(|_| "invalid prior K")?;
            let n: u64 = f[2].parse().map_err(|_| "invalid prior count")?;
            let tokens: u64 = f[3].parse().map_err(|_| "invalid prior tokens")?;
            let ns: u64 = f[4].parse().map_err(|_| "invalid prior time")?;
            if !(1..=cap).contains(&k)
                || cells[c][k - 1].is_some()
                || (n == 0 && (tokens != 0 || ns != 0))
                || (n > 0
                    && (tokens < n || tokens as u128 > n as u128 * (k + 1) as u128 || ns == 0))
            {
                return Err("duplicate or inconsistent prior row");
            }
            cells[c][k - 1] = Some(Estimate {
                tokens_per_round: if n == 0 {
                    0.0
                } else {
                    tokens as f64 / n as f64
                },
                ns_per_round: if n == 0 { 0.0 } else { ns as f64 / n as f64 },
                rounds: n,
            });
        }
        let mut estimates = [[Estimate::default(); MAX_K]; 3];
        for k in 0..cap {
            let global = cells[3][k].ok_or("missing global prior")?;
            if global.rounds == 0 {
                return Err("empty global prior");
            }
            for c in 0..3 {
                let local = cells[c][k].ok_or("missing context prior")?;
                estimates[c][k] = if local.rounds >= 32 { local } else { global };
            }
        }
        Ok(Self {
            global_k,
            cap,
            estimates,
        })
    }
}

#[derive(Clone, Copy, Debug, Default)]
struct Accumulator {
    rounds: u64,
    tokens: u64,
    ns: u64,
}

#[derive(Clone, Debug)]
struct State {
    priors: Priors,
    estimates: [[Estimate; MAX_K]; 3],
    observed: [[Accumulator; MAX_K]; 3],
    blocks: [[Accumulator; MAX_K]; 3],
    tracker: SpanTracker,
    seen: usize,
    requests: u64,
    rounds: u64,
    current: usize,
    active: SpanKind,
    online: bool,
    since_probe: [u64; 3],
    probe_direction: [bool; 3],
    probe: Option<(SpanKind, u64)>,
    switches: u64,
}

#[derive(Clone, Debug)]
pub struct ContextEvent {
    pub before: SpanKind,
    pub after: SpanKind,
    pub k: usize,
    pub next_k: usize,
    pub output_start: usize,
    pub output_end: usize,
    pub elapsed_ns: u64,
    pub eligible: bool,
    pub probe: bool,
    pub reason: &'static str,
    pub cpu_ns: u64,
}

#[derive(Debug)]
pub struct ContextDepth {
    state: State,
    token_bytes: Arc<Vec<Vec<u8>>>,
    events: Vec<ContextEvent>,
}

impl Clone for ContextDepth {
    fn clone(&self) -> Self {
        // Receipts stay with the finished request; all learning state is retained.
        Self {
            state: self.state.clone(),
            token_bytes: self.token_bytes.clone(),
            events: Vec::new(),
        }
    }
}

impl ContextDepth {
    pub fn new(priors: Priors, token_bytes: Arc<Vec<Vec<u8>>>, online: bool) -> Self {
        Self {
            state: State {
                estimates: priors.estimates,
                current: priors.global_k,
                priors,
                observed: [[Accumulator::default(); MAX_K]; 3],
                blocks: [[Accumulator::default(); MAX_K]; 3],
                tracker: SpanTracker::new(""),
                seen: 0,
                requests: 0,
                rounds: 0,
                active: SpanKind::Prose,
                online,
                since_probe: [0; 3],
                probe_direction: [false; 3],
                probe: None,
                switches: 0,
            },
            token_bytes,
            events: Vec::new(),
        }
    }

    pub fn depth(&self) -> usize {
        self.state.current + 1
    }
    pub fn switches(&self) -> u64 {
        self.state.switches
    }

    pub fn begin_request(&mut self, prompt: &str) {
        self.state.tracker = SpanTracker::new(prompt);
        self.state.seen = 0;
        self.state.probe = None;
        self.events.clear();
        self.state.active = self.state.tracker.kind();
        // The very first round shares the fixed control's calibrated initial K.
        if self.state.requests > 0 {
            self.select(self.best(self.state.active));
        }
        self.state.requests += 1;
    }

    pub fn prepare_output(&mut self, output: &[u32]) -> Result<(), &'static str> {
        if output.len() < self.state.seen {
            return Err("context observer output went backwards");
        }
        for &id in &output[self.state.seen..] {
            self.state.tracker.observe(
                self.token_bytes
                    .get(id as usize)
                    .ok_or("context token outside vocabulary")?,
            );
        }
        self.state.seen = output.len();
        Ok(())
    }

    fn best(&self, kind: SpanKind) -> usize {
        let row = &self.state.estimates[kind.index()];
        (1..=self.state.priors.cap)
            .min_by(|&a, &b| row[a - 1].cost().total_cmp(&row[b - 1].cost()))
            .unwrap()
    }

    fn select(&mut self, k: usize) {
        self.state.switches += u64::from(k != self.state.current);
        self.state.current = k;
    }

    fn update_block(&mut self, c: usize, k: usize) {
        let b = &mut self.state.blocks[c][k];
        if b.rounds == 0 {
            return;
        }
        let estimate = &mut self.state.estimates[c][k];
        estimate.tokens_per_round =
            0.8 * estimate.tokens_per_round + 0.2 * b.tokens as f64 / b.rounds as f64;
        estimate.ns_per_round = 0.8 * estimate.ns_per_round + 0.2 * b.ns as f64 / b.rounds as f64;
        estimate.rounds += b.rounds;
        *b = Accumulator::default();
    }

    pub fn observe(
        &mut self,
        depth: usize,
        output_start: usize,
        output: &[u32],
        elapsed: Duration,
        eligible: bool,
    ) -> Result<(), &'static str> {
        let cpu = Instant::now();
        if depth != self.depth()
            || output_start != self.state.seen
            || output.len() < output_start
            || elapsed.is_zero()
            || elapsed.as_nanos() > u64::MAX as u128
        {
            return Err("inconsistent context observation");
        }
        let count = output.len() - output_start;
        if eligible && (count == 0 || count > depth) {
            return Err("invalid committed context round");
        }
        let before = self.state.tracker.kind();
        let k = self.state.current;
        let c = before.index();
        let probing = self.state.probe.is_some();
        self.prepare_output(output)?;
        let after = self.state.tracker.kind();
        let ns = elapsed.as_nanos() as u64;
        let mut block_complete = false;
        if eligible {
            self.state.rounds += 1;
            let observed = &mut self.state.observed[c][k - 1];
            observed.rounds += 1;
            observed.tokens += count as u64;
            observed.ns += ns;
            if self.state.online {
                self.state.since_probe[c] += 1;
                let b = &mut self.state.blocks[c][k - 1];
                b.rounds += 1;
                b.tokens += count as u64;
                b.ns += ns;
                block_complete = b.rounds >= BLOCK;
                if block_complete {
                    self.update_block(c, k - 1);
                }
            }
        }
        let mut reason = "hold";
        if eligible {
            if after != self.state.active {
                self.state.probe = None;
                self.select(self.best(after));
                reason = "context";
            } else if !self.state.online {
                self.select(self.best(after));
                reason = "frozen";
            } else if let Some((kind, left)) = self.state.probe {
                if left <= 1 || kind != after {
                    self.update_block(c, k - 1);
                    self.state.probe = None;
                    self.select(self.best(after));
                    reason = "probe_return";
                } else {
                    self.state.probe = Some((kind, left - 1));
                }
            } else if block_complete || self.state.rounds == 1 {
                let best = self.best(after);
                let row = &self.state.estimates[c];
                if row[best - 1].cost() < row[k - 1].cost() * 0.99 {
                    self.select(if best > k { k + 1 } else { k - 1 });
                    reason = "update";
                }
                if reason == "hold" && self.state.since_probe[c] >= PROBE_INTERVAL {
                    let current = self.state.current;
                    let up = self.state.probe_direction[c];
                    self.state.probe_direction[c] = !up;
                    let adjacent = if up && current < self.state.priors.cap {
                        current + 1
                    } else if current > 1 {
                        current - 1
                    } else if current < self.state.priors.cap {
                        current + 1
                    } else {
                        current
                    };
                    let row = &self.state.estimates[c];
                    let degraded = row[current - 1].cost()
                        > self.state.priors.estimates[c][current - 1].cost() * 1.08;
                    let close = row[adjacent - 1].cost() < row[current - 1].cost() * 1.05;
                    if adjacent != current && (degraded || close) {
                        self.select(adjacent);
                        self.state.probe = Some((after, PROBE_ROUNDS));
                        reason = "probe";
                    }
                    self.state.since_probe[c] = 0;
                }
            }
        }
        self.state.active = after;
        self.events.push(ContextEvent {
            before,
            after,
            k,
            next_k: self.state.current,
            output_start,
            output_end: output.len(),
            elapsed_ns: ns,
            eligible,
            probe: probing,
            reason,
            cpu_ns: cpu.elapsed().as_nanos() as u64,
        });
        Ok(())
    }

    pub fn write_events(&self, out: &mut impl Write, turn: usize) -> io::Result<()> {
        for (i, e) in self.events.iter().enumerate() {
            writeln!(
                out,
                "{turn}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}",
                i + 1,
                e.before.name(),
                e.after.name(),
                e.k,
                e.next_k,
                e.output_start,
                e.output_end,
                e.elapsed_ns,
                e.eligible,
                e.probe,
                e.reason,
                e.cpu_ns
            )?;
        }
        Ok(())
    }

    pub fn write_stats(&self, out: &mut impl Write) -> io::Result<()> {
        writeln!(
            out,
            "context\tk\trounds\ttokens\telapsed_ns\testimated_tokens_per_round\testimated_ns_per_round"
        )?;
        for kind in SpanKind::ALL {
            for k in 0..self.state.priors.cap {
                let a = self.state.observed[kind.index()][k];
                let e = self.state.estimates[kind.index()][k];
                writeln!(
                    out,
                    "{}\t{}\t{}\t{}\t{}\t{}\t{}",
                    kind.name(),
                    k + 1,
                    a.rounds,
                    a.tokens,
                    a.ns,
                    e.tokens_per_round,
                    e.ns_per_round
                )?;
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn priors() -> Priors {
        let mut text = "global_k\t2\ncontext\tk\trounds\ttokens\telapsed_ns\n".to_string();
        for c in ["all", "prose", "code", "numeric"] {
            for k in 1..=3 {
                let best = if c == "code" {
                    3
                } else if c == "numeric" {
                    1
                } else {
                    2
                };
                let ns = if k == best { 64000 } else { 128000 };
                text.push_str(&format!("{c}\t{k}\t64\t64\t{ns}\n"));
            }
        }
        Priors::parse(&text, 3).unwrap()
    }

    #[test]
    fn fences_split_across_tokens_and_numeric_spans_change_context() {
        let mut s = SpanTracker::new("Explain this.");
        s.observe(b"`");
        s.observe(b"``python\nx = 1\n");
        assert_eq!(s.kind(), SpanKind::Code);
        s.observe(b"``");
        s.observe(b"`\n");
        s.observe(b"12345 + 67890 = 80235\n");
        assert_eq!(s.kind(), SpanKind::Numeric);
        s.observe(&[b'a'; 128]);
        assert_eq!(s.kind(), SpanKind::Prose);
    }

    #[test]
    fn priors_reject_duplicates_and_unmeasured_global_curves() {
        assert!(
            Priors::parse(
                "global_k\t2\ncontext\tk\trounds\ttokens\telapsed_ns\nall\t1\t0\t0\t0\n",
                2
            )
            .is_err()
        );
        assert!(Priors::parse("global_k\t1\ncontext\tk\trounds\ttokens\telapsed_ns\nall\t1\t1\t1\t1\nall\t1\t1\t1\t1\n", 1).is_err());
    }

    #[test]
    fn numeric_runs_inside_fences_and_negative_instructions_are_not_code_hints() {
        let mut s = SpanTracker::new("Explain in prose, without code blocks or numeric tables.");
        assert_eq!(s.kind(), SpanKind::Prose);
        s.observe(b"```csv\n1,2345,6789\n2,4567,8901\n");
        assert_eq!(s.kind(), SpanKind::Numeric);
    }

    #[test]
    fn starts_at_shared_global_k_then_reuses_a_familiar_context() {
        let mut p = ContextDepth::new(priors(), Arc::new(vec![b"```python\n".to_vec()]), true);
        p.begin_request("Write code in a code block.");
        assert_eq!(p.depth(), 3);
        p.prepare_output(&[]).unwrap();
        p.observe(3, 0, &[0], Duration::from_micros(1), true)
            .unwrap();
        assert_eq!(p.depth(), 4);
        p.begin_request("Explain the mechanism.");
        assert_eq!(p.depth(), 3);
        p.begin_request("Write code in a code block.");
        assert_eq!(p.depth(), 4);
        assert_eq!(p.state.observed[SpanKind::Code.index()][1].rounds, 1);
    }

    #[test]
    fn terminal_rounds_never_update_learning_and_clone_keeps_partial_blocks() {
        let mut p = ContextDepth::new(priors(), Arc::new(vec![b"word ".to_vec()]), true);
        p.begin_request("Explain.");
        p.observe(3, 0, &[0], Duration::from_micros(1), true)
            .unwrap();
        p.observe(p.depth(), 1, &[0, 0], Duration::from_micros(1), false)
            .unwrap();
        assert_eq!(p.state.rounds, 1);
        let mut q = p.clone();
        assert!(q.events.is_empty());
        q.begin_request("Explain again.");
        assert_eq!(q.state.blocks[0][1].rounds, 1);
        assert_eq!(q.state.observed[0][1].rounds, 1);
        assert_eq!(q.state.observed[1][1].rounds, 0);
    }

    #[test]
    fn frozen_context_estimates_do_not_learn_from_online_timings() {
        let mut p = ContextDepth::new(priors(), Arc::new(vec![b"word ".to_vec()]), false);
        let expected = p.state.estimates[0][1].cost();
        p.begin_request("Explain.");
        let mut output = Vec::new();
        for _ in 0..24 {
            let n = output.len();
            output.push(0);
            p.observe(p.depth(), n, &output, Duration::from_secs(1), true)
                .unwrap();
        }
        assert_eq!(p.state.estimates[0][1].cost(), expected);
        assert_eq!(p.depth(), 3);
    }

    #[test]
    fn known_bad_neighbors_do_not_force_an_all_depth_sweep() {
        let mut p = ContextDepth::new(priors(), Arc::new(vec![b"word ".to_vec()]), true);
        p.begin_request("Explain.");
        let mut output = Vec::new();
        for _ in 0..256 {
            let n = output.len();
            output.push(0);
            p.observe(p.depth(), n, &output, Duration::from_micros(1), true)
                .unwrap();
        }
        assert!(p.events.iter().all(|e| e.k == 2 && !e.probe));
    }

    #[test]
    fn online_changes_remain_local_to_the_observed_context() {
        let mut p = ContextDepth::new(priors(), Arc::new(vec![b"word ".to_vec()]), true);
        p.begin_request("Explain.");
        let mut output = Vec::new();
        for _ in 0..8 {
            let n = output.len();
            output.push(0);
            p.observe(p.depth(), n, &output, Duration::from_millis(1), true)
                .unwrap();
        }
        assert_eq!(p.depth(), 2);
        p.begin_request("Write code.");
        assert_eq!(p.depth(), 4);
        p.begin_request("Explain again.");
        assert_eq!(p.depth(), 2);
    }

    #[test]
    fn neighboring_probes_have_a_bounded_round_budget() {
        let mut prior = priors();
        prior.estimates[0][0].ns_per_round = 1040.0;
        let mut p = ContextDepth::new(prior, Arc::new(vec![b"word ".to_vec()]), true);
        p.begin_request("Explain.");
        let mut output = Vec::new();
        for _ in 0..512 {
            let n = output.len();
            output.push(0);
            p.observe(p.depth(), n, &output, Duration::from_micros(1), true)
                .unwrap();
        }
        assert!(p.events.iter().any(|e| e.probe));
        assert!(p.events.iter().filter(|e| e.probe).count() <= 4 * 4);
        assert!(
            p.events
                .iter()
                .filter(|e| e.reason == "probe")
                .all(|e| e.k.abs_diff(e.next_k) == 1)
        );
    }
}
