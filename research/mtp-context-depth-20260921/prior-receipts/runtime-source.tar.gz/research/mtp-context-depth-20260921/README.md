# Context-conditioned MTP depth

This experiment tests whether the useful draft depth changes with generated
content, and whether learning that relationship across a conversation improves
complete-request throughput.

The controller observes the current prompt and committed output. It retains
separate cost estimates for prose, code and numeric spans, with calibration as
the shared starting prior. These are measured contexts, not rules that prescribe
a larger K for code or numbers. A familiar context can immediately reuse its
preferred depth; new information updates that preference within and across
requests.

Controls are native adaptation, a calibrated global fixed K, and a calibrated
context-conditioned policy with its estimates frozen. The online policy uses the
same calibration. Every scored arm uses the same native prompt-checkpoint reuse
contract. The primary metric is total returned output tokens divided by total
native request seconds, including classification, adaptation, suffix processing,
generation and detokenization.

Calibration, development and held-out workload pools are disjoint. Policy choices
are frozen before held-out scoring. Conversations exercise prose, code, numeric
work and transitions within replies. Context decisions never consume benchmark
labels or future output.

Work is in progress. There is no performance verdict or runtime default change.
