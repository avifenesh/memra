"""Qualify, calibrate and compare persistent contextual depth on mixed sessions."""
import argparse
import datetime
import hashlib
import json
import statistics
import subprocess
import sys
from pathlib import Path
from calibrate import freeze

LANE = Path(__file__).resolve().parent
ARMS = ("calibrated", "native", "context", "learned", "measured")


def save(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def schedule():
    rows = [tuple(ARMS[(i + offset) % 5] for i in (0, 1, 4, 2, 3)) for offset in range(5)]
    return rows + [tuple(reversed(row)) for row in rows]


def summarize(groups, planned):
    for g in groups:
        if len(g["records"]) != len(ARMS) or {r["arm"] for r in g["records"]} != set(ARMS):
            raise ValueError("incomplete matched set")
        if any(r["correctness_only"] or r["turns"] != 8 or r["elapsed_s"] <= 0
               or r["tokens"] <= 0 or r["reuse"]["cached_tokens"] <= 0 for r in g["records"]):
            raise ValueError("invalid complete-session measurement")
    pooled = {}
    for arm in ARMS:
        records = [next(r for r in g["records"] if r["arm"] == arm) for g in groups]
        pooled[arm] = sum(r["tokens"] for r in records) / sum(r["elapsed_s"] for r in records)
    comparisons = {}
    for candidate in ("context", "learned"):
        comparisons[candidate] = {}
        for control in (a for a in ARMS if a != candidate):
            values = []
            for g in groups:
                rates = {r["arm"]: r["e2e_tok_s"] for r in g["records"]}
                values.append(100 * (rates[candidate] / rates[control] - 1))
            comparisons[candidate][control] = {
                "pooled_change_percent": 100 * (pooled[candidate] / pooled[control] - 1),
                "paired_percent": values, "wins": sum(v > 0 for v in values),
                "median_pair_percent": statistics.median(values),
            }
    return {"complete_planned_matrix": len(groups) == planned, "sets": len(groups),
            "runs": len(groups) * len(ARMS), "turns": len(groups) * len(ARMS) * 8,
            "pooled_request_e2e_tok_s": pooled, "comparisons": comparisons,
            "metric": "returned output tokens / complete native request seconds"}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ["models", "binaries", "workloads", "out"]:
        p.add_argument("--" + name, required=True, type=Path)
    p.add_argument("--source", required=True)
    p.add_argument("--stop-after-development", action="store_true")
    a = p.parse_args()
    a.out.mkdir(parents=True, exist_ok=False)
    lock_path = a.workloads / "workloads.lock.json"
    lock = json.loads(lock_path.read_text())
    for family in ("qwen", "gemma"):
        for row in lock["families"][family].values():
            if digest(a.workloads / row["file"]) != row["sha256"]:
                raise ValueError("workload changed after preparation")
    save(a.out / "schedule.json", schedule())
    (a.out / "workloads.lock.json").write_bytes(lock_path.read_bytes())
    save(a.out / "source.json", {"source_commit": a.source})

    def status(**fields):
        save(a.out / "status.json", {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), **fields})
        print(json.dumps(fields), flush=True)

    def attempt(family, phase, cycle, order, workload, mapping, priors=None, gate=False, cold=False, tokens=2048):
        name = f"{family}-{phase}-{cycle}"
        root = a.out / name
        spec, depths = root.with_suffix(".schedule.json"), root.with_suffix(".depths.json")
        save(spec, [{"cycle": cycle, "order": order}]); save(depths, mapping)
        offsets = {"basis-short": 100, "cold-short": 100, "basis-long": 200, "cold-long": 200,
                   "calibration": 1000, "context-gate": 200, "development": 3000, "eval": 5000}
        seed = (20270000 if family == "qwen" else 20280000) + offsets[phase]
        model = a.models / family
        cmd = [sys.executable, str(LANE / "run_study.py"), "--family", family,
               "--binary", str(a.binaries / ("mtp-depth-study" if family == "qwen" else "gemma-depth-study")),
               "--target", str(model / "target.gguf"), "--workload", str(a.workloads / f"{family}-{workload}.txt"),
               "--out", str(root), "--lock", "/tmp/memra-gpu.lock", "--max-new", str(tokens),
               "--ctx", "49152", "--seed", str(seed), "--artifact-manifest", str(model / "artifacts.lock.json"),
               "--source-commit", a.source, "--schedule", str(spec), "--fixed-depths", str(depths)]
        if family == "gemma": cmd += ["--draft", str(model / "assistant.gguf")]
        if priors: cmd += ["--priors", str(priors)]
        if gate: cmd += ["--gate"]
        if cold: cmd += ["--cold-reference"]
        status(state="running", family=family, phase=phase, cycle=cycle, receipt_dir=name)
        with root.with_suffix(".driver.log").open("w") as log:
            subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, check=True)
        records = json.loads((root / "runs.json").read_text())
        if [r["arm"] for r in records] != list(order): raise ValueError("arm order changed")
        return {"cycle": cycle, "seed": seed + cycle, "receipt_dir": name, "records": records}

    def compare(cold, warm):
        for turn in range(1, 9):
            for kind in ("prompt", "output"):
                name = f"turn-{turn}.{kind}.ids"
                x = a.out / cold["receipt_dir"] / f'{cold["seed"]}-native' / name
                y = a.out / warm["receipt_dir"] / f'{warm["seed"]}-native' / name
                if x.read_bytes() != y.read_bytes(): raise ValueError("cold/resumed identity failed")

    try:
        selections = {}
        for family, maximum in (("qwen", 7), ("gemma", 5)):
            mapping = {f"k{k}": k for k in range(1, maximum + 1)}
            basis = []
            for shape, workload, count in (("short", "short", 64), ("long", "calibration-a", 2048)):
                cold = attempt(family, "cold-" + shape, 0, ["native"], workload, {}, gate=True, cold=True, tokens=count)
                warm = attempt(family, "basis-" + shape, 0, ["native", "measured", *mapping], workload, mapping, gate=True, tokens=count)
                compare(cold, warm)
                basis.append({"shape": shape, "cold": cold, "warm": warm})
            save(a.out / f"{family}-basis-qualification.json", basis)
            calibration = []
            for i, workload in enumerate(("calibration-a", "calibration-b")):
                order = list(mapping) if i == 0 else list(reversed(mapping))
                calibration.append(attempt(family, "calibration", i, order, workload, mapping))
            winner, priors, selection = freeze(a.out, family, calibration, maximum)
            selection.update(selected_k=winner, priors_sha256=digest(priors), source_commit=a.source,
                             selected_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
            save(a.out / f"{family}-selection.json", selection)
            selections[family] = (winner, priors)
            contextual_gate = attempt(family, "context-gate", 0, ["native", "calibrated", "context", "learned"],
                                      "calibration-a", {"calibrated": winner}, priors=priors, gate=True)
            compare(basis[1]["cold"], contextual_gate)
            save(a.out / f"{family}-context-qualification.json", contextual_gate)
            development = []
            for i, workload in enumerate(("development-a", "development-b")):
                development.append(attempt(family, "development", i, schedule()[i], workload,
                                           {"calibrated": winner}, priors=priors))
            save(a.out / f"{family}-development-sets.json", development)
            report = summarize(development, 2)
            save(a.out / f"{family}-development-report.json", report)
            status(state="development-complete", family=family, selected_k=winner, report=report)
        if a.stop_after_development:
            save(a.out / "DEVELOPMENT-DONE.json", {"families": list(selections)})
            return
        freeze_record = {"source_commit": a.source, "runner_sha256": digest(LANE / "run_study.py"),
                         "controller_sha256": digest(__file__), "workloads_sha256": digest(lock_path),
                         "priors_sha256": {f: digest(v[1]) for f, v in selections.items()},
                         "frozen_before_heldout_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()}
        save(a.out / "heldout-freeze.json", freeze_record)
        for family, (winner, priors) in selections.items():
            groups = []
            for cycle, order in enumerate(schedule()):
                groups.append(attempt(family, "eval", cycle, order,
                                      "heldout-a" if cycle % 2 == 0 else "heldout-b",
                                      {"calibrated": winner}, priors=priors))
                save(a.out / f"{family}-selected-sets.json", groups)
            report = summarize(groups, 10)
            save(a.out / f"{family}-report.json", report)
            status(state="family-complete", family=family, report=report)
        save(a.out / "DONE.json", {"families": ["qwen", "gemma"], "sets_each": 10})
        status(state="complete")
    except BaseException as exc:
        status(state="failed", error_type=type(exc).__name__, error=str(exc))
        raise


if __name__ == "__main__":
    main()
