"""Independently reconstruct span labels and persistent observations from token bytes."""
import collections
import csv
import hashlib
from pathlib import Path

KINDS = ("prose", "code", "numeric")


def rows(path):
    with Path(path).open() as f:
        return list(csv.DictReader(f, delimiter="\t"))


class Tracker:
    def __init__(self, prompt):
        tail = prompt[-1024:].rsplit("\n\n", 1)[-1].strip()
        lower = tail.translate(str.maketrans("ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"))
        self.hint = ("numeric" if lower.startswith(("calculate", "compute a table", "tabulate"))
                     else "code" if lower.startswith(("write code", "write a python", "write a rust", "implement", "return a json"))
                     else "prose")
        self.window = collections.deque(maxlen=128)
        self.fenced = False
        self.ticks = 0

    def observe(self, data):
        for b in data:
            if b == 96:
                self.ticks += 1
                if self.ticks == 3:
                    self.fenced = not self.fenced
                    self.window.clear()
                    self.hint = "prose"
            else:
                self.ticks = 0
            self.window.append(b)

    def kind(self):
        digits = sum(48 <= b <= 57 for b in self.window)
        letters = sum(65 <= b <= 90 or 97 <= b <= 122 for b in self.window)
        math = sum(b in b"+-*/=.,:%" for b in self.window)
        if digits >= 4 and digits + math > letters:
            return "numeric"
        if self.fenced:
            return "code"
        return self.hint if len(self.window) < 24 else "prose"


def prior_costs(path, cap):
    with Path(path).open() as f:
        first = f.readline().strip().split("\t")
        if len(first) != 2 or first[0] != "global_k":
            raise ValueError("invalid prior header")
        records = list(csv.DictReader(f, delimiter="\t"))
    cells = {}
    for r in records:
        key = (r["context"], int(r["k"]))
        if key in cells:
            raise ValueError("duplicate prior cell")
        cells[key] = r
    costs = {}
    for kind in KINDS:
        for k in range(1, cap + 1):
            cell = cells[kind, k]
            if int(cell["rounds"]) < 32:
                cell = cells["all", k]
            costs[kind, k] = int(cell["elapsed_ns"]) / int(cell["tokens"])
    return int(first[1]), costs


def audit_run(root, arm, cap, priors=None):
    root = Path(root)
    token_bytes = {}
    for row in rows(root / "token-bytes.tsv"):
        i = int(row["id"])
        if i in token_bytes:
            raise ValueError("duplicate token byte mapping")
        token_bytes[i] = bytes.fromhex(row["hex"])
    spans = rows(root / "spans.tsv")
    events = rows(root / "context-events.tsv")
    contextual = arm in ("context", "learned")
    if contextual and len(events) != len(spans):
        raise ValueError("context decisions and recorded rounds disagree")
    if not contextual and events:
        raise ValueError("control unexpectedly contains context decisions")
    turns = rows(root / "turns.tsv")
    if len(turns) != 8:
        raise ValueError("incomplete conversation")
    initial_k, costs = prior_costs(priors, cap) if contextual else (None, {})
    totals = collections.defaultdict(lambda: [0, 0, 0])
    transitions, cpu_ns = 0, 0
    seen_context_turns = collections.defaultdict(set)
    for t in turns:
        turn = int(t["turn"])
        public = [int(s) for s in (root / f"turn-{turn}.output.ids").read_text().split()]
        output = [int(s) for s in (root / f"turn-{turn}.committed.ids").read_text().split()]
        if output[:len(public)] != public:
            raise ValueError("public output is not a prefix of the committed tape")
        tracker = Tracker((root / f"turn-{turn}.user.txt").read_text())
        these = [s for s in spans if int(s["turn"]) == turn]
        decisions = [s for s in events if int(s["turn"]) == turn]
        if len(these) != int(t["policy_rounds"]):
            raise ValueError("missing span rounds")
        seen = 0
        for i, span in enumerate(these):
            start, end = int(span["output_start"]), int(span["output_end"])
            k, ns = int(span["k"]), int(span["elapsed_ns"])
            eligible = span["eligible"] == "true"
            if not (seen <= start <= end <= len(output) and 1 <= k <= cap and ns > 0):
                raise ValueError("invalid span range or cost")
            tracker.observe(b"".join(token_bytes[x] for x in output[seen:start]))
            before = tracker.kind()
            tracker.observe(b"".join(token_bytes[x] for x in output[start:end]))
            after = tracker.kind()
            if (span["context_before"], span["context_after"]) != (before, after):
                raise ValueError("context label uses other than the committed byte prefix")
            if int(span["round"]) != i + 1:
                raise ValueError("span round sequence changed")
            transitions += before != after
            if eligible:
                if end > len(public) or not 1 <= end - start <= k + 1:
                    raise ValueError("learned from terminal overshoot or an impossible round")
                cell = totals[before, k]
                cell[0] += 1; cell[1] += end - start; cell[2] += ns
                seen_context_turns[before].add(turn)
            if contextual:
                event = decisions[i]
                for field in ("turn", "round", "context_before", "context_after", "k",
                              "output_start", "output_end", "elapsed_ns", "eligible"):
                    if event[field] != span[field]:
                        raise ValueError("online context event differs from independent replay")
                next_k = int(event["next_k"])
                if not 1 <= next_k <= cap:
                    raise ValueError("context selected an unqualified depth")
                if i + 1 < len(decisions) and next_k != int(decisions[i + 1]["k"]):
                    raise ValueError("selected depth was not used")
                if turn == 1 and i == 0 and k != initial_k:
                    raise ValueError("context policy did not start at the shared calibrated K")
                if event["reason"] == "probe" and abs(next_k - k) != 1:
                    raise ValueError("probe skipped neighboring depth")
                if arm == "context" and eligible:
                    expected = min(range(1, cap + 1), key=lambda x: (costs[after, x], x))
                    if next_k != expected:
                        raise ValueError("frozen context control changed its calibration rule")
                cpu_ns += int(event["cpu_ns"])
            seen = end
        if contextual:
            stats = rows(root / f"turn-{turn}.context-stats.tsv")
            expected_cells = {(kind, k) for kind in KINDS for k in range(1, cap + 1)}
            if len(stats) != len(expected_cells) or {(r["context"], int(r["k"])) for r in stats} != expected_cells:
                raise ValueError("missing or duplicate contextual state")
            for s in stats:
                actual = [int(s[x]) for x in ("rounds", "tokens", "elapsed_ns")]
                if actual != totals[s["context"], int(s["k"])]:
                    raise ValueError("context learner state reset, duplicated, or lost observations")
    return {
        "rounds": len(spans), "context_transitions": transitions, "controller_cpu_ns": cpu_ns,
        "observations": {f"{c}:{k}": v for (c, k), v in sorted(totals.items())},
        "context_turns": {c: sorted(v) for c, v in sorted(seen_context_turns.items())},
        "auditor_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
