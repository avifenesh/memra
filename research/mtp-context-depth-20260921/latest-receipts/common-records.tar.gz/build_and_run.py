"""Build the latest engine only after the frozen study has been sealed."""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import time
from pathlib import Path

OLD=Path('/opt/adaptive')
ROOT=OLD/'latest'
DATA=OLD/'receipts/latest-followup'


def save(name, value):
    (DATA/name).write_text(json.dumps(value,indent=2)+'\n')


def run(name, command, env):
    save('status.json',{'phase':name,'state':'running'})
    with (DATA/f'{name}.log').open('w') as log:
        subprocess.run(command,cwd=ROOT/'repo',env=env,stdout=log,
                       stderr=subprocess.STDOUT,check=True)


def main():
    while not (OLD/'receipts/closeout.exit').exists():
        time.sleep(10)
    if (OLD/'receipts/closeout.exit').read_text().strip()!='0':
        raise RuntimeError('Frozen study closeout needs repair before latest-engine work')
    source=json.loads((DATA/'source.json').read_text())
    archive=DATA/'runtime-source.tar.gz'
    with archive.open('rb') as stream:
        assert hashlib.file_digest(stream,'sha256').hexdigest()==source['runtime_archive_sha256']
    (ROOT/'repo').mkdir(parents=True,exist_ok=False)
    with tarfile.open(archive) as stream:
        stream.extractall(ROOT/'repo',filter='data')
    assert (ROOT/'repo/docs/FLAGS.md').is_file()
    # Regenerate build outputs after the interrupted export that lacked this registry.
    os.utime(ROOT/'repo/crates/memra-engine/build.rs',None)
    (ROOT/'tmp').mkdir(exist_ok=True)
    (ROOT/'binaries').mkdir(exist_ok=True)
    (ROOT/'models').symlink_to(OLD/'models',target_is_directory=True)
    (ROOT/'receipts').symlink_to(DATA,target_is_directory=True)
    shutil.copyfile(DATA/'source.json',ROOT/'source.json')
    shutil.copytree(OLD/'receipts/workloads',DATA/'workloads')
    env=os.environ.copy()
    for name in list(env):
        if name.startswith('MEMRA_'):del env[name]
    env.update(PATH='/root/.cargo/bin:/usr/local/cuda-13.1/bin:'+env['PATH'],
               LD_LIBRARY_PATH='/usr/local/cuda-13.1/lib64:'+env.get('LD_LIBRARY_PATH',''),
               CARGO_TARGET_DIR=str(OLD/'target'),CARGO_BUILD_JOBS='4',
               MEMRA_CUDA_ARCH='120a',TMPDIR=str(ROOT/'tmp'))
    build=['cargo','build','--locked','--release','-p','memra-engine']
    for name in ['mtp-depth-study','gemma-depth-study','kernel-check','run-gen',
                 'run-spec','gemma-spec-session-gate']:
        build+=['--bin',name]
    run('build',build,env)
    if 'boot audit is inert' in (DATA/'build.log').read_text():
        raise RuntimeError('Latest build omitted the boot-audit registry')
    run('clippy',['cargo','clippy','--locked','--release','-p','memra-engine','--lib',
                 '--bin','mtp-depth-study','--bin','gemma-depth-study','--','-D','warnings'],env)
    for name in ['context_depth','learned_depth','progress::tests','env_audit::tests']:
        run(name.replace('::','-')+'-tests',
            ['cargo','test','--locked','--release','-p','memra-engine','--lib',name,
             '--','--test-threads=1'],env)
    run('history-tests',['cargo','test','--locked','--release','-p','memra-engine',
                         '--bin','mtp-depth-study'],env)
    run('python-tests',['python3','-m','unittest','discover','-s',
                       'research/mtp-context-depth-20260921','-p','test_*.py'],env)
    binaries={}
    for name in ['mtp-depth-study','gemma-depth-study','kernel-check','run-gen',
                 'run-spec','gemma-spec-session-gate']:
        target=ROOT/'binaries'/name
        shutil.copy2(OLD/'target/release'/name,target)
        with target.open('rb') as stream:
            binaries[name]=hashlib.file_digest(stream,'sha256').hexdigest()
    save('BUILD-DONE.json',{'status':'passed','source':source,'binaries':binaries})
    env.pop('MEMRA_CUDA_ARCH')
    run('main-runner-checks',['python3',str(ROOT/'main_runner_checks.py')],env)
    run('comparison',['python3','-u',str(ROOT/'compare.py')],env)
    save('status.json',{'state':'complete'})


if __name__=='__main__':
    code=0
    try:
        main()
    except BaseException as error:
        code=1
        save('status.json',{'state':'failed','error_type':type(error).__name__,'error':str(error)})
        raise
    finally:
        (DATA/'pipeline.exit').write_text(str(code)+'\n')
