"""Independently replay source-paired results and inspect cross-version token identity."""
import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,default=Path('/opt/adaptive'))
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    root=args.root;data=root/'receipts/latest-followup'
    lane=root/'latest/repo/research/mtp-context-depth-20260921'
    if not __debug__:raise RuntimeError('Verification requires normal Python assertions')
    sys.path.insert(0,str(lane))
    from audit_context import audit_run
    from audit_reuse import audit_reuse
    from loop_audit import loop_candidate
    from run_study import audit_control_ids
    freeze=json.loads((data/'followup-freeze.json').read_text())
    sources={'old':freeze['original_source']['source_commit'],
             'latest':freeze['latest_source']['source_commit']}
    assert sources=={'old':'cb2f1783a0818705c5528f5b11cae0b0bc176deb',
                     'latest':'5450580fe2e5eb5c34cd17452f472ed368034f41'}
    assert freeze['latest_source']['runtime_archive_sha256']=='943d165b80f268ffacc63e78191c669ed4bda562b3151d45758876321e3f6dc8'
    assert digest(data/'runtime-source.tar.gz')==freeze['latest_source']['runtime_archive_sha256']
    assert digest(data/'compare.py')==freeze['comparison_script_sha256']
    assert digest(data/'build_and_run.py')==freeze['build_script_sha256']
    assert digest(lane/'run_study.py')==freeze['runner_sha256']
    assert digest(data/'workloads/workloads.lock.json')==freeze['workloads_sha256']
    assert json.loads((data/'source.json').read_text())==freeze['latest_source']
    build=json.loads((data/'BUILD-DONE.json').read_text())
    assert build==freeze['latest_build'] and build['status']=='passed'
    assert build['source']==freeze['latest_source']
    main_checks=json.loads((data/'main-runners/DONE.json').read_text())
    assert main_checks['status']=='passed' and main_checks['source_commit']==sources['latest']
    assert len(main_checks['checks'])==8 and all(r['returncode']==0 for r in main_checks['checks'])
    old_bins={row['file']:row['sha256'] for row in freeze['original_binaries']['binaries']}
    binaries={'old':old_bins,'latest':build['binaries']}
    qualification_turns=0
    for family,seed,cap in [('qwen',20270200,7),('gemma',20280200,5)]:
        parent=data/f'{family}-qualification'
        identity=json.loads((parent/'identity.json').read_text())
        binary='mtp-depth-study' if family=='qwen' else 'gemma-depth-study'
        assert identity['source_commit']==sources['latest']
        assert identity['binary_sha256']==binaries['latest'][binary]
        assert identity['mode']=='correctness-only'
        priors=parent/'context-priors.tsv'
        assert digest(priors)==freeze['priors_sha256'][family]
        records=json.loads((parent/'runs.json').read_text())
        assert [r['arm'] for r in records]==['calibrated','native','context','learned']
        audit_control_ids(parent,seed,['calibrated','context','learned'])
        for record in records:
            folder=parent/f'{seed}-{record["arm"]}'
            assert record['correctness_only'] and record['turns']==8
            assert audit_reuse(folder)==record['reuse']
            assert audit_run(folder,record['arm'],cap,priors)==record['context_audit']
            qualification_turns+=8
    groups=json.loads((data/'comparison-groups.json').read_text())
    plan=json.loads((data/'comparison-plan.json').read_text())
    assert len(groups)==4 and plan['sources']==sources
    arms=('calibrated','native','context','learned')
    forward=[[version,arm] for index,arm in enumerate(arms)
             for version in (('old','latest') if index%2==0 else ('latest','old'))]
    reports={};identities=[];excluded=[]
    for family in ('qwen','gemma'):
        selected=[g for g in groups if g['family']==family]
        assert [g['cycle'] for g in selected]==[0,1]
        cap=7 if family=='qwen' else 5
        k=3 if family=='qwen' else 4
        binary='mtp-depth-study' if family=='qwen' else 'gemma-depth-study'
        artifact=json.loads((lane/f'{family}-artifacts.lock.json').read_text())
        for group in selected:
            cycle=group['cycle'];seed=(20296500 if family=='qwen' else 20306500)+cycle
            order=forward if cycle==0 else list(reversed(forward))
            workload='heldout-a' if cycle==0 else 'heldout-b'
            assert group['seed']==seed and group['order']==order and group['workload']==workload
            assert [[r['version'],r['arm']] for r in group['runs']]==order
            found_loops=[]
            for index,run in enumerate(group['runs']):
                version,arm=order[index]
                name=f'{family}-pair-{cycle}-{index}-{version}-{arm}'
                assert run['receipt_dir']==name and run['seed']==seed
                parent=data/name;folder=parent/f'{seed}-{arm}'
                identity=json.loads((parent/'identity.json').read_text())
                assert identity['source_commit']==sources[version]
                assert identity['binary_sha256']==binaries[version][binary]
                assert identity['runner_sha256']==freeze['runner_sha256']
                assert identity['artifacts']==artifact
                assert identity['mode']=='measurement' and identity['max_new']==2048 and identity['ctx']==49152
                assert identity['fixed_depths']=={'calibrated':k}
                assert identity['settings']=={'MEMRA_SPEC_ADAPT':'1','MEMRA_SPEC_ADAPT_FLOOR':'1',
                    'MEMRA_SPEC_CAPMAX':str(cap),'MEMRA_SPEC_PMIN':'0','MEMRA_SPEC_PMIN_INROUND':'0'}
                assert identity['workload_sha256']==digest(data/f'workloads/{family}-{workload}.txt')
                priors=parent/'context-priors.tsv'
                assert digest(priors)==freeze['priors_sha256'][family]
                assert identity['context_priors_sha256']==digest(priors)
                assert digest(parent/'runner.py')==freeze['runner_sha256']
                assert json.loads((parent/'runs.json').read_text())==[run['record']]
                assert json.loads((data/(name+'.schedule.json')).read_text())==[{'cycle':0,'order':[arm]}]
                assert json.loads((data/(name+'.depths.json')).read_text())=={'calibrated':k}
                command=json.loads((parent/f'{seed}-{arm}.command.json').read_text())
                assert Path(command[0]).name==binary
                assert command[5:10]==[f'fixed:{k}' if arm=='calibrated' else arm,str(seed),'2048','49152','0.7']
                turns=list(csv.DictReader((folder/'turns.tsv').read_text().splitlines(),delimiter='\t'))
                assert [int(t['turn']) for t in turns]==list(range(1,9))
                tokens=0;seconds=0.;loops=[]
                for turn in turns:
                    number=int(turn['turn'])
                    ids=[int(x) for x in (folder/f'turn-{number}.output.ids').read_text().split()]
                    assert len(ids)==int(turn['output_tokens']) and int(turn['seed'])==seed
                    elapsed=float(turn['elapsed_s'])
                    assert math.isfinite(elapsed) and elapsed>0
                    tokens+=len(ids);seconds+=elapsed
                    flag=loop_candidate(ids) or loop_candidate(ids[:-1])
                    if flag:loops.append({'turn':number,**flag})
                record=run['record']
                assert record['turns']==8 and not record['correctness_only']
                assert record['tokens']==tokens and math.isclose(record['elapsed_s'],seconds,abs_tol=1e-6)
                assert math.isclose(record['e2e_tok_s'],tokens/seconds,rel_tol=1e-7)
                assert audit_reuse(folder)==record['reuse']
                assert audit_run(folder,arm,cap,priors)==record['context_audit']
                assert loops==run['loops']
                found_loops.extend(loops)
            assert group['excluded']==bool(found_loops)
            if group['excluded']:excluded.append({'family':family,'cycle':cycle})
            for arm in arms:
                paths={r['version']:data/r['receipt_dir']/f'{seed}-{arm}'
                       for r in group['runs'] if r['arm']==arm}
                same={kind:all((paths['old']/f'turn-{turn}.{kind}.ids').read_bytes()==
                               (paths['latest']/f'turn-{turn}.{kind}.ids').read_bytes()
                               for turn in range(1,9)) for kind in ('prompt','output')}
                identities.append({'family':family,'cycle':cycle,'arm':arm,**same})
        eligible=[g for g in selected if not g['excluded']]
        policies={}
        for arm in arms:
            rates={}
            for version in ('old','latest'):
                records=[r['record'] for g in eligible for r in g['runs']
                         if r['version']==version and r['arm']==arm]
                rates[version]=(sum(r['tokens'] for r in records)/sum(r['elapsed_s'] for r in records)
                                if records else None)
            paired=[]
            for group in eligible:
                rates_for_pair={r['version']:r['record']['e2e_tok_s'] for r in group['runs'] if r['arm']==arm}
                paired.append(100*(rates_for_pair['latest']/rates_for_pair['old']-1))
            policies[arm]={'rates':rates,'paired_percent':paired,
                           'pooled_change_percent':100*(rates['latest']/rates['old']-1) if eligible else None}
        reports[family]={'recorded_groups':2,'included_groups':len(eligible),'policies':policies}
    expected={'recorded_runs':32,'recorded_turns':256,'sources':sources,
              'reports':reports,'excluded_groups':excluded}
    assert expected==json.loads((data/'REPORT.json').read_text())
    result={'status':'passed','report_reproduced_exactly':True,'recorded_runs':32,
            'recorded_turns':256,'audit_sha256':digest(Path(__file__)),
            'sources':sources,'qualification_turns_reaudited':qualification_turns,
            'cross_version_token_identity':identities}
    path=data/'AUDIT.json'
    if args.check:assert json.loads(path.read_text())==result
    else:path.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
