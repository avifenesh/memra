"""Verify and package both result sets after the latest timed comparison ends."""
import json
import os
import subprocess
import time
from pathlib import Path

ROOT=Path('/opt/adaptive')
LATEST=ROOT/'latest'
DATA=ROOT/'receipts/latest-followup'


def step(name, command, timeout=900):
    (DATA/'postprocess-status.json').write_text(json.dumps({'state':'running','step':name})+'\n')
    env=os.environ.copy()
    env['PYTHONPATH']=str(ROOT/'audit-tools')
    env['TMPDIR']=str(LATEST/'tmp')
    with (DATA/f'postprocess-{name}.log').open('w') as log:
        subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,
                       timeout=timeout,check=True)


def main():
    while not (DATA/'pipeline.exit').exists():
        time.sleep(10)
    if (DATA/'pipeline.exit').read_text().strip()!='0':
        raise RuntimeError('Latest-engine measurement needs repair before archival')
    step('audit',['python3',str(LATEST/'audit_compare.py')])
    step('audit-check',['python3',str(LATEST/'audit_compare.py'),'--check'])
    step('package',['python3',str(LATEST/'package_latest.py')])
    bundle=DATA/'public'
    pin=(bundle/'manifest.sha256').read_text().split()[0]
    step('reproduce',['python3',str(LATEST/'reproduce_latest.py'),
                      '--receipts',str(bundle),'--manifest-sha256',pin])
    original=ROOT/'receipts/public'
    step('original-boundary-check',['python3',str(ROOT/'audit-tools/verify_boundary.py'),
          '--receipts',str(original),'--review',str(original/'boundary-review.json'),
          '--prefix','research/mtp-context-depth-20260921/receipts','--check'])
    step('latest-boundary-inventory',['python3',str(ROOT/'audit-tools/scan_archives.py'),
          '--receipts',str(bundle),'--prefix','research/mtp-context-depth-20260921/latest-receipts'])
    result={'status':'passed','manifest_sha256':pin,
            'report_reproduced_exactly':True,'original_boundary_recheck':'passed',
            'latest_boundary_review':'pending'}
    (DATA/'POSTPROCESS.json').write_text(json.dumps(result,indent=2)+'\n')
    (DATA/'postprocess-status.json').write_text(json.dumps({'state':'complete'})+'\n')


if __name__=='__main__':
    code=0
    try:main()
    except BaseException as error:
        code=1
        (DATA/'postprocess-status.json').write_text(json.dumps(
            {'state':'failed','error_type':type(error).__name__,'error':str(error)})+'\n')
        raise
    finally:(DATA/'postprocess.exit').write_text(str(code)+'\n')
