"""Interleave old/latest engines under identical priors and request settings."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

OLD=Path('/opt/adaptive')
ROOT=OLD/'latest'
DATA=OLD/'receipts/latest-followup'
LANE=ROOT/'repo/research/mtp-context-depth-20260921'
sys.path.insert(0,str(LANE))
from loop_audit import loop_candidate
from audit_reuse import audit_reuse
from audit_context import audit_run

ARMS=('calibrated','native','context','learned')
SOURCES={'old':'cb2f1783a0818705c5528f5b11cae0b0bc176deb',
         'latest':'5450580fe2e5eb5c34cd17452f472ed368034f41'}


def save(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def invoke(family, version, seed, arm, workload, name, gate=False):
    binary=('mtp-depth-study' if family=='qwen' else 'gemma-depth-study')
    binaries=OLD/'receipts/native-binaries' if version=='old' else ROOT/'binaries'
    parent=DATA/name
    schedule=DATA/(name+'.schedule.json');depths=DATA/(name+'.depths.json')
    order=list(ARMS) if gate else [arm]
    save(schedule,[{'cycle':0,'order':order}])
    save(depths,{'calibrated':3 if family=='qwen' else 4})
    command=[sys.executable,str(LANE/'run_study.py'),'--family',family,
             '--binary',str(binaries/binary),'--target',str(OLD/f'models/{family}/target.gguf'),
             '--workload',str(OLD/f'receipts/workloads/{family}-{workload}.txt'),
             '--out',str(parent),'--lock','/tmp/memra-gpu.lock','--max-new','2048',
             '--ctx','49152','--seed',str(seed),'--artifact-manifest',
             str(OLD/f'models/{family}/artifacts.lock.json'),'--source-commit',SOURCES[version],
             '--schedule',str(schedule),'--fixed-depths',str(depths),
             '--priors',str(OLD/f'receipts/experiment/{family}-priors.tsv')]
    if family=='gemma':command+=['--draft',str(OLD/'models/gemma/assistant.gguf')]
    if gate:command+=['--gate']
    save(DATA/'status.json',{'state':'running','family':family,'version':version,
                            'arm':arm,'seed':seed,'receipt_dir':name,'gate':gate})
    with (DATA/(name+'.driver.log')).open('w') as log:
        subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
    records=json.loads((parent/'runs.json').read_text())
    if gate:return records
    assert len(records)==1 and records[0]['arm']==arm
    record=records[0]
    run=parent/f'{seed}-{arm}'
    loops=[]
    for turn in range(1,9):
        ids=[int(x) for x in (run/f'turn-{turn}.output.ids').read_text().split()]
        found=loop_candidate(ids) or loop_candidate(ids[:-1])
        if found:loops.append({'turn':turn,**found})
    assert audit_reuse(run)==record['reuse']
    assert audit_run(run,arm,7 if family=='qwen' else 5,
                     OLD/f'receipts/experiment/{family}-priors.tsv')==record['context_audit']
    return {'family':family,'version':version,'arm':arm,'seed':seed,
            'receipt_dir':name,'record':record,'loops':loops}


def main():
    assert json.loads((DATA/'BUILD-DONE.json').read_text())['status']=='passed'
    assert json.loads((DATA/'main-runners/DONE.json').read_text())['status']=='passed'
    for name in ['run_study.py','audit_context.py','audit_reuse.py']:
        assert digest(LANE/name)==digest(OLD/'repo/research/mtp-context-depth-20260921'/name)
    for family,seed in [('qwen',20270200),('gemma',20280200)]:
        invoke(family,'latest',seed,'all','calibration-a',family+'-qualification',gate=True)
    plan=[]
    forward=[(version,arm) for index,arm in enumerate(ARMS)
             for version in (('old','latest') if index%2==0 else ('latest','old'))]
    for family in ('qwen','gemma'):
        for cycle in range(2):
            seed=(20296500 if family=='qwen' else 20306500)+cycle
            order=forward if cycle==0 else list(reversed(forward))
            plan.append({'family':family,'cycle':cycle,'seed':seed,'order':order,
                         'workload':'heldout-a' if cycle==0 else 'heldout-b'})
    save(DATA/'comparison-plan.json',{'sources':SOURCES,'groups':plan,
         'scope':'Two balanced source comparisons per model, with four policies per source; '
                 'original workload pools and shared calibration, fresh sampling seeds; diagnostic, not a retuned or production-default qualification.',
         'rule':'Exclude a whole eight-run source-paired group if any arm repeats; no replacement seeds.'})
    groups=[]
    for row in plan:
        records=[]
        for index,(version,arm) in enumerate(row['order']):
            name=f'{row["family"]}-pair-{row["cycle"]}-{index}-{version}-{arm}'
            records.append(invoke(row['family'],version,row['seed'],arm,row['workload'],name))
            save(DATA/'completed-runs.json',[r for g in groups for r in g['runs']]+records)
        groups.append({**row,'runs':records,'excluded':any(r['loops'] for r in records)})
        save(DATA/'comparison-groups.json',groups)
    reports={}
    for family in ('qwen','gemma'):
        eligible=[g for g in groups if g['family']==family and not g['excluded']]
        policies={}
        for arm in ARMS:
            rates={}
            for version in ('old','latest'):
                records=[r['record'] for g in eligible for r in g['runs']
                         if r['version']==version and r['arm']==arm]
                rates[version]=(sum(r['tokens'] for r in records)/sum(r['elapsed_s'] for r in records)
                                if records else None)
            pairs=[]
            for group in eligible:
                found={r['version']:r['record']['e2e_tok_s'] for r in group['runs'] if r['arm']==arm}
                pairs.append(100*(found['latest']/found['old']-1))
            policies[arm]={'rates':rates,'paired_percent':pairs,
                           'pooled_change_percent':100*(rates['latest']/rates['old']-1) if eligible else None}
        reports[family]={'recorded_groups':2,'included_groups':len(eligible),'policies':policies}
    save(DATA/'REPORT.json',{'recorded_runs':32,'recorded_turns':256,'sources':SOURCES,
                           'reports':reports,'excluded_groups':[
                               {'family':g['family'],'cycle':g['cycle']} for g in groups if g['excluded']]})
    save(DATA/'DONE.json',{'status':'passed','recorded_runs':32,'recorded_turns':256})


if __name__=='__main__':
    main()
