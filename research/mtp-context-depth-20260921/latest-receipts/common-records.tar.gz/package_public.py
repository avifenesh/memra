"""Package public study receipts; operational/provider material stays private."""
import argparse
import gzip
import hashlib
import json
import shutil
import tarfile
from pathlib import Path, PurePosixPath

COMMON = {
    'source.json', 'binaries.sha256', 'toolchain.json', 'RESULTS.md', 'learner-tests.log', 'control-tests.log',
    'history-tests.log', 'reuse-tests.log', 'clippy.log', 'archive-reader-tests.log',
    'build.log', 'workloads.log', 'publication-reader-tests.log',
    'publication-prior-replay.log', 'publication-checks.json', 'prior-reproduction.log',
    'experiment/DONE.json', 'experiment/FINAL-AUDIT.json',
    'experiment/heldout-freeze.json', 'experiment/schedule.json',
    'experiment/source.json', 'experiment/status.json', 'experiment/workloads.lock.json',
    'experiment/heldout-continuation.json', 'experiment/heldout-exclusions.json',
    'heldout-continuation.log', 'heldout-interruption.exit', 'experiment-driver.log',
}


def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def archive(root, files, destination):
    hashes = []
    with destination.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0, filename='') as zipped:
        with tarfile.open(fileobj=zipped, mode='w|') as out:
            for relative in sorted(files):
                path = root/relative
                if path.is_symlink() or not path.is_file() or '..' in PurePosixPath(relative).parts:
                    raise ValueError('Archive input is not a contained regular file')
                hashes.append(f'{digest(path)}  {relative}\n')
                info = out.gettarinfo(str(path), arcname=relative)
                info.uid = info.gid = 0; info.uname = info.gname = ''; info.mtime = 0
                with path.open('rb') as f:
                    out.addfile(info, f)
    checks = destination.with_name(destination.name.replace('.tar.gz', '.sha256'))
    checks.write_text(''.join(hashes))
    return {'file': destination.name, 'bytes': destination.stat().st_size, 'sha256': digest(destination),
            'files': len(files), 'file_manifest_sha256': digest(checks)}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, default=Path('/opt/adaptive'))
    p.add_argument('--out', type=Path, default=Path('/opt/adaptive/receipts/public'))
    a = p.parse_args()
    receipts = a.root/'receipts'
    final = json.loads((receipts/'experiment/FINAL-AUDIT.json').read_text())
    if set(final['models']) != {'qwen', 'gemma'} or any(not r['report_reproduced_exactly'] for r in final['models'].values()):
        raise ValueError('Full report audit has not passed')
    a.out.mkdir(parents=True, exist_ok=False)
    files = [f.relative_to(receipts).as_posix() for f in receipts.rglob('*') if f.is_file()]
    buckets = {'qwen': [], 'gemma': [], 'common': []}
    for name in files:
        parts = PurePosixPath(name).parts
        if len(parts) >= 2 and parts[0] == 'experiment' and parts[1].startswith(('qwen-', 'gemma-')):
            buckets[parts[1].split('-')[0]].append(name)
        elif name in COMMON or parts[0] == 'workloads' or parts[0] in ('final-audit-tools', 'main-runners'):
            buckets['common'].append(name)
    if not COMMON <= set(buckets['common']):
        raise ValueError('A required common receipt is missing')
    rows = [archive(receipts, buckets[name], a.out/f'{name}-records.tar.gz') for name in ('qwen', 'gemma', 'common')]
    source = json.loads((a.root/'source.json').read_text())
    if digest(a.root/'runtime-source.tar.gz') != source['runtime_archive_sha256']:
        raise ValueError('Runtime archive changed')
    shutil.copyfile(a.root/'runtime-source.tar.gz', a.out/'runtime-source.tar.gz')
    manifest = {'schema': 1, 'archives': rows, 'runtime_source': source,
                'scope': 'all completed qualification, calibration, development and held-out receipts for the corrected source',
                'earlier_unscored_attempt': 'initial controller, excluded calibration and unused partial held-out data are banked separately as iteration-1',
                'performance_verdict_eligible': final['performance_verdict_eligible']}
    manifest.update(recorded_runs=final['recorded_runs'], scored_runs=final['scored_runs'],
                    scored_timed_turns=final['scored_timed_turns'],
                    matched_set_exclusions=final['matched_set_exclusions'])
    (a.out/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(json.dumps({'archives': rows, 'manifest_sha256': digest(a.out/'manifest.json')}, indent=2))


if __name__ == '__main__':
    main()
