"""Publish raw source comparisons while keeping executables and failed builds private."""
import json
import os
import shutil
import tempfile
from pathlib import Path

ROOT=Path('/opt/adaptive')
DATA=ROOT/'receipts/latest-followup'
from package_public import archive, digest

COMMON = {
    'source.json', 'BUILD-DONE.json', 'comparison-plan.json', 'comparison-groups.json',
    'completed-runs.json', 'REPORT.json', 'AUDIT.json', 'DONE.json',
    'native-binaries.json', 'status.json', 'followup-freeze.json',
    'pipeline.log', 'build.log', 'clippy.log', 'context_depth-tests.log',
    'learned_depth-tests.log', 'progress-tests-tests.log', 'env_audit-tests-tests.log',
    'history-tests.log', 'python-tests.log', 'main-runner-checks.log', 'comparison.log',
}


def main():
    audit=json.loads((DATA/'AUDIT.json').read_text())
    assert audit['status']=='passed' and audit['report_reproduced_exactly']
    assert json.loads((DATA/'DONE.json').read_text())=={
        'status':'passed','recorded_runs':32,'recorded_turns':256}
    build=json.loads((DATA/'BUILD-DONE.json').read_text())
    binaries=DATA/'native-binaries'
    binaries.mkdir(exist_ok=True)
    binary_rows=[]
    for name,sha in build['binaries'].items():
        source=ROOT/'latest/binaries'/name
        assert digest(source)==sha
        target=binaries/name
        if not target.exists():shutil.copy2(source,target)
        assert digest(target)==sha
        binary_rows.append({'file':name,'sha256':sha,'bytes':target.stat().st_size})
    (DATA/'native-binaries.json').write_text(json.dumps(binary_rows,indent=2)+'\n')
    output=DATA/'public'
    output.mkdir(exist_ok=False)
    buckets={name:[] for name in ['qwen','gemma','common']}
    with tempfile.TemporaryDirectory(prefix='latest-public-',dir=ROOT/'latest/tmp') as temporary:
        staging=Path(temporary)
        for source in sorted(DATA.rglob('*')):
            if not source.is_file() or source.is_symlink():continue
            relative=source.relative_to(DATA)
            top=relative.parts[0]
            if top.startswith(('qwen-','gemma-')):
                name='experiment/'+relative.as_posix()
                bucket=top.split('-')[0]
            elif (len(relative.parts)==1 and (source.name in COMMON or source.suffix=='.py')) or top in ('workloads','main-runners'):
                name=relative.as_posix();bucket='common'
            else:
                continue
            target=staging/name
            target.parent.mkdir(parents=True,exist_ok=True)
            os.link(source,target)
            buckets[bucket].append(name)
        assert COMMON <= set(buckets['common'])
        rows=[archive(staging,buckets[name],output/f'{name}-records.tar.gz')
              for name in ['qwen','gemma','common']]
    source=json.loads((DATA/'source.json').read_text())
    assert digest(DATA/'runtime-source.tar.gz')==source['runtime_archive_sha256']
    shutil.copy2(DATA/'runtime-source.tar.gz',output/'runtime-source.tar.gz')
    manifest={'schema':1,'kind':'interleaved-engine-followup','archives':rows,
              'runtime_source':source,'original_source':audit['sources']['old'],
              'recorded_runs':32,'recorded_turns':256}
    path=output/'manifest.json'
    path.write_text(json.dumps(manifest,indent=2)+'\n')
    (output/'manifest.sha256').write_text(digest(path)+'  manifest.json\n')
    print(json.dumps({'manifest_sha256':digest(path),'archives':rows},indent=2))


if __name__=='__main__':main()
