"""Exact repeated-output screening, applied after the request clock."""
def loop_candidate(ids):
    # Exact repeated output, not a repeated schema whose values keep changing.
    # Check overlapping windows as well as the final suffix.
    for end in sorted(set([len(ids), *range(512, len(ids) + 1, 256)])):
        for period in range(1, 129):
            repeated = max(4, (256 + period - 1) // period)
            size = repeated * period
            if end < size:
                continue
            block = ids[end-period:end]
            if ids[end-size:end] == block * repeated:
                return {'end_token': end, 'period': period, 'repeated_tokens': size}
    return None

