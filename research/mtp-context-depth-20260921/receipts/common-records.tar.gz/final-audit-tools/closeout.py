"""Finish verification and portable reproduction before the owned pod is released."""
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path('/opt/adaptive')
TOOLS = ROOT/'audit-tools'
RECEIPTS = ROOT/'receipts'


def archive_binaries():
    expected = {
        Path(path).name: sha for sha, path in
        (line.split(maxsplit=1) for line in (RECEIPTS/'binaries.sha256').read_text().splitlines())
    }
    if set(expected) != {'mtp-depth-study', 'gemma-depth-study'}:
        raise ValueError('Unexpected measured executable inventory')
    destination = RECEIPTS/'native-binaries'
    destination.mkdir(exist_ok=True)
    records = []
    for name, sha in sorted(expected.items()):
        source = ROOT/'target/release'/name
        target = destination/name
        if source.is_symlink() or target.is_symlink():
            raise ValueError('Measured executable cannot be a symlink')
        with source.open('rb') as stream:
            if hashlib.file_digest(stream, 'sha256').hexdigest() != sha:
                raise ValueError('Measured executable changed before archival')
        if not target.exists():
            shutil.copy2(source, target)
        with target.open('rb') as stream:
            if hashlib.file_digest(stream, 'sha256').hexdigest() != sha:
                raise ValueError('Archived executable differs from the measured binary')
        records.append({'file': name, 'sha256': sha, 'bytes': target.stat().st_size})
    record = {'source': json.loads((ROOT/'source.json').read_text()), 'binaries': records}
    manifest = destination/'manifest.json'
    if manifest.exists() and json.loads(manifest.read_text()) != record:
        raise ValueError('Measured executable manifest changed')
    manifest.write_text(json.dumps(record, indent=2)+'\n')


def run(name, args):
    with (RECEIPTS/f'{name}.log').open('w') as log:
        result = subprocess.run(args, stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        (RECEIPTS/'closeout.json').write_text(json.dumps(
            {'status': 'failed', 'step': name, 'returncode': result.returncode}, indent=2)+'\n')
        raise SystemExit(result.returncode)


def main():
    archive_binaries()
    with (RECEIPTS/'main-runner-checks.log').open('w') as log:
        main_checks = subprocess.run([sys.executable, str(TOOLS/'main_runner_checks.py')], stdout=log, stderr=subprocess.STDOUT)
    run('final-audit', [sys.executable, str(TOOLS/'finalize.py')])
    run('render-results', [sys.executable, str(TOOLS/'render_results.py')])
    run('archive-reader-tests', ['bash', str(ROOT/'repo/tools/unittest-floor.sh'),
                                 str(TOOLS), 'test_*.py', '16'])
    run('prior-reproduction', [sys.executable, str(TOOLS/'reproduce_development.py'),
                              '--receipts', str(RECEIPTS/'prior-public'),
                              '--manifest-sha256',
                              '4c89b2a243cea44be43ba19f3826e57d3df06b6c2629cbfbd1c4019c14e9ff62'])
    run('public-bundle', [sys.executable, str(TOOLS/'package_public.py')])
    manifest = RECEIPTS/'public/manifest.json'
    manifest_sha = hashlib.sha256(manifest.read_bytes()).hexdigest()
    run('public-reproduction', [sys.executable, str(TOOLS/'reproduce.py'),
                                '--receipts', str(manifest.parent), '--manifest-sha256', manifest_sha])
    run('boundary-inventory', [sys.executable, str(TOOLS/'scan_archives.py')])
    boundary = json.loads((RECEIPTS/'public/boundary-scan.json').read_text())
    final_audit = json.loads((RECEIPTS/'experiment/FINAL-AUDIT.json').read_text())
    record = {'status': 'passed' if main_checks.returncode == 0 else 'main_runner_checks_failed',
              'boundary_review': boundary['status'], 'manifest_sha256': manifest_sha,
              'reports_reproduced_exactly': True, 'archive_reader_tests': 16,
              'recorded_runs': final_audit['recorded_runs'],
              'scored_runs': final_audit['scored_runs'],
              'scored_timed_turns': final_audit['scored_timed_turns'],
              'performance_verdict_eligible': final_audit['performance_verdict_eligible'],
              'main_runner_returncode': main_checks.returncode}
    (RECEIPTS/'public/REPRODUCTION.json').write_text(json.dumps(record, indent=2)+'\n')
    (RECEIPTS/'closeout.json').write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps(record))
    if main_checks.returncode:
        raise SystemExit(main_checks.returncode)

if __name__ == '__main__':
    code = 0
    try:
        main()
    except BaseException:
        code = 1
        raise
    finally:
        (RECEIPTS/'closeout.exit').write_text(str(code)+'\n')
