"""Render a scoped report from the completed, independently verified measurement."""
import csv
import json
from pathlib import Path

ROOT=Path('/opt/adaptive')
LANE=ROOT/'repo/research/mtp-context-depth-20260921'
AUDIT=ROOT/'receipts/experiment/FINAL-AUDIT.json'


def calibrated_depths(family, cap):
    path=ROOT/'receipts/experiment'/f'{family}-priors.tsv'
    rows=csv.DictReader(path.read_text().splitlines()[1:],delimiter='\t')
    cells={(r['context'],int(r['k'])):r for r in rows}
    result={}
    for context in ['prose','code','numeric']:
        def cost(k):
            row=cells[(context,k)]
            if int(row['rounds'])<32:
                row=cells[('all',k)]
            rounds=int(row['rounds'])
            return (int(row['elapsed_ns'])/rounds)/(int(row['tokens'])/rounds)
        result[context]=min(range(1,cap+1),key=cost)
    return result


def main():
    audit=json.loads(AUDIT.read_text())
    source=json.loads((ROOT/'source.json').read_text())
    if set(audit['models'])!={'qwen','gemma'} or not all(m['report_reproduced_exactly'] for m in audit['models'].values()):
        raise ValueError('Complete report reproduction is required')
    main_gate=ROOT/'receipts/main-runners/DONE.json'
    main_ok=main_gate.exists() and json.loads(main_gate.read_text())['status']=='passed'
    out=['# Context-conditioned depth with paired local evidence','',
         'The original schedule recorded ten matched sets per model, five policies per set, '
         'and one eight-turn conversation per run: **100 runs and 800 held-out timed turns**. '
         f"The throughput comparison uses **{audit['scored_runs']} runs and "
         f"{audit['scored_timed_turns']} turns** after excluding complete matched sets flagged "
         'by the exact-repeat screen. The remaining original seeds were completed without replacements.', '',
         'The metric is total returned output tokens divided by total native request seconds. '
         'Rendering/tokenization, checkpoint restore, suffix processing, classification, policy updates, '
         'generation, synchronization and detokenization are included. Model loading, token-byte table '
         'construction, warmup and receipt I/O are excluded.', '']
    if not audit['performance_verdict_eligible'] or not main_ok:
        out += ['**A performance conclusion is withheld.** '
                'Inspect `receipts/experiment/FINAL-AUDIT.json` and the main-runner receipts. '
                'The recorded token/time totals remain diagnostic evidence; they are not a promotion gate.', '']
        out += [f"Measured source: `{source['source_commit']}`.", '',
                f"Runtime archive SHA-256: `{source['runtime_archive_sha256']}`.", '']
        (ROOT/'receipts/RESULTS.md').write_text('\n'.join(out))
        return
    else:
        out += ['All included calibration, development and held-out records passed the exact-repeat screen. '
                'The reports reproduced from their token tapes, times, source bindings, cache traces and '
                 'paired-evidence records.', '']
    out += ['Excluded matched sets (all five policies are omitted from the throughput comparison):', '']
    for family, excluded in audit['matched_set_exclusions'].items():
        for cycle, loops in sorted(excluded.items(), key=lambda item:int(item[0])):
            details='; '.join(f"{row['arm']} turn {row['turn']}: period {row['period']}, "
                              f"{row['repeated_tokens']} repeated tokens" for row in loops)
            out.append(f"- {family}, cycle {cycle}: {details}. Raw records remain archived.")
    out += ['', 'These are comparisons among complete conversations that passed the screen. '
            'The excluded response and its matched controls are retained separately from the score; '
            'the screening outcome is part of the result.', '']
    out += ['| Model | Global fixed K | Prose K | Code K | Numeric K |',
            '|---|---:|---:|---:|---:|']
    for family,cap in [('qwen',7),('gemma',5)]:
        depths=calibrated_depths(family,cap)
        fixed=audit['models'][family]['calibration']['selected_k']
        out.append(f"| {family} | {fixed} | {depths['prose']} | {depths['code']} | {depths['numeric']} |")
    out += ['', 'These are calibration choices. Both contextual policies begin with the same priors; '
            'the held-out comparison below measures whether using or updating them improves complete '
            'request throughput. K counts drafted tokens.', '',
            '| Model | Calibrated fixed K | Fixed tok/s | Native tok/s | Frozen context tok/s | Online tok/s |',
            '|---|---:|---:|---:|---:|---:|']
    names={'qwen':'Qwen3.8-27B NVFP4+Q5_K / embedded MTP',
           'gemma':'Gemma 4 12B QAT Q4_0 / QAT Q8_0 assistant'}
    for family in ['qwen','gemma']:
        model=audit['models'][family];report=model['report'];rates=report['pooled_request_e2e_tok_s']
        k=model['calibration']['selected_k']
        out.append(f"| {names[family]} | {k} | {rates['calibrated']:.3f} | {rates['native']:.3f} | {rates['context']:.3f} | {rates['learned']:.3f} |")
    out += ['', '| Model / online compared with | Pooled change | Median paired change | Wins |',
            '|---|---:|---:|---:|']
    for family in ['qwen','gemma']:
        report=audit['models'][family]['report']
        for key,label in [('calibrated','fixed'),('native','native'),('context','frozen context')]:
            r=report['comparisons']['learned'][key]
            out.append(f"| {family} / {label} | {r['pooled_change_percent']:+.2f}% | {r['median_pair_percent']:+.2f}% | {r['wins']}/{report['sets']} |")
    out += ['', 'The frozen-context comparison isolates whether online preference updates add value '
            'beyond a calibrated context lookup. Models and protocols are never pooled together.', '',
            '## What the controller actually did', '',
            '| Model | Completed local comparisons | Preference adoptions | Recorded policy CPU / request time | Trial round time / request time |',
            '|---|---:|---:|---:|---:|']
    for family in ['qwen','gemma']:
        d=audit['models'][family]['diagnostics']['learned'];seconds=d['seconds']
        out.append(f"| {family} | {d['paired_comparisons']} | {d['adoptions']} | {100*d['cpu_ns']/1e9/seconds:.4f}% | {100*d['probe_ns']/1e9/seconds:.3f}% |")
    out += ['', 'A preference adoption requires a candidate to beat an 8/4/8-round locally bracketed '
            'incumbent comparison by more than 2%, with no more than 10% before/after baseline drift, '
            'on two distinct prompts. Context transitions reuse the established preference immediately. '
            'Trial time includes useful generated output and is not removable overhead. The CPU figures '
            'are recorded classifier/update diagnostics, not counterfactual asynchronous speedups.', '',
            '## Scope and validation', '',
            '- One RTX 5090 32GB, CUDA 13.1 / sm_120a, driver 595.84, recorded 525 W limit. '
            'The power limit is metadata, not a causal explanation.',
            '- Full vocabulary heads; no head masking or confidence cutoff. Temperature 0.7, '
            'top-k 20, top-p 0.95, up to 2,048 returned tokens per turn, 49,152-token reservation.',
            '- Initial prompts are approximately 16K tokens. Render-stable prompt checkpoints persist '
            'across turns; the previous reply and new user text are re-primed as a suffix. '
            'This does not retain every generated KV row.',
            '- The scenarios are synthetic and share a conversation format. The byte classifier '
            'uses fences, numeric density and a short prompt hint; it is not a semantic classifier.',
            '- The paired revision uses fresh held-out topics and seeds. First-iteration development '
            'results motivated the update; its partial held-out outcomes were not used.',
            '- Native-session correctness is checked cold/resumed and across all allowed fixed depths '
            'and the contextual policies. Ordinary kernel, prefill/decode, plain/spec and Gemma '
            'session-boundary runner receipts are retained separately.',
            '- This is a direct native-session study, not an HTTP/concurrency or vendor-default '
            'serving qualification. No serving default is changed by this report.', '',
            '## Source and evidence', '', f"Measured source: `{source['source_commit']}`.", '',
            f"Runtime archive SHA-256: `{source['runtime_archive_sha256']}`.", '']
    for family in ['qwen','gemma']:
        out.append(f"- {family} binary SHA-256: `{audit['models'][family]['binary_sha256']}`.")
    out += ['- The current portable archives contain the raw commands, token tapes, timing, GPU telemetry, '
            'calibration, state traces and paired comparisons. `publication/reproduce.py` verifies them '
            'before loading their exact audit code.',
            '- `prior-receipts/` preserves the first iteration’s completed development study and its '
            'rejected calibration set separately. Its results are not mixed into the final score.', '']
    (ROOT/'receipts/RESULTS.md').write_text('\n'.join(out))
    print('Rendered the completed study report')


if __name__=='__main__':main()
