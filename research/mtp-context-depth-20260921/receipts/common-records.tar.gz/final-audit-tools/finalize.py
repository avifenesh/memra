"""Reproduce completed reports from returned-token tapes and independent context audits."""
import argparse
import collections
import csv
import hashlib
import json
import math
import re
import sys
from pathlib import Path
from scored_sets import matched_report


def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def loop_candidate(ids):
    # Exact repeated output, not a repeated schema whose values keep changing.
    # Check overlapping windows as well as the final suffix.
    for end in sorted(set([len(ids), *range(512, len(ids) + 1, 256)])):
        for period in range(1, 129):
            repeated = max(4, (256 + period - 1) // period)
            size = repeated * period
            if end < size:
                continue
            block = ids[end-period:end]
            if ids[end-size:end] == block * repeated:
                return {'end_token': end, 'period': period, 'repeated_tokens': size}
    return None


def sampled_tapes(run, scope, loops):
    with (run/'turns.tsv').open() as f:
        turns = list(csv.DictReader(f, delimiter='\t'))
    assert [int(t['turn']) for t in turns] == list(range(1, 9))
    count = 0
    for turn in turns:
        t = int(turn['turn'])
        ids = [int(x) for x in (run/f'turn-{t}.output.ids').read_text().split()]
        assert len(ids) == int(turn['output_tokens'])
        assert len((run/f'turn-{t}.prompt.ids').read_text().split()) == int(turn['prompt_tokens'])
        count += len(ids)
        suspect = loop_candidate(ids) or loop_candidate(ids[:-1])
        if suspect:
            loops.append({**scope, 'turn': t, **suspect})
    seconds = sum(float(t['elapsed_s']) for t in turns)
    assert count > 0 and math.isfinite(seconds) and seconds > 0
    return count, seconds


def check_calibration(study, family, cap, source, binary, lane, workloads, audit_context, loops):
    selection = json.loads((study/f'{family}-selection.json').read_text())
    groups = selection['calibration']
    assert len(groups) == 2 and [g['cycle'] for g in groups] == [0, 1]
    rates, totals = {}, collections.defaultdict(lambda: [0, 0, 0])
    for i, group in enumerate(groups):
        assert group['receipt_dir'] == f'{family}-calibration-{i}'
        names = [f'k{k}' for k in range(1, cap + 1)]
        order = names if i == 0 else list(reversed(names))
        assert [r['arm'] for r in group['records']] == order
        parent = study/group['receipt_dir']
        identity = json.loads((parent/'identity.json').read_text())
        assert json.loads((parent/'runs.json').read_text()) == group['records']
        assert identity['source_commit'] == source and identity['binary_sha256'] == binary
        assert identity['mode'] == 'measurement'
        assert identity['runner_sha256'] == digest(lane/'run_study.py')
        assert identity['audit_context_sha256'] == digest(audit_context.__file__)
        assert identity['workload_sha256'] == workloads['families'][family][f'calibration-{"a" if i == 0 else "b"}']['sha256']
        for record in group['records']:
            arm = record['arm']; k = int(arm[1:])
            run = parent/f'{group["seed"]}-{arm}'
            count, seconds = sampled_tapes(run, {'phase': 'calibration', 'family': family, 'seed': group['seed'], 'arm': arm}, loops)
            assert not record['correctness_only'] and record['turns'] == 8
            assert count == record['tokens'] and math.isclose(seconds, record['elapsed_s'], abs_tol=1e-6)
            bucket = rates.setdefault(k, [0, 0.0])
            bucket[0] += record['tokens']; bucket[1] += record['elapsed_s']
            audit = audit_context.audit_run(run, arm, cap)
            assert audit == record['context_audit']
            for label, values in audit['observations'].items():
                kind, actual_k = label.split(':')
                assert int(actual_k) == k
                for name in (kind, 'all'):
                    cell = totals[name, k]
                    for j, value in enumerate(values):
                        cell[j] += value
    pooled = {k: n/s for k, (n, s) in rates.items()}
    winner = min(pooled, key=lambda k: (-pooled[k], k))
    assert winner == selection['selected_k']
    assert {str(k): v for k, v in pooled.items()} == selection['pooled_calibration_tok_s']
    text = f'global_k\t{winner}\ncontext\tk\trounds\ttokens\telapsed_ns\n'
    for kind in ('all', 'prose', 'code', 'numeric'):
        for k in range(1, cap + 1):
            n, tokens, ns = totals[kind, k]
            text += f'{kind}\t{k}\t{n}\t{tokens}\t{ns}\n'
    path = study/f'{family}-priors.tsv'
    assert path.read_text() == text and digest(path) == selection['priors_sha256']
    return {'selected_k': winner, 'records': cap * 2, 'priors_reproduced_exactly': True}


def check_gates(study, family, cap, source, binary, priors, audit_context, run_study):
    basis = json.loads((study/f'{family}-basis-qualification.json').read_text())
    assert [b['shape'] for b in basis] == ['short', 'long']
    total = 0
    for pair in basis:
        cold, warm = pair['cold'], pair['warm']
        assert cold['receipt_dir'] == f'{family}-cold-{pair["shape"]}-0'
        assert warm['receipt_dir'] == f'{family}-basis-{pair["shape"]}-0'
        expected = ['native', 'measured', *[f'k{k}' for k in range(1, cap + 1)]]
        assert [r['arm'] for r in warm['records']] == expected
        for group in (cold, warm):
            parent = study/group['receipt_dir']
            identity = json.loads((parent/'identity.json').read_text())
            assert identity['source_commit'] == source and identity['binary_sha256'] == binary
            assert identity['mode'] == 'correctness-only'
            assert json.loads((parent/'runs.json').read_text()) == group['records']
            for record in group['records']:
                assert record['correctness_only'] and record['turns'] == 8
                run = parent/f'{group["seed"]}-{record["arm"]}'
                assert audit_context.audit_run(run, record['arm'], cap) == record['context_audit']
                total += 8
        run_study.audit_control_ids(study/warm['receipt_dir'], warm['seed'], expected[1:])
        for turn in range(1, 9):
            for kind in ('prompt', 'output'):
                filename = f'turn-{turn}.{kind}.ids'
                a = study/cold['receipt_dir']/f'{cold["seed"]}-native'/filename
                b = study/warm['receipt_dir']/f'{warm["seed"]}-native'/filename
                assert a.read_bytes() == b.read_bytes()
    group = json.loads((study/f'{family}-context-qualification.json').read_text())
    assert group['receipt_dir'] == f'{family}-context-gate-0'
    parent = study/group['receipt_dir']
    identity = json.loads((parent/'identity.json').read_text())
    assert identity['source_commit'] == source and identity['binary_sha256'] == binary
    assert identity['context_priors_sha256'] == digest(priors)
    assert identity['mode'] == 'correctness-only'
    assert [r['arm'] for r in group['records']] == ['native', 'calibrated', 'context', 'learned']
    assert json.loads((parent/'runs.json').read_text()) == group['records']
    run_study.audit_control_ids(parent, group['seed'], ['calibrated', 'context', 'learned'])
    reference = basis[1]['cold']
    for turn in range(1, 9):
        for kind in ('prompt', 'output'):
            filename = f'turn-{turn}.{kind}.ids'
            a = study/reference['receipt_dir']/f'{reference["seed"]}-native'/filename
            b = parent/f'{group["seed"]}-native'/filename
            assert a.read_bytes() == b.read_bytes()
    for record in group['records']:
        run = parent/f'{group["seed"]}-{record["arm"]}'
        assert record['correctness_only'] and record['turns'] == 8
        assert audit_context.audit_run(run, record['arm'], cap, priors) == record['context_audit']
        total += 8
    return total


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, default=Path('/opt/adaptive'))
    p.add_argument('--portable', action='store_true', help='Use the sealed binary hash manifest without requiring executable files')
    p.add_argument('--check', action='store_true', help='Compare the sealed final audit without rewriting it')
    a = p.parse_args()
    if not __debug__:
        raise RuntimeError("Run the verifier without Python optimization")
    lane = a.root / 'repo/research/mtp-context-depth-20260921'
    sys.path.insert(0, str(lane))
    import audit_context
    import audit_reuse
    import controller
    import run_study
    study = a.root / 'receipts/experiment'
    exclusions = json.loads((study/'heldout-exclusions.json').read_text())
    continuation = json.loads((study/'heldout-continuation.json').read_text())
    assert set(exclusions) == {'qwen', 'gemma'}
    assert continuation['source_commit'] == 'cb2f1783a0818705c5528f5b11cae0b0bc176deb'
    assert continuation['remaining_cycles'] == [5, 6, 7, 8, 9]
    assert continuation['replacement_seeds'] == [] and not continuation['policy_and_inputs_changed']
    assert continuation['orchestrator_sha256'] == digest(Path(__file__).with_name('resume_heldout.py'))
    frozen = json.loads((study / 'heldout-freeze.json').read_text())
    identity = json.loads((a.root / 'source.json').read_text())
    binaries = {}
    for line in (a.root/'receipts/binaries.sha256').read_text().splitlines():
        sha, path = line.split(maxsplit=1)
        name = Path(path).name
        if not re.fullmatch(r'[0-9a-f]{64}', sha) or name in binaries:
            raise ValueError("Invalid binary hash manifest")
        binaries[name] = sha
    assert set(binaries) == {'mtp-depth-study', 'gemma-depth-study'}
    assert frozen['source_commit'] == identity['source_commit']
    assert frozen['runner_sha256'] == digest(lane/'run_study.py')
    assert frozen['controller_sha256'] == digest(lane/'controller.py')
    assert frozen['workloads_sha256'] == digest(a.root/'receipts/workloads/workloads.lock.json')
    workloads = json.loads((a.root/'receipts/workloads/workloads.lock.json').read_text())
    assert digest(audit_context.__file__) == digest(lane/'audit_context.py')
    assert digest(audit_reuse.__file__) == digest(lane/'audit_reuse.py')
    summary = {'source_commit': identity['source_commit'], 'models': {}, 'loops': [],
                'context_auditor_sha256': digest(audit_context.__file__),
                'reuse_auditor_sha256': digest(audit_reuse.__file__), 'finalizer_sha256': digest(__file__)}
    summary['matched_report_sha256'] = digest(Path(__file__).with_name('scored_sets.py'))
    summary['iteration'] = 'paired-local-evidence'
    summary['selection_scope'] = 'Fresh held-out topics and seeds; earlier iteration held-out outcomes were not used'
    summary['matched_set_exclusions'] = exclusions
    for family, cap in [('qwen', 7), ('gemma', 5)]:
        ledger = json.loads((study/f'{family}-selected-sets.json').read_text())
        assert len(ledger) == 10 and [g['cycle'] for g in ledger] == list(range(10))
        assert len({g['seed'] for g in ledger}) == 10
        priors = study/f'{family}-priors.tsv'
        assert digest(priors) == frozen['priors_sha256'][family]
        binary = a.root/'target/release'/('mtp-depth-study' if family=='qwen' else 'gemma-depth-study')
        expected_binary = binaries[binary.name]
        if not a.portable:
            assert digest(binary) == expected_binary
        artifacts = json.loads((lane/f'{family}-artifacts.lock.json').read_text())
        global_k, _ = audit_context.prior_costs(priors, cap)
        calibration = check_calibration(study, family, cap, identity['source_commit'],
                                        expected_binary, lane, workloads, audit_context, summary['loops'])
        correctness_turns = check_gates(study, family, cap, identity['source_commit'],
                                       expected_binary, priors, audit_context, run_study)
        development = json.loads((study/f'{family}-development-sets.json').read_text())
        assert len(development) == 2
        for group in development:
            assert group['receipt_dir'] == f'{family}-development-{group["cycle"]}'
            parent = study/group['receipt_dir']
            declared = json.loads((parent/'identity.json').read_text())
            assert declared['source_commit'] == identity['source_commit'] and declared['binary_sha256'] == expected_binary
            assert declared['context_priors_sha256'] == digest(priors)
            assert json.loads((parent/'runs.json').read_text()) == group['records']
            for record in group['records']:
                run = parent/f'{group["seed"]}-{record["arm"]}'
                count, seconds = sampled_tapes(run, {'phase': 'development', 'family': family,
                                                     'seed': group['seed'], 'arm': record['arm']}, summary['loops'])
                assert not record['correctness_only'] and count == record['tokens']
                assert math.isclose(seconds, record['elapsed_s'], abs_tol=1e-6)
                assert audit_context.audit_run(run, record['arm'], cap, priors) == record['context_audit']
        assert controller.summarize(development, 2) == json.loads((study/f'{family}-development-report.json').read_text())
        reproduced = []
        observed_exclusions = {}
        declared_exclusions = exclusions[family]
        observations = {
            arm: {'cpu_ns': 0, 'seconds': 0.0, 'transitions': 0, 'contexts': {},
                  'paired_comparisons': 0, 'adoptions': 0, 'final_preferences': [],
                  'probe_rounds': 0, 'probe_ns': 0}
            for arm in controller.ARMS
        }
        for group, order in zip(ledger, controller.schedule(), strict=True):
            group_loops = []
            excluded = str(group['cycle']) in declared_exclusions
            assert group['receipt_dir'] == f'{family}-eval-{group["cycle"]}'
            assert group['seed'] == (20295000 if family == 'qwen' else 20305000) + group['cycle']
            parent = study/group['receipt_dir']
            recorded = json.loads((parent/'identity.json').read_text())
            assert recorded['source_commit'] == identity['source_commit']
            assert recorded['binary_sha256'] == expected_binary
            assert recorded['runner_sha256'] == digest(lane/'run_study.py')
            assert recorded['audit_reuse_sha256'] == digest(audit_reuse.__file__)
            assert recorded['audit_context_sha256'] == digest(audit_context.__file__)
            assert recorded['context_priors_sha256'] == digest(priors)
            assert digest(parent/'runner.py') == frozen['runner_sha256']
            assert digest(parent/'context-priors.tsv') == digest(priors)
            assert recorded['artifacts'] == artifacts
            assert recorded['max_new'] == 2048 and recorded['ctx'] == 49152
            assert recorded['mode'] == 'measurement'
            assert recorded['fixed_depths'] == {'calibrated': global_k}
            expected_settings = {'MEMRA_SPEC_ADAPT': '1', 'MEMRA_SPEC_ADAPT_FLOOR': '1',
                                 'MEMRA_SPEC_CAPMAX': str(cap), 'MEMRA_SPEC_PMIN': '0',
                                 'MEMRA_SPEC_PMIN_INROUND': '0'}
            assert recorded['settings'] == expected_settings
            expected_workload = workloads['families'][family]['heldout-a' if group['cycle'] % 2 == 0 else 'heldout-b']
            assert recorded['workload_sha256'] == expected_workload['sha256']
            assert digest(a.root/'receipts/workloads'/expected_workload['file']) == expected_workload['sha256']
            spec = study/f'{group["receipt_dir"]}.schedule.json'
            depths = study/f'{group["receipt_dir"]}.depths.json'
            assert recorded['schedule_sha256'] == digest(spec)
            assert recorded['fixed_depths_sha256'] == digest(depths)
            assert json.loads(spec.read_text()) == [{'cycle': group['cycle'], 'order': list(order)}]
            assert json.loads(depths.read_text()) == {'calibrated': global_k}
            assert [r['arm'] for r in group['records']] == list(order)
            assert json.loads((parent/'runs.json').read_text()) == group['records']
            run_study.audit_control_ids(parent, group['seed'], ['measured'])
            verified_records = []
            for record in group['records']:
                arm = record['arm']; run = parent/f'{group["seed"]}-{arm}'
                assert record['seed'] == group['seed']
                command = json.loads((parent/f'{group["seed"]}-{arm}.command.json').read_text())
                runtime_arm = f'fixed:{global_k}' if arm == 'calibrated' else arm
                assert Path(command[0]).name == binary.name
                assert Path(command[1]).name == 'target.gguf'
                assert command[2] == 'embedded' if family == 'qwen' else Path(command[2]).name == 'assistant.gguf'
                assert Path(command[3]).name == expected_workload['file']
                assert Path(command[4]).name == run.name
                assert command[5:10] == [runtime_arm, str(group['seed']), '2048', '49152', '0.7']
                assert len(command) == (11 if arm in ('context', 'learned') else 10)
                if arm in ('context', 'learned'):
                    assert command[10].startswith('priors=') and Path(command[10][7:]).name == priors.name
                with (run/'turns.tsv').open() as f:
                    turns = list(csv.DictReader(f, delimiter='\t'))
                assert [int(t['turn']) for t in turns] == list(range(1, 9))
                assert all(int(t['seed']) == group['seed'] for t in turns)
                token_count = 0
                for turn in turns:
                    t = int(turn['turn'])
                    ids = [int(x) for x in (run/f'turn-{t}.output.ids').read_text().split()]
                    assert len(ids) == int(turn['output_tokens'])
                    assert len((run/f'turn-{t}.prompt.ids').read_text().split()) == int(turn['prompt_tokens'])
                    token_count += len(ids)
                    # The last token can be EOS; inspect both forms without altering metrics.
                    suspect = loop_candidate(ids) or loop_candidate(ids[:-1])
                    if suspect:
                        group_loops.append({'arm': arm, 'turn': t, **suspect})
                        summary['loops'].append({'phase': 'heldout', 'family': family,
                                                 'seed': group['seed'], 'cycle': group['cycle'],
                                                 'arm': arm, 'turn': t,
                                                 'excluded_matched_set': excluded, **suspect})
                seconds = sum(float(t['elapsed_s']) for t in turns)
                assert record['tokens'] == token_count
                assert math.isclose(seconds, record['elapsed_s'], abs_tol=1e-6)
                assert math.isclose(token_count/seconds, record['e2e_tok_s'], rel_tol=1e-7)
                reuse = audit_reuse.audit_reuse(run)
                context = audit_context.audit_run(run, arm, cap, priors)
                assert reuse == record['reuse'] and context == record['context_audit']
                verified_records.append(record)
                if excluded:
                    continue
                observed = observations[arm]
                observed['cpu_ns'] += context['controller_cpu_ns']
                observed['seconds'] += seconds
                observed['transitions'] += context['context_transitions']
                pair = context.get('paired_evidence')
                if pair is not None:
                    observed['paired_comparisons'] += pair['paired_comparisons']
                    observed['adoptions'] += pair['adoptions']
                    observed['final_preferences'].append({
                        'seed': group['seed'], **pair['final_preferred_k'],
                    })
                if arm in ('context', 'learned'):
                    with (run/'context-events.tsv').open() as f:
                        events = list(csv.DictReader(f, delimiter='\t'))
                    trials = [e for e in events if e['probe'] == 'true']
                    observed['probe_rounds'] += len(trials)
                    observed['probe_ns'] += sum(int(e['elapsed_ns']) for e in trials)
                for key, val in context['observations'].items():
                    acc = observed['contexts'].setdefault(key, [0, 0, 0])
                    for i, v in enumerate(val): acc[i] += v
            if group_loops:
                observed_exclusions[str(group['cycle'])] = group_loops
                rejection = json.loads((study/f'{group["receipt_dir"]}.loop-rejection.json').read_text())
                assert rejection == {'seed': group['seed'], 'loops': group_loops,
                                     'matched_set_not_scored': True}
            reproduced.append({**group, 'records': verified_records})
        report = matched_report(reproduced, declared_exclusions, observed_exclusions,
                                controller.summarize, annotate=family == 'gemma')
        assert report == json.loads((study/f'{family}-report.json').read_text())
        summary['models'][family] = {'report_reproduced_exactly': True,
                                     'runs': report['runs'], 'turns': report['turns'],
                                     'recorded_runs': 50, 'recorded_turns': 400,
                                    'binary_sha256': expected_binary, 'diagnostics': observations,
                                    'report': report, 'calibration': calibration,
                                    'correctness_turns_reaudited': correctness_turns,
                                    'development_reports_reproduced': True}
    summary['recorded_runs'] = 100
    summary['recorded_timed_turns'] = 800
    summary['scored_runs'] = sum(m['runs'] for m in summary['models'].values())
    summary['scored_timed_turns'] = sum(m['turns'] for m in summary['models'].values())
    summary['performance_verdict_eligible'] = all(l.get('excluded_matched_set', False) for l in summary['loops'])
    if a.check:
        assert json.loads((study/'FINAL-AUDIT.json').read_text()) == summary
    else:
        (study/'FINAL-AUDIT.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps({'reports_reproduced_exactly': True, 'recorded_timed_turns': 800,
                      'scored_timed_turns': summary['scored_timed_turns'],
                      'loop_candidates': len(summary['loops']), 'performance_verdict_eligible': summary['performance_verdict_eligible']}))


if __name__ == '__main__':
    main()
