"""Bank the completed first-iteration development study, excluding unused held-out output."""
import argparse
import json
import shutil
from pathlib import Path
from package_public import archive, digest

SOURCE = 'e1cd38a47c8c36aeef75860f4cc623d5203188fc'
SOURCE_SHA = 'd313e757edbb3b469890526e75522fd7f9893a74d990e9c5c5345bb50b9cd7f0'
COMMON = {'source.json', 'binaries.sha256', 'learner-tests.log', 'control-tests.log',
          'history-tests.log', 'reuse-tests.log', 'clippy.log', 'iteration1-decision.json',
          'experiment/source.json', 'experiment/schedule.json', 'experiment/workloads.lock.json',
          'experiment/calibration-exclusions.json', 'experiment/reuse-index.json'}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,default=Path('/opt/adaptive/receipts/iteration-1'))
    p.add_argument('--out',type=Path,default=Path('/opt/adaptive/receipts/prior-public'))
    a=p.parse_args()
    source=json.loads((a.root/'source.json').read_text())
    assert source['source_commit']==SOURCE and source['runtime_archive_sha256']==SOURCE_SHA
    assert digest(a.root/'runtime-source.tar.gz')==SOURCE_SHA
    for family in ['qwen','gemma']:
        report=json.loads((a.root/f'experiment/{family}-development-report.json').read_text())
        assert report['complete_planned_matrix'] and report['sets']==2
    a.out.mkdir(parents=True,exist_ok=False)
    buckets={k:[] for k in ['qwen','gemma','common']}
    for path in a.root.rglob('*'):
        if not path.is_file():continue
        name=path.relative_to(a.root).as_posix();parts=path.relative_to(a.root).parts
        if len(parts)>1 and parts[0]=='experiment' and parts[1].startswith(('qwen-','gemma-')):
            if '-eval-' in parts[1] or parts[1].endswith('-selected-sets.json') or parts[1].endswith('-report.json') and '-development-' not in parts[1]:
                continue
            buckets[parts[1].split('-')[0]].append(name)
        elif name in COMMON or parts[0] in ['workloads','iteration1-main-runners']:
            buckets['common'].append(name)
    assert COMMON<=set(buckets['common'])
    entries=[archive(a.root,buckets[k],a.out/f'{k}-records.tar.gz') for k in ['qwen','gemma','common']]
    shutil.copyfile(a.root/'runtime-source.tar.gz',a.out/'runtime-source.tar.gz')
    manifest={'schema':1,'archives':entries,'runtime_source':source,
              'scope':'First-iteration calibration, correctness and two complete development sets per model',
              'unused_heldout_outputs_included':False}
    (a.out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'manifest_sha256':digest(a.out/'manifest.json'),'archives':entries},indent=2))


if __name__=='__main__':main()
