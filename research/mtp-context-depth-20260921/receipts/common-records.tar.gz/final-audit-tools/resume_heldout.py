"""Finish the original held-out schedule; retain and exclude entire looping sets."""
import datetime
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT=Path('/opt/adaptive')
LANE=ROOT/'repo/research/mtp-context-depth-20260921'
STUDY=ROOT/'receipts/experiment'
SOURCE='cb2f1783a0818705c5528f5b11cae0b0bc176deb'
sys.path.insert(0,str(LANE))
import controller
from loop_audit import loop_candidate


def save(path, value):
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value,indent=2)+'\n')
    temporary.replace(path)


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def status(**fields):
    save(STUDY/'status.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**fields})


def collect(family, cycle):
    seed=(20295000 if family=='qwen' else 20305000)+cycle
    name=f'{family}-eval-{cycle}'
    records=json.loads((STUDY/name/'runs.json').read_text())
    assert [r['arm'] for r in records]==list(controller.schedule()[cycle])
    loops=[]
    for record in records:
        run=STUDY/name/f'{seed}-{record["arm"]}'
        for turn in range(1,9):
            ids=[int(x) for x in (run/f'turn-{turn}.output.ids').read_text().split()]
            found=loop_candidate(ids) or loop_candidate(ids[:-1])
            if found:loops.append({'arm':record['arm'],'turn':turn,**found})
    if loops:
        save(STUDY/f'{name}.loop-rejection.json',
             {'seed':seed,'loops':loops,'matched_set_not_scored':True})
    return {'cycle':cycle,'seed':seed,'receipt_dir':name,'records':records},loops


def main():
    os.environ.update(
        PATH='/root/.cargo/bin:/usr/local/cuda-13.1/bin:'+os.environ['PATH'],
        LD_LIBRARY_PATH='/usr/local/cuda-13.1/lib64:'+os.environ.get('LD_LIBRARY_PATH',''),
        TMPDIR=str(ROOT/'tmp'))
    frozen=json.loads((STUDY/'heldout-freeze.json').read_text())
    assert frozen['source_commit']==SOURCE
    assert frozen['runner_sha256']==digest(LANE/'run_study.py')
    assert frozen['controller_sha256']==digest(LANE/'controller.py')
    assert frozen['workloads_sha256']==digest(ROOT/'receipts/workloads/workloads.lock.json')
    for family in ('qwen','gemma'):
        assert frozen['priors_sha256'][family]==digest(STUDY/f'{family}-priors.tsv')
    for line in (ROOT/'receipts/binaries.sha256').read_text().splitlines():
        sha,path=line.split(maxsplit=1)
        assert digest(ROOT/'target/release'/Path(path).name)==sha
    groups=[collect('gemma',i)[0] for i in range(5)]
    rejected={str(i):collect('gemma',i)[1] for i in range(5) if collect('gemma',i)[1]}
    assert set(rejected)=={'4'}
    save(STUDY/'heldout-continuation.json',{
        'source_commit':SOURCE,'orchestrator_sha256':digest(Path(__file__)),
        'recorded_before_remaining_runs_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'reason':'Verified exact *10 repetition in fixed K=4, turn 8, seed 20305004.',
        'rule':'Retain all original runs; exclude every policy in a flagged matched set.',
        'remaining_cycles':[5,6,7,8,9],'replacement_seeds':[],
        'policy_and_inputs_changed':False,'known_exclusions':rejected})
    save(STUDY/'gemma-selected-sets.json',groups)
    for cycle in range(5,10):
        name=f'gemma-eval-{cycle}'
        order=list(controller.schedule()[cycle])
        schedule=STUDY/f'{name}.schedule.json'
        depths=STUDY/f'{name}.depths.json'
        save(schedule,[{'cycle':cycle,'order':order}])
        save(depths,{'calibrated':4})
        workload='heldout-a' if cycle%2==0 else 'heldout-b'
        cmd=[sys.executable,str(LANE/'run_study.py'),'--family','gemma',
             '--binary',str(ROOT/'target/release/gemma-depth-study'),
             '--target',str(ROOT/'models/gemma/target.gguf'),
             '--draft',str(ROOT/'models/gemma/assistant.gguf'),
             '--workload',str(ROOT/f'receipts/workloads/gemma-{workload}.txt'),
             '--out',str(STUDY/name),'--lock','/tmp/memra-gpu.lock',
             '--max-new','2048','--ctx','49152','--seed','20305000',
             '--artifact-manifest',str(ROOT/'models/gemma/artifacts.lock.json'),
             '--source-commit',SOURCE,'--schedule',str(schedule),'--fixed-depths',str(depths),
             '--priors',str(STUDY/'gemma-priors.tsv')]
        status(state='running',family='gemma',phase='eval',cycle=cycle,receipt_dir=name)
        with (STUDY/f'{name}.driver.log').open('w') as log:
            subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
        group,loops=collect('gemma',cycle)
        groups.append(group)
        if loops:rejected[str(cycle)]=loops
        save(STUDY/'gemma-selected-sets.json',groups)
        save(STUDY/'heldout-exclusions.json',{'qwen':{},'gemma':rejected})
    included=[g for g in groups if str(g['cycle']) not in rejected]
    report=controller.summarize(included,10)
    report.update(recorded_sets=10,recorded_runs=50,recorded_turns=400,
                  original_schedule_completed=True,excluded_cycles=[int(c) for c in rejected])
    save(STUDY/'gemma-report.json',report)
    save(STUDY/'DONE.json',{'families':['qwen','gemma'],'sets_each':10})
    status(state='complete',recorded_runs=100,scored_runs=50+len(included)*5,
           exclusions={'gemma':[int(c) for c in rejected]})


if __name__=='__main__':
    code=0
    try:
        main()
    except BaseException as error:
        code=1
        status(state='failed',error_type=type(error).__name__,error=str(error))
        raise
    finally:
        (ROOT/'receipts/pipeline.exit').write_text(str(code)+'\n')
