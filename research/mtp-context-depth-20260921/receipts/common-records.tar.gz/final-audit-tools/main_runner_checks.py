"""Exercise the ordinary native runners after scored work, on the recorded source."""
import ast
import argparse
import fcntl
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

ROOT=Path('/opt/adaptive')
OUT=ROOT/'receipts/main-runners'


def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def main():
    global OUT
    parser=argparse.ArgumentParser()
    parser.add_argument('--development-check',action='store_true')
    args=parser.parse_args()
    if args.development_check:
        OUT=ROOT/'receipts/iteration1-main-runners'
        for family in ['qwen','gemma']:
            report=json.loads((ROOT/f'receipts/experiment/{family}-development-report.json').read_text())
            assert report['complete_planned_matrix'] and report['sets']==2
    else:
        assert (ROOT/'receipts/experiment/DONE.json').exists()
    OUT.mkdir(exist_ok=False)
    lock=open('/tmp/memra-gpu.lock','a')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    env=os.environ.copy()
    for k in list(env):
        if k.startswith('MEMRA_'):del env[k]
    env.update(PATH='/root/.cargo/bin:/usr/local/cuda-13.1/bin:'+env['PATH'],
               LD_LIBRARY_PATH='/usr/local/cuda-13.1/lib64:'+env.get('LD_LIBRARY_PATH',''),
               CARGO_TARGET_DIR=str(ROOT/'target'),CARGO_BUILD_JOBS='4',
               MEMRA_CUDA_ARCH='120a',TMPDIR=str(ROOT/'tmp'))
    bins=ROOT/'target/release'
    cmd=['cargo','build','--locked','--release','-p','memra-engine',
         '--bin','kernel-check','--bin','run-gen','--bin','run-spec','--bin','gemma-spec-session-gate']
    with (OUT/'build.log').open('w') as log:
        subprocess.run(cmd,cwd=ROOT/'repo',env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
    env.pop('MEMRA_CUDA_ARCH')
    records=[]
    def run(name, command, extra=None, timeout=900):
        selected={**env,**(extra or {})}
        (OUT/f'{name}.command.json').write_text(json.dumps({'argv':command,'settings':extra or {}},indent=2)+'\n')
        with (OUT/f'{name}.log').open('w') as log:
            result=subprocess.run(command,cwd=ROOT/'repo',env=selected,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
        text=(OUT/f'{name}.log').read_text(errors='replace')
        records.append({'name':name,'returncode':result.returncode,'binary_sha256':digest(Path(command[0]))})
        (OUT/'status.json').write_text(json.dumps({'checks':records},indent=2)+'\n')
        if result.returncode:raise RuntimeError(f'{name} failed; inspect its raw log')
        return text
    text=run('kernel-check',[str(bins/'kernel-check'),str(ROOT/'models/qwen/target.gguf')])
    if 'ALL GREEN (' not in text:raise RuntimeError('Kernel check did not report complete success')
    prompt=('Explain how a durable work queue can retry a task after a worker crash without '
            'applying the same operation twice. Describe the state transitions and show a short '
            'Python function that deduplicates events by a stable key before updating a counter.')
    for family in ['qwen','gemma']:
        text=run(f'{family}-run-gen',[str(bins/'run-gen'),str(ROOT/f'models/{family}/target.gguf'),'--prompt',prompt],
                 {'MEMRA_CHAT':'1','MEMRA_NGEN':'64'})
        if not re.search(r'prefill argmax=.*\bMATCH\b',text) or 'MISMATCH-STRUCTURED' in text:
            raise RuntimeError(f'{family} prefill/decode gate did not pass')
        if family=='gemma':
            line=next(x for x in text.splitlines() if x.startswith('prompt tokens:'))
            ids=ast.literal_eval(line.split(':',1)[1].strip())
            assert ids and all(type(i) is int and i>=0 for i in ids)
            for k in [1,3,5]:
                gate=run(f'gemma-session-k{k}',[str(bins/'gemma-spec-session-gate'),str(ROOT/'models/gemma/target.gguf'),*map(str,ids)],
                         {'MEMRA_DRAFT':str(ROOT/'models/gemma/assistant.gguf'),'MEMRA_SPEC':str(k),'MEMRA_NGEN':'64'})
                if 'FAIL:' in gate or 'gate2' not in gate:
                    raise RuntimeError('Gemma session/plain gate did not pass')
                widths=re.findall(r'w=\d+: \d+ bursts, (\d+) toks',gate)
                if len(widths)!=5 or any(int(n)<64 for n in widths):
                    raise RuntimeError('Gemma boundary gate did not emit its full requested token tape')
                reference=re.search(r'references: plain (\d+) toks, one-shot (\d+) toks',gate)
                checked=re.findall(r'gate2 w=\d+: session == plain \((\d+) toks\)',gate)
                if not reference or min(map(int,reference.groups()))<64 or len(checked)!=5 or any(int(n)<64 for n in checked):
                    raise RuntimeError('Gemma plain reference or comparison was truncated')
    for shape in ['short','long']:
        if shape=='short':text_prompt=prompt
        else:text_prompt=(ROOT/'receipts/workloads/qwen-calibration-a.txt').read_text().split('\n---TURN---\n')[0]
        file=OUT/f'qwen-{shape}.prompt.txt';file.write_text(text_prompt)
        text=run(f'qwen-run-spec-{shape}',[str(bins/'run-spec'),str(ROOT/'models/qwen/target.gguf')],
                 {'MEMRA_PROMPT_FILE':str(file),'MEMRA_CHAT':'1','MEMRA_NGEN':'64'})
        if '=== SELF-CONSISTENCY PASS ===' not in text or text.count('PASS (identical to plain target)')!=8:
            raise RuntimeError('Qwen K=1..8 did not pass plain-target identity')
    record={'status':'passed','source_commit':json.loads((ROOT/'source.json').read_text())['source_commit'],
            'checks':records,'scope':'native kernel and main-runner correctness; not production or HTTP admission'}
    (OUT/'DONE.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record))


if __name__=='__main__':main()
