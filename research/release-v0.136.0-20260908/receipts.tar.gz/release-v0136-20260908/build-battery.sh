#!/bin/bash
set -euo pipefail
export PATH=/root/.cargo/bin:$PATH CARGO_TARGET_DIR=/root/target MEMRA_CUDA_ARCH=120a MEMRA_GPU_LOCK=/tmp/memra-gpu.lock
cd /root/wt-release-v0136-20260908
out=/root/release-v0136-20260908
echo $$ > "$out/build-battery.pid"
trap 'echo $? > "$out/build-battery.exit"' EXIT
exec 9>/tmp/memra-gpu.lock
flock -n 9
apps=$(nvidia-smi --query-compute-apps=pid,process_name --format=csv,noheader)
printf '%s\n' "$apps" > "$out/gpu-before.txt"
[ -z "$apps" ] || exit 90
git -c safe.directory='*' rev-parse HEAD > "$out/candidate.sha"
cargo build --release --bins > "$out/build.log" 2>&1
sha256sum /root/target/release/{memra-server,kernel-check,run-spec,argmax-margin-probe} > "$out/binaries.sha256"
[ -z "$(nvidia-smi --query-compute-apps=pid,process_name --format=csv,noheader)" ] || exit 91
bash -x tools/release-battery.sh > "$out/battery-full.log" 2>&1
bash tools/release-guard.sh v0.136.0 > "$out/guard.log" 2>&1
