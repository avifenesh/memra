import fcntl, hashlib, json, os, pathlib, re, subprocess, time, urllib.request
out=pathlib.Path('/root/release-v0136-20260908')
(out/'sampled.pid').write_text(str(os.getpid()))
lock=open('/tmp/memra-gpu.lock','w'); fcntl.flock(lock,fcntl.LOCK_EX)
assert (out/'build-battery.exit').read_text().strip()=='0', 'release battery did not pass'
apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,process_name','--format=csv,noheader'],text=True).strip()
assert not apps, apps
(out/'sampled-gpu-before.txt').write_text(apps+'\n')
metadata='''[models."qwen/qwen3.8-27b"]
default_temperature = 1.0
default_top_p = 0.95
default_top_k = 20
default_min_p = 0.0
default_presence_penalty = 0.0
default_repetition_penalty = 1.0
[models."qwen/qwen3.8-27b".non_thinking_sampling]
temperature = 0.7
top_p = 0.8
top_k = 20
presence_penalty = 1.5
'''
(out/'models.toml').write_text(metadata)
env=os.environ.copy(); env.update({
'MEMRA_ADDR':'127.0.0.1:45136','MEMRA_MODELS':'qwen/qwen3.8-27b=/data/ai-ml/hf-models/qwen38-27b-nvfp4-mtp/Qwen3.8-27B-NVFP4-Q5K-mtp.gguf',
'MEMRA_MODEL_METADATA':str(out/'models.toml'),
'MEMRA_CTX':'32768','MEMRA_MAX_SESSIONS':'1','MEMRA_PREFIX_CACHE_MB':'1024','MEMRA_COMPAT':'openai',
'MEMRA_DSPARK_SPEC':'1','MEMRA_DSPARK_DRAFT':'/data/qual/models/q38-dflash2',
'MEMRA_FRSPEC_TRIM':'/data/qual/models/q38-gguf/q38-ranks-sxc32768.gguf.txt',
'MEMRA_PRIME_CHUNK':'1024','MEMRA_REUSE_POOL_GLOBAL_CAP':'1'})
(out/'sampled-profile.json').write_text(json.dumps({k:v for k,v in env.items() if k.startswith('MEMRA_')},indent=2)+'\n')
log=open(out/'sampled-server.log','w')
server=subprocess.Popen(['/root/target/release/memra-server'],cwd='/root/wt-release-v0136-20260908',env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'sampled-server.pid').write_text(str(server.pid))
result={'result':'FAIL'}
try:
 for _ in range(240):
  assert server.poll() is None, 'server exited during boot'
  try:
   with urllib.request.urlopen('http://127.0.0.1:45136/readyz',timeout=2) as r:
    if r.status==200: break
  except Exception: pass
  time.sleep(1)
 else: raise RuntimeError('readiness timeout')
 req={'model':'qwen/qwen3.8-27b','messages':[{'role':'user','content':'Explain how a hash table handles collisions, with a small worked example and the tradeoffs of chaining and open addressing.'}],'max_tokens':512,'stream':False}
 (out/'sampled-request.json').write_text(json.dumps(req,indent=2)+'\n')
 with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:45136/v1/chat/completions',data=json.dumps(req).encode(),headers={'Content-Type':'application/json'}),timeout=180) as r: data=r.read()
 (out/'sampled-response.json').write_bytes(data)
 response=json.loads(data); assert response.get('choices'), response
 assert response.get('usage',{}).get('completion_tokens',0)>0, response
 time.sleep(1)
 text=(out/'sampled-server.log').read_text()
 routes=[l for l in text.splitlines() if '[dspark-acc]' in l]
 assert any(re.search(r'cum=\d+/[1-9]\d*=',l) for l in routes), 'no dspark engagement receipt'
 faults=[l for l in text.splitlines() if re.search(r'step[- ]OOM|source=oom-replay|CUDA_ERROR|panicked|FATAL|CRITICAL',l)]
 assert not faults, faults[:3]
 result={'result':'PASS','model':req['model'],'sampling':'vendor defaults, no request sampling parameters','usage':response['usage'],'route_receipts':routes,'binary_sha256':hashlib.sha256(pathlib.Path('/root/target/release/memra-server').read_bytes()).hexdigest()}
finally:
 pid=int((out/'sampled-server.pid').read_text()); assert pid==server.pid
 if server.poll() is None: os.kill(pid,15)
 try: server.wait(timeout=60)
 except subprocess.TimeoutExpired: os.kill(pid,9); server.wait(timeout=30)
 log.close()
 (out/'sampled-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
