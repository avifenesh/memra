
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json,select,signal,socket,sys,time,threading
from pathlib import Path
mode=sys.argv[2]
lock=threading.Lock()
active=set()
def log(event, **kw): print(json.dumps(dict(event=event,**kw)),flush=True)
class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def reply(self,data,extra=0):
        self.send_response(200);self.send_header('Content-Length',str(len(data)+extra))
        self.send_header('x-request-id','minted-'+self.headers.get('X-Request-Id',''))
        self.end_headers();self.wfile.write(data);self.wfile.flush()
    def do_GET(self):
        with lock: count=len(active)
        if self.path=='/metrics':
            self.reply(json.dumps(dict(active_sessions=count)).encode(),5 if mode=='bad_metrics' else 0)
        else:
            self.reply(json.dumps(dict(status='ok',worker=dict(generation=0,phase='busy' if count else 'idle'))).encode())
    def do_POST(self):
        p=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        role,wire=p['fixture_role'],p['fixture_wire']
        label=self.headers['X-Request-Id']
        with lock: active.add(label)
        log('request',role=role,id=label)
        try:
            if mode in ('truncated_target','cancel_before_eof','typed_error','finish_first'):
                # Fixture-only rendezvous: the peer is genuinely in flight before
                # the target response. The collector never consumes these files.
                if role=='peer':
                    Path('peer-started').touch()
                    end=time.monotonic()+4
                    while not Path('release-eof').exists() and time.monotonic()<end: time.sleep(.005)
                    if not Path('release-eof').exists(): raise RuntimeError('fixture peer barrier expired')
                elif role=='target':
                    end=time.monotonic()+4
                    while not Path('peer-started').exists() and time.monotonic()<end: time.sleep(.005)
                    if not Path('peer-started').exists(): raise RuntimeError('fixture start barrier expired')
                    if mode in ('cancel_before_eof','typed_error'):
                        data=bytes.fromhex(p['fixture_error']) if mode=='typed_error' else b'data: {'
                        self.reply(data,5)
                        end=time.monotonic()+4
                        while not Path('release-eof').exists() and time.monotonic()<end: time.sleep(.005)
                        if not Path('release-eof').exists(): raise RuntimeError('fixture EOF barrier expired')
                        log('eof_released',id=label,observed_ns=time.monotonic_ns())
                        return
            if role=='target' and mode not in ('finish_first','truncated_target'):
                self.send_response(200);self.send_header('x-request-id','minted-'+label);self.end_headers()
                self.wfile.write(b'data: {');self.wfile.flush()
                end=time.monotonic()+2
                while time.monotonic()<end:
                    if select.select([self.connection],[],[],.01)[0] and self.connection.recv(1,socket.MSG_PEEK)==b'':
                        log('client_eof',id=label)
                        if mode=='leaked_target':
                            log('cleanup_withheld',id=label)
                            time.sleep(.8)
                        break
                return
            if role=='peer': time.sleep(.25)
            if role=='target' and mode=='truncated_target': self.reply(b'data: {',5);return
            data=bytes.fromhex(p['fixture_response'])
            if role=='recovery' and mode=='truncated_recovery': data=b'data: {}\n\n'
            self.reply(data)
        finally:
            with lock: active.discard(label)
            log('retired',id=label)
signal.signal(signal.SIGTERM,lambda *_:sys.exit(0))
with ThreadingHTTPServer(('127.0.0.1',int(sys.argv[1])),Handler) as server:
    print('FIXTURE_READY',flush=True)
    server.serve_forever(poll_interval=.01)
