
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json,os,select,signal,socket,sys,threading,time
from pathlib import Path
sys.path.insert(0,sys.argv[3])
from test_serving_trace import Script
mode,scenario=sys.argv[2],sys.argv[4]
output_lock=threading.Lock()
def log(value):
    with output_lock: print(json.dumps(value),flush=True)
def emit(row):
    with output_lock: os.write(1,b'[request-lifecycle] '+json.dumps(row,separators=(',',':')).encode()+b'\n')
class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def do_GET(self):
        data=b'{"status":"ok","models":["gate"],"worker":{"generation":7}}'
        self.send_response(200);self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    def do_POST(self):
        p=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        role=p['fixture_role']; label=self.headers['X-Request-Id']; key=self.headers.get('x-memra-trace-id')
        log(dict(event='HTTP',role=role,key=key,id=label))
        if role=='peer':
            Path('peer-started').touch()
            end=time.monotonic()+6
            while not Path('release-peer').exists() and time.monotonic()<end: time.sleep(.005)
        if role!='target':
            data=bytes.fromhex(p['fixture_response'])
            self.send_response(200);self.send_header('x-request-id','minted-'+label)
            self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
        end=time.monotonic()+4
        while not Path('peer-started').exists() and time.monotonic()<end: time.sleep(.005)
        s=Script(pid=os.getpid());s.bind(key,'minted-target')
        if mode=='foreign_model':
            for row in s.rows:
                if row['model'] is not None:row['model']='other'
        for row in s.rows:
            if mode=='false_prefix' and row['event']=='worker_bound':continue
            if mode=='no_phase' and row['event']=='queued':continue
            emit(row)
        def add(event,**kwargs):s.add(event,**kwargs);emit(s.rows[-1])
        if scenario!='cancel_queued':
            self.send_response(200);self.send_header('x-request-id','minted-target');self.end_headers()
        if mode=='fragmented_error':
            data=bytes.fromhex(p['fixture_error'])
            for piece in (data[:11],data[11:37],data[37:]):self.wfile.write(piece);self.wfile.flush();time.sleep(.01)
            end=time.monotonic()+4
            while not Path('error-observed').exists() and time.monotonic()<end:time.sleep(.005)
            if not Path('error-observed').exists():raise RuntimeError('error observer barrier expired')
        if mode!='no_phase':
            if scenario=='cancel_prime':s.quantum_start();emit(s.rows[-1])
            elif scenario=='cancel_decode':add('decode_start',phase='decode')
        if mode=='fast_eof':
            data=bytes.fromhex(p['fixture_response']);self.wfile.write(data);self.wfile.flush()
            add('http_body_eof',http_body='normal_eof');add('http_body_drop',http_body='dropped_after_eof')
            add('trace_end',sequence_valid=False,first_error='trace_ended_without_explicit_retirement')
            Path('target-finished').touch();return
        if scenario!='cancel_queued' and mode!='fragmented_error':self.wfile.write(b'data: {');self.wfile.flush()
        end=time.monotonic()+6
        while time.monotonic()<end:
            if select.select([self.connection],[],[],.01)[0] and self.connection.recv(1,socket.MSG_PEEK)==b'':break
        if mode=='stale_at_drop' and scenario=='cancel_prime':s.quantum_end();emit(s.rows[-1])
        add('http_pending_drop' if scenario=='cancel_queued' else 'http_body_drop',
            http_body='pending_dropped' if scenario=='cancel_queued' else 'dropped_before_eof')
        if scenario=='cancel_prime' and mode not in ('stale_at_drop','no_phase'):
            s.quantum_end(remaining=None,completed=mode!='failed_quantum');emit(s.rows[-1])
        add('receiver_closed',receiver_close_cause='receiver_dropped',observed_close_cause='receiver_dropped')
        if mode!='missing_retirement':
            add('retired',retirement='aborted',retirement_site='WorkerQueue' if scenario=='cancel_queued' else 'ActiveSession')
            add('trace_end')
        Path('target-finished').touch()
signal.signal(signal.SIGTERM,lambda *_:sys.exit(0))
if mode=='preexisting_key':
    previous=Script(pid=os.getpid());previous.bind('0123456789abcdef0123456789abcdef','minted-previous')
    for row in previous.rows:emit(row)
with ThreadingHTTPServer(('127.0.0.1',int(sys.argv[1])),Handler) as server:
    print('SYNTHETIC_PHASE_PRODUCER_READY',flush=True)
    if mode=='partial_before_launch':os.write(1,b'[request-lifecycle] {"schema":')
    server.serve_forever(poll_interval=.01)
