//! Experimental, session-owned depth selection from measured committed tokens / time.
//!
//! This is a new Memra policy, not a reproduction of the unavailable H/C/D prototype.
//! Each depth is held for a block of complete rounds. All depths are measured before
//! exploitation; periodic round-robin probes allow recovery after a workload change.
//! Timing and token commitment stay with the caller. No model, sampler, or CUDA state
//! is owned here, and no environment variable enables this policy in the server.

use std::time::Duration;

#[derive(Clone, Debug)]
pub struct DepthStats {
    pub depth: usize,
    pub rounds: u64,
    pub tokens: u64,
    pub elapsed: Duration,
    pub blocks: u64,
    pub ewma_tokens_per_second: Option<f64>,
}

#[derive(Clone, Debug)]
pub struct LearnedDepth {
    stats: Vec<DepthStats>,
    current: usize,
    rounds_per_block: u64,
    exploit_blocks: u64,
    blocks_since_probe: u64,
    next_probe: usize,
    block_rounds: u64,
    block_tokens: u64,
    block_time: Duration,
    switches: u64,
}

impl LearnedDepth {
    pub fn new(
        depths: Vec<usize>,
        initial: usize,
        rounds_per_block: u64,
        exploit_blocks: u64,
    ) -> Result<Self, &'static str> {
        if depths.is_empty() || depths.contains(&0) || depths.windows(2).any(|w| w[0] >= w[1]) {
            return Err("depths must be positive, unique, and ascending");
        }
        let current = depths
            .iter()
            .position(|&d| d == initial)
            .ok_or("initial depth must be in the candidate set")?;
        if rounds_per_block == 0 || exploit_blocks == 0 {
            return Err("block size and exploitation interval must be positive");
        }
        Ok(Self {
            stats: depths
                .into_iter()
                .map(|depth| DepthStats {
                    depth,
                    rounds: 0,
                    tokens: 0,
                    elapsed: Duration::ZERO,
                    blocks: 0,
                    ewma_tokens_per_second: None,
                })
                .collect(),
            current,
            rounds_per_block,
            exploit_blocks,
            blocks_since_probe: 0,
            next_probe: 0,
            block_rounds: 0,
            block_tokens: 0,
            block_time: Duration::ZERO,
            switches: 0,
        })
    }

    pub fn depth(&self) -> usize {
        self.stats[self.current].depth
    }

    pub fn stats(&self) -> &[DepthStats] {
        &self.stats
    }

    pub fn switches(&self) -> u64 {
        self.switches
    }

    /// Record one successful, untruncated round at the selected depth. Failed or
    /// terminally truncated rounds are not observations. Their cost still belongs
    /// in the caller's end-to-end benchmark denominator.
    pub fn observe(
        &mut self,
        depth: usize,
        committed: usize,
        elapsed: Duration,
    ) -> Result<(), &'static str> {
        if depth != self.depth() {
            return Err("observation depth differs from the selected depth");
        }
        if committed == 0 || committed > depth || elapsed.is_zero() {
            return Err("observation needs 1..=depth committed tokens and positive time");
        }
        let stat = &mut self.stats[self.current];
        stat.rounds += 1;
        stat.tokens += committed as u64;
        stat.elapsed += elapsed;
        self.block_rounds += 1;
        self.block_tokens += committed as u64;
        self.block_time += elapsed;
        if self.block_rounds < self.rounds_per_block {
            return Ok(());
        }
        // Pool tokens and elapsed time before division; averaging round rates
        // overweights short rounds and is the wrong optimization objective.
        let rate = self.block_tokens as f64 / self.block_time.as_secs_f64();
        stat.ewma_tokens_per_second = Some(match stat.ewma_tokens_per_second {
            Some(old) => 0.5 * old + 0.5 * rate,
            None => rate,
        });
        stat.blocks += 1;
        self.block_rounds = 0;
        self.block_tokens = 0;
        self.block_time = Duration::ZERO;

        let next = if let Some(unseen) = self.stats.iter().position(|s| s.blocks == 0) {
            unseen
        } else if self.blocks_since_probe >= self.exploit_blocks {
            let probe = self.next_probe;
            self.next_probe = (self.next_probe + 1) % self.stats.len();
            self.blocks_since_probe = 0;
            probe
        } else {
            self.blocks_since_probe += 1;
            let mut best = self.current;
            for (index, candidate) in self.stats.iter().enumerate() {
                if candidate.ewma_tokens_per_second.unwrap()
                    > self.stats[best].ewma_tokens_per_second.unwrap() * 1.01
                {
                    best = index;
                }
            }
            best
        };
        self.switches += u64::from(next != self.current);
        self.current = next;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn refuses_bad_configuration_and_observations_without_mutation() {
        for depths in [vec![], vec![0, 2], vec![3, 3], vec![4, 3]] {
            assert!(LearnedDepth::new(depths, 3, 2, 8).is_err());
        }
        assert!(LearnedDepth::new(vec![3, 4], 8, 2, 8).is_err());
        assert!(LearnedDepth::new(vec![3, 4], 3, 0, 8).is_err());
        let mut policy = LearnedDepth::new(vec![3, 4], 3, 2, 8).unwrap();
        for (depth, tokens, time) in [
            (4, 2, Duration::from_millis(1)),
            (3, 0, Duration::from_millis(1)),
            (3, 4, Duration::from_millis(1)),
            (3, 2, Duration::ZERO),
        ] {
            assert!(policy.observe(depth, tokens, time).is_err());
        }
        assert_eq!(policy.stats()[0].rounds, 0);
        assert_eq!(policy.depth(), 3);
    }

    #[test]
    fn ranks_throughput_instead_of_acceptance_or_mean_round_rates() {
        let mut policy = LearnedDepth::new(vec![3, 8], 3, 2, 8).unwrap();
        policy.observe(3, 1, Duration::from_millis(1)).unwrap();
        policy.observe(3, 1, Duration::from_millis(99)).unwrap();
        assert_eq!(policy.stats()[0].ewma_tokens_per_second, Some(20.0));
        assert_eq!(policy.depth(), 8);
        // The deeper round commits more tokens, but at only 10 tok/s.
        policy.observe(8, 8, Duration::from_millis(800)).unwrap();
        policy.observe(8, 8, Duration::from_millis(800)).unwrap();
        assert_eq!(policy.depth(), 3);
    }

    #[test]
    fn explores_every_depth_and_tracks_a_changed_workload_in_both_directions() {
        let mut policy = LearnedDepth::new(vec![3, 4, 6, 8], 8, 2, 3).unwrap();
        for best in [8, 3, 6] {
            let mut selections = [0u64; 9];
            for _ in 0..2000 {
                let d = policy.depth();
                selections[d] += 1;
                let millis = if d == best { 10 } else { 100 };
                policy.observe(d, 2, Duration::from_millis(millis)).unwrap();
            }
            assert!(selections[best] > 1000, "did not adapt to depth {best}");
        }
        assert!(policy.stats().iter().all(|s| s.blocks > 1));
        assert!(policy.switches() > 10);
    }

    #[test]
    fn independent_sessions_and_partial_blocks_do_not_share_learning() {
        let mut a = LearnedDepth::new(vec![3, 8], 8, 3, 8).unwrap();
        let b = a.clone();
        a.observe(8, 2, Duration::from_millis(10)).unwrap();
        a.observe(8, 2, Duration::from_millis(10)).unwrap();
        assert_eq!(a.depth(), 8);
        assert_eq!(a.stats()[1].blocks, 0);
        a.observe(8, 2, Duration::from_millis(10)).unwrap();
        assert_eq!(a.depth(), 3);
        assert_eq!(b.depth(), 8);
        assert_eq!(b.stats()[1].rounds, 0);
    }
}
