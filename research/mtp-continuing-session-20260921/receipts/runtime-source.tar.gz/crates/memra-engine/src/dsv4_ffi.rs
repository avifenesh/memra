//! FFI declarations for the DeepSeek-V4-Flash GPU kernels (cu/dsv4_gpu.cu, lane 4).
//!
//! House pattern (mmq_ffi kind): C-ABI host launchers in the libmemra_mmq.a static lib,
//! returning 0 ok / 10000+cudaError / 20000+heuristic / 30000+matmul / 4000x contract
//! bands; the stream rides as `*mut c_void` (`stream.cu_stream()`).

use std::os::raw::c_void;

unsafe extern "C" {
    pub fn memra_dsv4_replay_compressor_emit(
        pending_kv: *mut f32,
        pending_score: *mut f32,
        ape: *const f32,
        emit: *mut f32,
        norm: *const f32,
        cs: *const f32,
        store: *mut f32,
        shift: *mut f32,
        pos: *const i32,
        ratio: i32,
        d: i32,
        latent: i32,
        overlap: i32,
        rotate: i32,
        clamp_only: i32,
        rd: i32,
        row0: i32,
        eps: f32,
        hadamard_scale: f32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_sample_device_replay(
        logits: *const f32,
        values: *mut f32,
        keys0: *mut u64,
        keys1: *mut u64,
        prefix: *mut f64,
        blocks: *mut f64,
        counts: *const i32,
        result: *mut u32,
        n: i32,
        k: i32,
        temperature: f64,
        top_p: f64,
        uniform: *const f64,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_replay_input(
        input: *const u64,
        token: *mut i32,
        pos: *mut i32,
        slot: *mut i32,
        window: i32,
        counter: *mut u64,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_replay_tick(counter: *mut u64, stream: *mut c_void) -> i32;
    pub fn memra_dsv4_replay_capture_begin(graph: *mut *mut c_void, stream: *mut c_void) -> i32;
    pub fn memra_dsv4_replay_capture_end(
        graph: *mut c_void,
        executable: *mut *mut c_void,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_replay_launch(executable: *mut c_void, stream: *mut c_void) -> i32;
    pub fn memra_dsv4_replay_abort(stream: *mut c_void) -> i32;
    pub fn memra_dsv4_replay_census(graph: *mut c_void, out: *mut u64) -> i32;
    pub fn memra_dsv4_replay_dump(graph: *mut c_void, path: *const std::ffi::c_char) -> i32;
    pub fn memra_dsv4_replay_destroy(
        graph: *mut c_void,
        executable: *mut c_void,
        stream: *mut c_void,
    ) -> i32;

    pub fn memra_dsv4_replay_copy_row(
        src: *const f32,
        dst: *mut f32,
        pos: *const i32,
        width: i32,
        ratio: i32,
        offset: i32,
        emitted: i32,
        stream: *mut c_void,
    ) -> i32;

    pub fn memra_dsv4_replay_indices(
        idx: *mut i32,
        pos: *const i32,
        win: i32,
        ratio: i32,
        cap: i32,
        stride: i32,
        trans_base: i32,
        fine: i32,
        topk: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_replay_indexer(
        q: *const f32,
        kv: *const f32,
        weights: *const f32,
        scale: f32,
        score: *mut f32,
        idx_tail: *mut i32,
        pos: *const i32,
        heads: i32,
        hd: i32,
        nb_max: i32,
        ratio: i32,
        topk: i32,
        win: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_replay_attention(
        q: *const f32,
        kv: *const f32,
        idx: *const i32,
        sink: *const f32,
        score: *mut f32,
        eval: *mut f32,
        den: *mut f32,
        out: *mut f32,
        pos: *const i32,
        heads: i32,
        hd: i32,
        slots_max: i32,
        stride: i32,
        scale: f32,
        win: i32,
        ratio: i32,
        topk: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_sample_device(
        logits: *const f32,
        values: *mut f32,
        keys0: *mut u64,
        keys1: *mut u64,
        prefix: *mut f64,
        blocks: *mut f64,
        counts: *const i32,
        result: *mut u32,
        n: i32,
        k: i32,
        temperature: f64,
        top_p: f64,
        uniform: f64,
        repeat: f32,
        freq: f32,
        present: f32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_sink_scores_tiled_init() -> i32;
    pub fn memra_dsv4_sink_attn_dec_mq_f32acc_tiled(
        q: *const f32,
        kv: *const f32,
        idxs: *const i32,
        sink: *const f32,
        scores: *mut f32,
        evals: *mut f32,
        den: *mut f32,
        o: *mut f32,
        nq: i32,
        heads: i32,
        hd: i32,
        slots: i32,
        idx_stride: i32,
        scale: f32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_grouped_routes_partition(
        selected: *const i32,
        weights: *const f32,
        scale2: *const f32,
        counts: *mut i32,
        offsets: *mut i32,
        expert_ids: *mut i32,
        pairs: *mut i32,
        tokens: *mut i32,
        route_weights: *mut f32,
        macro1: *mut f32,
        macro2: *mut f32,
        macro3: *mut f32,
        status: *mut i32,
        slots: i32,
        global_experts: i32,
        first: i32,
        expert_count: i32,
        topk: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_grouped_routes(
        selected: *const i32,
        weights: *const f32,
        scale2: *const f32,
        counts: *mut i32,
        offsets: *mut i32,
        expert_ids: *mut i32,
        pairs: *mut i32,
        tokens: *mut i32,
        route_weights: *mut f32,
        macro1: *mut f32,
        macro2: *mut f32,
        macro3: *mut f32,
        status: *mut i32,
        slots: i32,
        experts: i32,
        topk: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_fp4_gemm_sel_ep(
        a: *const c_void,
        a_scales: *const f32,
        weights: *const c_void,
        scales: *const c_void,
        scale2: *const f32,
        selected: *const i32,
        projection: i32,
        per_slot: i32,
        kind: i32,
        out: *mut f32,
        slots: i32,
        n: i32,
        k: i32,
        weight_stride: i64,
        scale_stride: i64,
        a_group: i32,
        reduction: i32,
        expert_first: i32,
        expert_count: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_ep_merge_slots(
        local: *mut f32,
        peer: *const f32,
        selected: *const i32,
        slots: i32,
        width: i32,
        peer_first: i32,
        peer_count: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_topk_idx_numeric(
        score: *const f32,
        nb: i32,
        kk: i32,
        win: i32,
        idx_out: *mut i32,
        stream: *mut c_void,
    ) -> i32;
    /// Gate-only exact radix-cut twin for the common t=1, K=512 path. The scratch planes are
    /// persistent workspace owned by the decode state; no score/index host round trip exists.
    pub fn memra_dsv4_topk_idx_radix_m1(
        score: *const f32,
        nb: i32,
        kk: i32,
        win: i32,
        idx_out: *mut i32,
        radix_keys: *mut u64,
        radix_candidates: *mut u64,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_c4_gather(
        device: *const f32,
        host: *const f32,
        indices: *const i32,
        out: *mut f32,
        out_indices: *mut i32,
        nq: i32,
        slots: i32,
        stride: i32,
        live_rows: i32,
        logical_transient: i32,
        transient_rows: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_c4_recent_write(
        source: *const f32,
        recent: *mut f32,
        tags: *mut i32,
        first_row: i32,
        rows: i32,
        cache_rows: i32,
        reset: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_c4_gather_recent(
        device: *const f32,
        host: *const f32,
        indices: *const i32,
        out: *mut f32,
        out_indices: *mut i32,
        nq: i32,
        slots: i32,
        stride: i32,
        live_rows: i32,
        logical_transient: i32,
        transient_rows: i32,
        recent: *const f32,
        tags: *const i32,
        cache_rows: i32,
        stream: *mut c_void,
    ) -> i32;
    // iteration-5 F-itemisation instrument (see dsv4_gpu.rs Dsv4Phase).
    pub fn memra_dsv4_nvtx_push(name: *const std::os::raw::c_char) -> i32;
    pub fn memra_dsv4_nvtx_pop() -> i32;
    pub fn memra_dsv4_nvfp4_deq_bf16(
        w: *const c_void,
        sc: *const c_void,
        scale2: f32,
        rows: i32,
        cols: i32,
        out: *mut c_void,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_mxfp4_deq_bf16(
        w: *const c_void,
        sc: *const c_void,
        rows: i32,
        cols: i32,
        out: *mut c_void,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_cvt_bf16(x: *const f32, o: *mut c_void, n: i64, stream: *mut c_void) -> i32;
    pub fn memra_dsv4_embed_rows(
        table_bf16: *const c_void,
        ids: *const i32,
        out: *mut f32,
        n_ids: i32,
        ncols: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_gather_bf16(
        x: *const c_void,
        idx: *const i32,
        out: *mut c_void,
        g: i32,
        d: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_scatter_add(
        y: *mut f32,
        contrib: *const f32,
        idx: *const i32,
        g: i32,
        d: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_add_inplace(y: *mut f32, x: *const f32, n: i64, stream: *mut c_void) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_fp8_gather_half(
        codes: *const c_void,
        scales: *const f32,
        row_ids: *const i32,
        out: *mut c_void,
        row_scale: *mut f32,
        row_status: *mut i32,
        rows: i32,
        cols: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_scale_rows(
        y: *mut f32,
        scale: *const f32,
        rows: i32,
        cols: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_take_cols(
        src: *const f32,
        dst: *mut f32,
        s: i32,
        n: i32,
        stride: i64,
        col_off: i64,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_place_cols(
        src: *const f32,
        dst: *mut f32,
        s: i32,
        n: i32,
        stride: i64,
        col_off: i64,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_repeat_hc(
        e: *const f32,
        h: *mut f32,
        s: i32,
        hc: i32,
        d: i32,
        stream: *mut c_void,
    ) -> i32;
    /// iteration-5: row-blocked twin of `memra_dsv4_dots_f32`. Same arithmetic, same
    /// reduction tree, same order -- only the block geometry differs, so it is bit-identical.
    pub fn memra_dsv4_dots_f32_rowblk(
        x: *const f32,
        w: *const c_void,
        w_is_bf16: i32,
        y: *mut f32,
        s: i32,
        k: i32,
        n: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_dots_f32(
        x: *const f32,
        w: *const c_void,
        w_is_bf16: i32,
        y: *mut f32,
        s: i32,
        k: i32,
        n: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_dots_f32acc(
        x: *const f32,
        w: *const c_void,
        w_is_bf16: i32,
        y: *mut f32,
        s: i32,
        k: i32,
        n: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_gemm_bf16(
        w_bf16: *const c_void,
        x_bf16: *const c_void,
        y_f32: *mut f32,
        m: i32,
        n: i32,
        k: i32,
        dev: i32,
        ws: *mut c_void,
        ws_bytes: usize,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_rmsnorm(
        x: *const f32,
        w: *const f32,
        dst: *mut f32,
        rows: i32,
        ncols: i32,
        eps: f32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_rope(
        x: *mut f32,
        n_pos: i32,
        n_vec: i32,
        dim: i32,
        rd: i32,
        cs: *const f32,
        positions: *const i32,
        inverse: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_headrms(x: *mut f32, rows: i32, d: i32, eps: f32, stream: *mut c_void)
    -> i32;
    pub fn memra_dsv4_act_quant(
        x: *mut f32,
        rows: i32,
        stride: i64,
        prefix_len: i32,
        block: i32,
        clamp_only: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_fp4_act_quant(
        x: *mut f32,
        rows: i32,
        stride: i64,
        len: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_hadamard(
        x: *mut f32,
        rows: i32,
        d: i32,
        scale: f32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_compressor_pool(
        kv: *const f32,
        score: *const f32,
        ape: *const f32,
        out: *mut f32,
        nb: i32,
        ratio: i32,
        d: i32,
        latent: i32,
        overlap: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_indexer_score(
        q: *const f32,
        ckv: *const f32,
        w: *const f32,
        wscale: f32,
        score: *mut f32,
        s: i32,
        heads: i32,
        hd: i32,
        nb: i32,
        ratio: i32,
        lim0: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_sink_attn(
        q: *const f32,
        kv: *const f32,
        idxs: *const i32,
        sink: *const f32,
        o: *mut f32,
        s: i32,
        heads: i32,
        hd: i32,
        slots: i32,
        scale: f32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_rowsq_scale(
        x: *const f32,
        mixes: *mut f32,
        s: i32,
        w: i32,
        rows: i32,
        eps: f32,
        stream: *mut c_void,
    ) -> i32;
    /// Roofline probe: read `n_floats` from `x` and discard, `mode` 0 = scalar 32-bit loads
    /// (the shape the old `MEMRA_HC_BW_PROBE` number was taken with), 1 = 128-bit `float4`.
    /// Bench-only (`bw_roofline`); nothing on a serving path calls it.
    pub fn memra_bw_read(
        x: *const f32,
        n_floats: i64,
        sink: *mut f32,
        mode: i32,
        ilp: i32,
        blocks: i32,
        threads: i32,
        stream: *mut c_void,
    ) -> i32;
    /// Roofline probe, scattered form: `nslabs` disjoint slabs of `slab_floats` each, at the
    /// float4 offsets in `off4`. Models the MoE expert read (9 of 288 slabs per layer out of a
    /// pool far larger than any cache) against the contiguous rate.
    pub fn memra_bw_read_slabs(
        x: *const f32,
        off4: *const i64,
        nslabs: i32,
        slab_floats: i64,
        sink: *mut f32,
        blocks: i32,
        threads: i32,
        stream: *mut c_void,
    ) -> i32;
    /// `memra_dsv4_hc_pre_v4` with `rms_norm_zq8_f32`'s epilogue folded in, deleting that launch
    /// (~3.9 us x ~79 per token). Bit-identical by an index coincidence spelled out at the kernel:
    /// at BLOCK 1024 and d 4096 both passes of the norm own exactly the four elements the combine
    /// tail already holds, in the same order, so the reduction tree and every expression replay
    /// unchanged. Refuses any other width rather than reordering the reduction quietly.
    #[allow(clippy::too_many_arguments)]
    // allow: it is the hc-pre signature plus the norm epilogue's operands; splitting it would hide which buffer belongs to which half
    pub fn memra_dsv4_hc_pre_v4_norm_zq8(
        x: *const f32,
        mixes: *const f32,
        scale: *const f32,
        base: *const f32,
        pre: *mut f32,
        post: *mut f32,
        comb: *mut f32,
        y: *mut f32,
        s: i32,
        hc: i32,
        d: i32,
        iters: i32,
        eps: f32,
        niters: *mut i32,
        block: i32,
        nw: *const f32,
        z: *mut f32,
        out_q: *mut i8,
        out_d: *mut f32,
        norm_eps: f32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_hc_collapse(
        x: *const f32,
        pre: *const f32,
        y: *mut f32,
        s: i32,
        hc: i32,
        d: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_hc_post(
        f: *const f32,
        residual: *const f32,
        post: *const f32,
        comb: *const f32,
        out: *mut f32,
        s: i32,
        hc: i32,
        d: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_act_quant_fp8(
        x: *const f32,
        codes: *mut c_void,
        scales: *mut f32,
        rows: i32,
        kdim: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_fp4_gemm(
        a_codes: *const c_void,
        a_scales: *const f32,
        w: *const c_void,
        wsc: *const c_void,
        scale2: f32,
        kind: i32,
        out: *mut f32,
        g: i32,
        n: i32,
        kdim: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_gather_rows_u8(
        x: *const c_void,
        idx: *const i32,
        out: *mut c_void,
        g: i32,
        row_bytes: i64,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_swiglu(
        gate: *const f32,
        up: *const f32,
        dst: *mut f32,
        rows: i32,
        inter: i32,
        limit: f32,
        wrow: *const f32,
        stream: *mut c_void,
    ) -> i32;
    // ---- lane 8: device-resident decode step (RECEIPTS.md "Lane 8")
    pub fn memra_dsv4_rope_at(
        x: *mut f32,
        n_vec: i32,
        dim: i32,
        rd: i32,
        cs: *const f32,
        pos: i32,
        inverse: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_hc_sinkhorn(
        mixes: *const f32,
        scale: *const f32,
        base: *const f32,
        pre: *mut f32,
        post: *mut f32,
        comb: *mut f32,
        hc: i32,
        iters: i32,
        eps: f32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_hc_head_pre(
        mixes: *const f32,
        scale: *const f32,
        base: *const f32,
        pre: *mut f32,
        hc: i32,
        eps: f32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_route(
        raw: *const f32,
        bias: *const f32,
        tid2eid: *const i32,
        tok: *const i32,
        ne: i32,
        topk: i32,
        route_scale: f32,
        sel: *mut i32,
        selw: *mut f32,
        order: *mut i32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_fp4_gemm_sel(
        a_codes: *const c_void,
        a_scales: *const f32,
        w_base: *const c_void,
        sc_base: *const c_void,
        s2: *const f32,
        sel: *const i32,
        proj: i32,
        a_stride_rows: i32,
        kind: i32,
        out: *mut f32,
        slots: i32,
        n: i32,
        kdim: i32,
        wstride: i64,
        sstride: i64,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_combine_rows(
        contrib: *const f32,
        order: *const i32,
        topk: i32,
        y: *mut f32,
        d: i64,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_build_idx(
        idx: *mut i32,
        pos: i32,
        win: i32,
        nb: i32,
        cap: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_topk_idx(
        score: *const f32,
        nb: i32,
        kk: i32,
        win: i32,
        idx_out: *mut i32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_topk_idx_m(
        score: *const f32,
        s: i32,
        nb: i32,
        topk: i32,
        win: i32,
        idx_out: *mut i32,
        idx_stride: i32,
        pos0: i32,
        ratio: i32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_topk_idx_stream_m(
        score: *const f32,
        s: i32,
        nb: i32,
        topk: i32,
        win: i32,
        idx_out: *mut i32,
        idx_stride: i32,
        work_a: *mut u64,
        work_b: *mut u64,
        work_stride: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_argmax(v: *const f32, n: i64, out: *mut i32, stream: *mut c_void) -> i32;
    /// iteration-5: `dst[0..cols) = src[idx[slot] * cols ..]`, the index read on the
    /// DEVICE so the DSpark markov chain needs no host round trip between steps.
    pub fn memra_dsv4_gather_row_by_idx(
        src: *const f32,
        idx: *const i32,
        slot: i32,
        dst: *mut f32,
        cols: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_gemv_bf16(
        w_bf16: *const c_void,
        x_bf16: *const c_void,
        y: *mut f32,
        n: i32,
        k: i32,
        stream: *mut c_void,
    ) -> i32;
    /// iteration-5 FP8 dense arm: as-stored e4m3 codes + host-decoded f32 block scales
    /// (exact pow2). BIT-IDENTICAL to memra_dsv4_gemv_bf16 over the dequant slab by
    /// construction (same value, same accumulation order — see cu header note).
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_gemv_fp8(
        w_codes: *const c_void,
        sc_f32: *const f32,
        sc_cols: i32,
        x_bf16: *const c_void,
        y: *mut f32,
        n: i32,
        k: i32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_sink_attn_dec(
        q: *const f32,
        kv: *const f32,
        idxs: *const i32,
        sink: *const f32,
        scores: *mut f32,
        evals: *mut f32,
        den: *mut f64,
        o: *mut f32,
        heads: i32,
        hd: i32,
        slots: i32,
        scale: f32,
        stream: *mut c_void,
    ) -> i32;

    // ── 0731 re-gate extension rung (MEMRA_DSV4_DOTS_ARM=f32x): f32-accumulation twins
    // of the remaining device-path f64 chains. Same signatures as their f64 twins except
    // sink dec's `den`, which rides a FLOAT view of the caller's f64 workspace (written
    // and read within the one entry point). f64 kernels untouched.
    pub fn memra_dsv4_small_norm_pack_f32_fixed_order(
        x: *mut f32,
        w: *const f32,
        packed: *mut c_void,
        s: i32,
        n: i32,
        eps: f32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_small_hc_f32_fixed_order(
        x: *const f32,
        mixes: *mut f32,
        scale: *const f32,
        base: *const f32,
        pre: *mut f32,
        post: *mut f32,
        comb: *mut f32,
        y: *mut f32,
        s: i32,
        hc: i32,
        d: i32,
        iters: i32,
        eps: f32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_rmsnorm_f32acc(
        x: *const f32,
        w: *const f32,
        dst: *mut f32,
        rows: i32,
        ncols: i32,
        eps: f32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_headrms_f32acc(
        x: *mut f32,
        rows: i32,
        d: i32,
        eps: f32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_rowsq_scale_f32acc(
        x: *const f32,
        mixes: *mut f32,
        s: i32,
        w: i32,
        rows: i32,
        eps: f32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_indexer_score_f32acc(
        q: *const f32,
        ckv: *const f32,
        w: *const f32,
        wscale: f32,
        score: *mut f32,
        s: i32,
        heads: i32,
        hd: i32,
        nb: i32,
        ratio: i32,
        lim0: i32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_indexer_score_tiled(
        q: *const f32,
        ckv: *const f32,
        w: *const f32,
        wscale: f32,
        score: *mut f32,
        s: i32,
        heads: i32,
        hd: i32,
        nb: i32,
        ratio: i32,
        lim0: i32,
        pos0: i32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_indexer_score_f32acc_pos_m(
        q: *const f32,
        ckv: *const f32,
        w: *const f32,
        wscale: f32,
        score: *mut f32,
        s: i32,
        heads: i32,
        hd: i32,
        nb: i32,
        ratio: i32,
        pos0: i32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_sink_attn_dec_f32acc(
        q: *const f32,
        kv: *const f32,
        idxs: *const i32,
        sink: *const f32,
        scores: *mut f32,
        evals: *mut f32,
        den: *mut f32,
        o: *mut f32,
        heads: i32,
        hd: i32,
        slots: i32,
        scale: f32,
        stream: *mut c_void,
    ) -> i32;
    // iteration 3 (GPU DSpark drafter path)
    pub fn memra_dsv4_hc_mean(
        h: *const f32,
        out: *mut f32,
        s: i32,
        hc: i32,
        hidden: i32,
        stream: *mut c_void,
    ) -> i32;
    /// Model-entry stream expand, the inverse of `memra_dsv4_hc_mean`. Added for the
    /// glm5_next trunk (crate::hyper), which drives the whole hc kernel family.
    pub fn memra_dsv4_hc_expand(
        e: *const f32,
        out: *mut f32,
        s: i32,
        hc: i32,
        hidden: i32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_build_idx_redirect(
        idx: *mut i32,
        pos: i32,
        win: i32,
        nb: i32,
        cap: i32,
        pos0: i32,
        trans_base: i32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_build_idx_redirect_m(
        idx: *mut i32,
        pos0: i32,
        s: i32,
        win: i32,
        ratio: i32,
        cap: i32,
        stride: i32,
        trans_base: i32,
        fine: i32,
        stream: *mut c_void,
    ) -> i32;
    /// Window-only redirect builder reading the absolute query position from a
    /// stable device scalar. This is the graph-safe twin for the first one-layer
    /// probe; ratio/compressor layers retain the original host-scalar ABI.
    pub fn memra_dsv4_build_idx_redirect_window_pos(
        idx: *mut i32,
        pos_dev: *const i32,
        win: i32,
        cap: i32,
        trans_base: i32,
        stream: *mut c_void,
    ) -> i32;
    /// Fine-indexer redirect component twin for the gate-only scalar probe.
    /// Both `pos_dev` and `nb_dev` are persistent device scalars; the full
    /// compressor/indexer layer still retains the host-state-machine refusal.
    pub fn memra_dsv4_build_idx_redirect_fine_pos(
        idx: *mut i32,
        pos_dev: *const i32,
        nb_dev: *const i32,
        win: i32,
        cap: i32,
        trans_base: i32,
        stream: *mut c_void,
    ) -> i32;

    // ---- iteration 3, rung 4: batched T=k+1 verify twins. Every entry is BIT-EXACT
    // against `m`/`nq` sequential single-position calls of its pinned twin (the design
    // law in cu/dsv4_gpu.cu's batched section): the added dimension only hoists the
    // WEIGHT load, never reorders an accumulation.
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_gemv_bf16_m(
        w_bf16: *const c_void,
        x_bf16: *const c_void,
        y: *mut f32,
        m: i32,
        n: i32,
        k: i32,
        xstride: i32,
        ystride: i32,
        stream: *mut c_void,
    ) -> i32;
    /// FP8 dense arm, batched twin (see memra_dsv4_gemv_fp8).
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_gemv_fp8_m(
        w_codes: *const c_void,
        sc_f32: *const f32,
        sc_cols: i32,
        x_bf16: *const c_void,
        y: *mut f32,
        m: i32,
        n: i32,
        k: i32,
        xstride: i32,
        ystride: i32,
        stream: *mut c_void,
    ) -> i32;
    /// FP8 dense t=1 grouped output projection. The weight rows are grouped
    /// contiguously; each group reads its own activation/output slice while
    /// retaining the ordinary m=1 accumulation and reduction body.
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_gemv_fp8_grouped_m1(
        w_codes: *const c_void,
        sc_f32: *const f32,
        sc_cols: i32,
        x_bf16: *const c_void,
        y: *mut f32,
        groups: i32,
        rows_per_group: i32,
        k: i32,
        x_group_stride: i32,
        y_group_stride: i32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_dots_f32_mrow(
        x: *const f32,
        w: *const c_void,
        w_is_bf16: i32,
        y: *mut f32,
        s: i32,
        k: i32,
        n: i32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_dots_f32acc_mrow(
        x: *const f32,
        w: *const c_void,
        w_is_bf16: i32,
        y: *mut f32,
        s: i32,
        k: i32,
        n: i32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_hc_sinkhorn_m(
        mixes: *const f32,
        scale: *const f32,
        base: *const f32,
        pre: *mut f32,
        post: *mut f32,
        comb: *mut f32,
        s: i32,
        hc: i32,
        iters: i32,
        eps: f32,
        stream: *mut c_void,
    ) -> i32;
    /// Fused hc pre-chain: rowsq_scale + Sinkhorn (bit-preserving stationarity exit) +
    /// collapse, one launch per (site, token). `niters` is nullable — per-token executed
    /// Sinkhorn iteration counts, the gate's convergence receipt. Bit-identical to the
    /// three-kernel chain (hc_fused_pre_gpu.rs); host seam MEMRA_HC_FUSED_PRE.
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_hc_pre_fused(
        x: *const f32,
        mixes: *const f32,
        scale: *const f32,
        base: *const f32,
        pre: *mut f32,
        post: *mut f32,
        comb: *mut f32,
        y: *mut f32,
        s: i32,
        hc: i32,
        d: i32,
        iters: i32,
        eps: f32,
        niters: *mut i32,
        stream: *mut c_void,
    ) -> i32;
    /// `MEMRA_HC_FUSED_PRE=2` (lane/b200-sinkhorn-fusion-20260902 follow-up): same stages
    /// and same signature as `memra_dsv4_hc_pre_fused` above; the Sinkhorn stage runs
    /// warp-0-only with `__syncwarp()` instead of `__syncthreads()` when hc<=4 (rows<=32),
    /// falling back to `memra_dsv4_hc_pre_fused` internally otherwise. Bit-identical to
    /// both the three-kernel chain and to the `=1` fused kernel by construction (a
    /// synchronization-primitive substitution only, no operand/order change).
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_hc_pre_fused_v2(
        x: *const f32,
        mixes: *const f32,
        scale: *const f32,
        base: *const f32,
        pre: *mut f32,
        post: *mut f32,
        comb: *mut f32,
        y: *mut f32,
        s: i32,
        hc: i32,
        d: i32,
        iters: i32,
        eps: f32,
        niters: *mut i32,
        stream: *mut c_void,
    ) -> i32;
    /// `memra_dsv4_hc_pre_fused_v2` with the block size as a parameter (door
    /// `MEMRA_HC_PRE_BLOCK`, lane/b200-hcpre-wide-20260903). v2 hardcodes `<<<s, 128>>>`,
    /// one block per row, so at t=1 decode the whole call is ONE block of 128 threads on a
    /// 148-SM B200 and nsys prices it as the LARGEST kernel in the decode profile (17.5%,
    /// 31.1 us avg, 90.7 launches per token = 2 per layer x 45 layers). It moves ~128 KB in
    /// those 31 us, which is 4.1 GB/s: four warps cannot cover HBM latency. `block` = 128
    /// reproduces v2's thread partition exactly and is therefore bit-identical to it; wider
    /// blocks change stage 1's `dsv4_block_sum` partition (stage 3 stays bit-identical at
    /// any width, and stage 2 is warp-0-only either way), which is the NAMED NUMERIC CLASS
    /// `hc_pre_rowsq_blockwide`. Refuses a `block` that is not a power of two in [32, 1024].
    #[allow(clippy::too_many_arguments)]
    /// BENCH-ONLY phase-stamped twin of `memra_dsv4_hc_pre_fused_v3` (no niters): `stamps` is 12 u64 on the device, [0..6) %globaltimer ns and [6..12) clock64 at
    /// the six phase boundaries named in the kernel's header. Only the gate binary calls it.
    pub fn memra_dsv4_hc_pre_fused_v3_stamped(
        x: *const f32,
        mixes: *const f32,
        scale: *const f32,
        base: *const f32,
        pre: *mut f32,
        post: *mut f32,
        comb: *mut f32,
        y: *mut f32,
        s: i32,
        hc: i32,
        d: i32,
        iters: i32,
        eps: f32,
        block: i32,
        sink_reg: i32,
        stamps: *mut u64,
        stream: *mut c_void,
    ) -> i32;
    /// hc pre-chain v4 (lane/hc-pre-phases-20260905): v3's arithmetic in v3's order on a
    /// register schedule (one round of loads kept for the combine, two barriers, Sinkhorn
    /// overlapped with the combine). 40025 = shape does not fit (caller runs v3).
    /// BENCH-ONLY phase-stamped twin of `memra_dsv4_hc_pre_v4` (12 u64 stamps: [0..6)
    /// %globaltimer ns, [6..12) clock64). Only the gate binary calls it.
    pub fn memra_dsv4_hc_pre_v4_stamped(
        x: *const f32,
        mixes: *const f32,
        scale: *const f32,
        base: *const f32,
        pre: *mut f32,
        post: *mut f32,
        comb: *mut f32,
        y: *mut f32,
        s: i32,
        hc: i32,
        d: i32,
        iters: i32,
        eps: f32,
        stamps: *mut u64,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_hc_pre_v4(
        x: *const f32,
        mixes: *const f32,
        scale: *const f32,
        base: *const f32,
        pre: *mut f32,
        post: *mut f32,
        comb: *mut f32,
        y: *mut f32,
        s: i32,
        hc: i32,
        d: i32,
        iters: i32,
        eps: f32,
        niters: *mut i32,
        block: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_hc_pre_fused_v3(
        x: *const f32,
        mixes: *const f32,
        scale: *const f32,
        base: *const f32,
        pre: *mut f32,
        post: *mut f32,
        comb: *mut f32,
        y: *mut f32,
        s: i32,
        hc: i32,
        d: i32,
        iters: i32,
        eps: f32,
        niters: *mut i32,
        block: i32,
        // `MEMRA_HC_PRE_SINK_REG=1`: run stage 2 (Sinkhorn) in REGISTERS with `__shfl_sync`
        // instead of shared memory. BIT-IDENTICAL by construction, not a numeric class: every
        // row/column sum is gathered in the SAME order the shared loop used
        // (`for k: sum += __shfl_sync(mask, cv, r*hc+k)` against `for k: sum += comb[t*hc+k]`),
        // so the same addends land in the same sequence in the same running float. A tree
        // reduction would be fewer instructions and a different association; it is deliberately
        // not used. Falls back to the shared path when `hc*hc > 32` (the matrix must fit one
        // warp), checked in the launcher rather than assumed.
        sink_reg: i32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_hc_head_pre_m(
        mixes: *const f32,
        scale: *const f32,
        base: *const f32,
        pre: *mut f32,
        s: i32,
        hc: i32,
        eps: f32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_route_m(
        raw: *const f32,
        bias: *const f32,
        tid2eid: *const i32,
        tok: *const i32,
        s: i32,
        ne: i32,
        topk: i32,
        route_scale: f32,
        sel: *mut i32,
        selw: *mut f32,
        order: *mut i32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_fp4_gemm_sel_g(
        a_codes: *const c_void,
        a_scales: *const f32,
        w_base: *const c_void,
        sc_base: *const c_void,
        s2: *const f32,
        sel: *const i32,
        proj: i32,
        a_stride_rows: i32,
        kind: i32,
        out: *mut f32,
        slots: i32,
        n: i32,
        kdim: i32,
        wstride: i64,
        sstride: i64,
        a_group: i32,
        stream: *mut c_void,
    ) -> i32;
    /// Explicit per-model reduction: 0 = original block tree, 1 = exact warp tree.
    pub fn memra_dsv4_fp4_gemm_sel_g_arm(
        a_codes: *const c_void,
        a_scales: *const f32,
        w_base: *const c_void,
        sc_base: *const c_void,
        s2: *const f32,
        sel: *const i32,
        proj: i32,
        a_stride_rows: i32,
        kind: i32,
        out: *mut f32,
        slots: i32,
        n: i32,
        kdim: i32,
        wstride: i64,
        sstride: i64,
        a_group: i32,
        reduce_arm: i32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_combine_rows_m(
        contrib: *const f32,
        order: *const i32,
        topk: i32,
        y: *mut f32,
        d: i64,
        s: i32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_sink_attn_dec_mq(
        q: *const f32,
        kv: *const f32,
        idxs: *const i32,
        sink: *const f32,
        scores: *mut f32,
        evals: *mut f32,
        den: *mut f64,
        o: *mut f32,
        nq: i32,
        heads: i32,
        hd: i32,
        slots: i32,
        idx_stride: i32,
        scale: f32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_sink_attn_dec_mq_f32acc(
        q: *const f32,
        kv: *const f32,
        idxs: *const i32,
        sink: *const f32,
        scores: *mut f32,
        evals: *mut f32,
        den: *mut f32,
        o: *mut f32,
        nq: i32,
        heads: i32,
        hd: i32,
        slots: i32,
        idx_stride: i32,
        scale: f32,
        stream: *mut c_void,
    ) -> i32;
    // q staging for the two f32acc scorers, whose q operand is [nq][hd][heads].
    pub fn memra_dsv4_q_transpose_m(
        q: *const f32,
        qt: *mut f32,
        nq: i32,
        heads: i32,
        hd: i32,
        stream: *mut c_void,
    ) -> i32;
    // RED ARMS, gate only: the [heads][hd] scorers the layout change replaced. No serving
    // path calls these; dsv4_q_layout_gate uses them to assert byte identity.
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_sink_scores_mq_f32acc_ref(
        q: *const f32,
        kv: *const f32,
        idxs: *const i32,
        scores: *mut f32,
        nq: i32,
        heads: i32,
        hd: i32,
        slots: i32,
        idx_stride: i32,
        scale: f32,
        stream: *mut c_void,
    ) -> i32;
    #[allow(clippy::too_many_arguments)]
    pub fn memra_dsv4_indexer_score_f32acc_pos_m_ref(
        q: *const f32,
        ckv: *const f32,
        w: *const f32,
        wscale: f32,
        score: *mut f32,
        s: i32,
        heads: i32,
        hd: i32,
        nb: i32,
        ratio: i32,
        pos0: i32,
        stream: *mut c_void,
    ) -> i32;
    pub fn memra_dsv4_scatter_rows(
        src: *const f32,
        dst: *mut f32,
        dst_rows: *const i32,
        n: i32,
        d: i32,
        stream: *mut c_void,
    ) -> i32;
}

/// rc -> Err with the kernel name (refuse loudly, house style).
pub fn ck(name: &str, rc: i32) -> Result<(), String> {
    crate::last_site_set(name);
    if rc == 0 {
        Ok(())
    } else {
        Err(format!("dsv4 kernel {name} failed rc={rc}"))
    }
}
