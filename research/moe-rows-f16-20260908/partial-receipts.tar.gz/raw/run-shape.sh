#!/usr/bin/env bash
set -euo pipefail
source /root/tunebox/env.sh
export CUDA_VISIBLE_DEVICES=0 CARGO_TARGET_DIR=/root/rowsf16-target
export MEMRA_MOE_RESIDENT=0 MEMRA_MOE_VROWS_ILP=1 MEMRA_MOE_VROWS_PACK=0
export MEMRA_MOE_VROWS_DEDUP_ORDER=0 MEMRA_MOE_VROWS_DOWN_TMAJ=0
OUT=/root/rowsf16-receipts-20260908
T=$1
MODE=$2
mkdir -p "$OUT/t$T"
trap 'echo $? > "$OUT/t$T/$MODE.exit"' EXIT
sha256sum "$CARGO_TARGET_DIR/release/moe_rows_ceiling_bench" > "$OUT/t$T/$MODE.binary.sha256"
MEMRA_GPU_LOCK=/tmp/memra-gpu.lock flock /tmp/memra-gpu.lock nice -n 19 timeout 1800 \
  "$CARGO_TARGET_DIR/release/moe_rows_ceiling_bench" --real-cell \
  /data/models/glm53-b200-mint /root/tunebox/prompts/p4k "$T" "$OUT/t$T" "$MODE" \
  > "$OUT/t$T/$MODE.log" 2>&1
