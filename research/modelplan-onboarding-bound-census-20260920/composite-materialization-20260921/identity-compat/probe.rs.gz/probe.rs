use memra_gguf::source::{Hy3RepackSource,TensorSource};
fn main() {
 let dir=std::path::PathBuf::from(std::env::args().nth(1).unwrap());std::fs::create_dir_all(&dir).unwrap();
 std::fs::write(dir.join("config.json"),r#"{"model_type":"qwen3_moe","num_hidden_layers":1,"hidden_size":32,"num_attention_heads":2,"num_key_value_heads":1,"head_dim":16,"intermediate_size":64,"vocab_size":32,"max_position_embeddings":128,"num_experts":4,"num_experts_per_tok":2,"moe_intermediate_size":32}"#).unwrap();
 let manifest=r#"{"format":"memra-repack-v1","tensors":{"blk.0.ffn_gate_exps.1.weight":{"file":"a.bin","offset":0,"qtype":"F32","ne":[32,32],"bytes":4096},"blk.0.ffn_gate_exps.3.weight":{"file":"b.bin","offset":0,"qtype":"F32","ne":[32,32],"bytes":4096}}}"#;
 std::fs::write(dir.join("a.bin"),[1.0f32.to_le_bytes().repeat(1024),vec![1,2,3,4]].concat()).unwrap();
 std::fs::write(dir.join("b.bin"),2.0f32.to_le_bytes().repeat(1024)).unwrap();
 for mask in [false,true] {
  let text=if mask {manifest.replacen('{',"{\"pruned_experts\":{\"0\":[0,2]},",1)} else {manifest.to_owned()};
  std::fs::write(dir.join("manifest.json"),text).unwrap();
  let source=Hy3RepackSource::open(&dir).unwrap();println!("{mask}:{}",source.artifact_sha256().unwrap());
 }
}
