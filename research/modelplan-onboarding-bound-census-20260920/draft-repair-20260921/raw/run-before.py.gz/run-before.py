from pathlib import Path
import os,subprocess,time,json,shutil,hashlib
root=Path.cwd();out=root/'target/541-draft-repair';probe=root/'target/541-draft-repair-probe'
cmd=['cargo','run','--locked','--offline','--manifest-path',str(probe/'Cargo.toml'),'--',str(probe/'fixtures')]
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(root/'target'),CARGO_BUILD_JOBS='2')
start=time.monotonic()
with (out/'before.log').open('wb') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
result={'command':cmd,'environment':{k:env[k] for k in ['CARGO_INCREMENTAL','CARGO_TARGET_DIR','CARGO_BUILD_JOBS']},'exit_code':r.returncode,'wall_seconds':time.monotonic()-start}
assert r.returncode==101,r.returncode
binary=root/'target/debug/reviewer-external-draft-edges';dest=out/'before-cpu';shutil.copyfile(binary,dest);dest.chmod(binary.stat().st_mode&0o777)
result['binary_sha256']=hashlib.sha256(dest.read_bytes()).hexdigest()
(out/'before-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
