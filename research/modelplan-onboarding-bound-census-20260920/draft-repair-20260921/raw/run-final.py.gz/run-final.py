from pathlib import Path
import os,subprocess,json,time,shutil,hashlib
root=Path.cwd();out=root/'target/541-draft-repair';probe=root/'target/541-draft-repair-probe';harness=root/'research/modelplan-onboarding-bound-census-20260920/draft-repair-20260921/consumer-harness'
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(root/'target'),CARGO_BUILD_JOBS='2')
commands=[('after-probe',['cargo','run','--locked','--offline','--manifest-path',str(probe/'Cargo.toml'),'--',str(probe/'fixtures')],{}),('source-clippy',['cargo','clippy','--locked','--offline','-p','memra-gguf','--all-targets','--','-D','warnings'],{}),('consumer-clippy',['cargo','clippy','--locked','--offline','--manifest-path',str(harness/'Cargo.toml'),'--all-targets','--','-D','warnings'],{}),('engine-clippy',['cargo','clippy','--locked','--offline','--target','x86_64-unknown-linux-gnu','-p','memra-engine','--lib','--tests','--','-D','warnings'],{'DOCS_RS':'1'}),('format',['cargo','fmt','--all','--','--check'],{}),('consumer-format',['cargo','fmt','--manifest-path',str(harness/'Cargo.toml'),'--','--check'],{}),('diff',['git','diff','--check'],{})]
results=[]
for name,cmd,extra in commands:
    start=time.monotonic()
    with (out/(name+'.log')).open('wb') as log:r=subprocess.run(cmd,env=dict(env,**extra),stdout=log,stderr=subprocess.STDOUT)
    results.append({'name':name,'command':cmd,'environment':dict({k:env[k] for k in ['CARGO_INCREMENTAL','CARGO_TARGET_DIR','CARGO_BUILD_JOBS']},**extra),'exit_code':r.returncode,'wall_seconds':time.monotonic()-start})
    (out/'final-results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
    if r.returncode:raise SystemExit(r.returncode)
    if name=='after-probe':
        binary=root/'target/debug/reviewer-external-draft-edges';dest=out/'after-cpu';shutil.copyfile(binary,dest);dest.chmod(binary.stat().st_mode&0o777)
        log=(out/'after-probe.log').read_text();assert 'accepted,target_m3=false' in log and 'accepted,scale=F32' in log
        assert 'refused,target_m3=true' in log and 'refused,scale=F16' in log and 'refused,scale=BF16' in log
for p,digest in json.loads((out/'source-pin.json').read_text()).items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==digest,p
print('Pinned final checks PASS',flush=True)
