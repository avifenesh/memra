import hashlib,json,os,pathlib,subprocess,time,sys
root=pathlib.Path.cwd();out=root/'target/541-root-trim';h=root/'research/modelplan-onboarding-bound-census-20260920/root-trim-20260922/consumer-harness'
files=['crates/memra-engine/src/hybrid.rs','crates/memra-engine/src/hybrid/root_trim.rs','crates/memra-engine/src/model/final_upload.rs','crates/memra-engine/src/plan_backend.rs','crates/memra-engine/src/plan_backend/target_trim.rs','crates/memra-engine/src/plan_backend/runtime_identity.rs','crates/memra-engine/src/plan_backend/execution_snapshot.rs','crates/memra-engine/src/head_trim.rs','crates/memra-engine/src/trim_ranks.rs','crates/memra-engine/src/model.rs','research/modelplan-onboarding-bound-census-20260920/head-trim-20260921/consumer-harness/src/fixture.rs']+[str(p.relative_to(root)) for p in h.rglob('*') if p.is_file()]
pin={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(files)};(out/'source-pin.json').write_text(json.dumps(pin,indent=2)+'\n')
env={'CARGO_INCREMENTAL':'0','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target')}
checks=[('root-tests',['cargo','test','--locked','--offline','--manifest-path',str(h/'Cargo.toml'),'--lib','hybrid::tests','--','--test-threads=1','--nocapture'],{},0),('harness-clippy',['cargo','clippy','--locked','--offline','--manifest-path',str(h/'Cargo.toml'),'--all-targets','--','-D','warnings'],{},0),('format',['cargo','fmt','--all','--','--check'],{},0),('harness-format',['cargo','fmt','--manifest-path',str(h/'Cargo.toml'),'--','--check'],{},0),('diff',['git','diff','--check'],{},0),('actual-target-eligibility',['cargo','run','--locked','--offline','--manifest-path',str(h/'Cargo.toml'),'--bin','eligibility','--',str(out/'metadata-witness.gguf')],{},2)]
results=[]
for name,command,extra,expected in checks:
 start=time.monotonic()
 with (out/(name+'-final.log')).open('w') as f:p=subprocess.run(command,env=os.environ|env|extra,stdout=f,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':command,'environment':env|extra,'expected_exit':expected,'exit_code':p.returncode,'wall_seconds':time.monotonic()-start});(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode!=expected:sys.exit(1)
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==v for p,v in pin.items())
(out/'source-stability.json').write_text(json.dumps({'verified':True,'files':len(pin),'engine_clippy':'Already passed for these unchanged production bytes in engine-clippy-1.log; no later production edits.'},indent=2)+'\n')
with (out/'toolchain.txt').open('w') as f:
 for c in [['rustc','--version'],['cargo','--version']]:subprocess.run(c,stdout=f,stderr=subprocess.STDOUT,check=True)
