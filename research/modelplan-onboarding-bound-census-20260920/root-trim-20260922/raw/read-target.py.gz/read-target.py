import subprocess,pathlib
out=pathlib.Path('target/541-root-trim')
code=r'''
import struct,hashlib,json,os,sys,tarfile,io,datetime
path='/data/ai-ml/hf-models/qwen38-27b-nvfp4-mtp/Qwen3.8-27B-NVFP4-Q5K-mtp.gguf'
expected='1facf36c2db359dcf9c2475cf8f85fe84a528d10aaaaff20f7c0db3d561e024a'
with open(path,'rb') as f:
 before=os.fstat(f.fileno());h=hashlib.sha256();prefix=bytearray()
 def take(n):
  if n<0 or len(prefix)+n>256*1024*1024:raise ValueError('metadata budget exceeded')
  b=f.read(n)
  if len(b)!=n:raise ValueError('short metadata')
  prefix.extend(b);h.update(b);return b
 def u32():return struct.unpack('<I',take(4))[0]
 def u64():return struct.unpack('<Q',take(8))[0]
 def string():return take(u64())
 def value(t,depth=0):
  if depth>3:raise ValueError('nested metadata depth')
  if t==8:string()
  elif t==9:
   subtype=u32();n=u64()
   if n>2000000:raise ValueError('metadata array budget')
   for _ in range(n):value(subtype,depth+1)
  else:take({0:1,1:1,2:2,3:2,4:4,5:4,6:4,7:1,10:8,11:8,12:8}[t])
 if take(4)!=b'GGUF' or u32()!=3:raise ValueError('expected GGUFv3')
 tensors=u64();count=u64()
 for _ in range(count):string();value(u32())
 header=bytes(prefix)
 for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
 after=os.fstat(f.fileno())
 fields=lambda st:(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)
 if fields(before)!=fields(after):raise ValueError('opened model changed during read')
 if h.hexdigest()!=expected:raise ValueError('model digest differs from accepted pin: '+h.hexdigest())
 metadata=bytearray(header);metadata[8:16]=(0).to_bytes(8,'little');metadata.extend(b'\0'*((-len(metadata))%4096))
 record={'path':path,'sha256':h.hexdigest(),'bytes':after.st_size,'metadata_prefix_sha256':hashlib.sha256(header).hexdigest(),'metadata_prefix_bytes':len(header),'metadata_only_container_sha256':hashlib.sha256(metadata).hexdigest(),'original_tensor_count':tensors,'metadata_count':count,'opened_stat':fields(after),'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'single opened descriptor; parser-captured metadata bytes included in same complete-file hash stream; before/after stat drift check','scope':'read-only metadata eligibility witness; generated container has zero tensors and is not a loadable target or native proof'}
 with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz') as archive:
  for name,data in [('metadata.gguf',bytes(metadata)),('model-pin.json',(json.dumps(record,indent=2)+'\n').encode())]:
   info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
'''
command=['ssh','-F','/Users/avifen/Documents/Codex/2026-09-19/w/work/continuous/gpu/verda-b75af981/ssh_config','-o','BatchMode=yes','-o','ConnectTimeout=10','memra-five-recovered','python3 -']
with (out/'target-metadata.tar.gz').open('xb') as f,(out/'target-read.stderr').open('w') as errors:
 p=subprocess.run(command,input=code.encode(),stdout=f,stderr=errors)
(out/'target-read.exit').write_text(str(p.returncode)+'\n');raise SystemExit(p.returncode)
