import pathlib,subprocess,hashlib,json,tomllib,re
root=pathlib.Path.cwd();out=root/'target/541-root-trim';base='341188ae5bdb4b57d016e5fd14042a790b17ae99';sha=lambda b:hashlib.sha256(b).hexdigest()
changed={'crates/memra-engine/src/hybrid.rs','crates/memra-engine/src/model/final_upload.rs','crates/memra-engine/src/plan_backend.rs'}
protected={}
for row in subprocess.check_output(['git','ls-tree','-r',base,'crates']).decode().splitlines():
 meta,path=row.split('\t');mode,kind,oid=meta.split()
 if path in changed:continue
 data=(root/path).read_bytes();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid,path
 assert ('100755' if (root/path).stat().st_mode&0o111 else '100644')==mode,path
 protected[path]={'git_blob':oid,'sha256':sha(data),'mode':mode}
def original(path):return subprocess.check_output(['git','show',base+':'+path]).decode()
def block(s,a,b):
 i=s.index(a);return s[i:s.index(b,i)]
p='crates/memra-engine/src/plan_backend.rs';old=original(p);new=(root/p).read_text();assert new.replace('mod target_trim;\npub(crate) use target_trim::capture_target_trim_rewrite_identity;\n','',1)==old
capture=block(old,'pub(crate) fn capture_rewrite_identity(','fn hardware_snapshot(')
assert block(new,'pub(crate) fn capture_rewrite_identity(','fn hardware_snapshot(')==capture
p='crates/memra-engine/src/model/final_upload.rs';old=original(p);new=(root/p).read_text()
for a,b in [('    pub(crate) fn validate_assigned(', '    pub(crate) fn after_upload('),('    pub(crate) fn install_into(', '    pub fn tensor(')]:
 i=new.index(a);j=new.index(b,i);new=new[:i]+new[j:]
assert new==old,'public upload path changed'
p='crates/memra-engine/src/hybrid.rs';old=original(p);new=(root/p).read_text()
new=new.replace('pub(crate) mod root_trim;\n\n','',1)
new=new.replace('    // Source-owned block origin and a temporary private reservation during strict trim load.\n    embedded_block_index: Option<u32>,\n    pending_trim_slot: Option<root_trim::SlotReservation>,\n','',1)
new=new.replace('            embedded_block_index: None,\n            pending_trim_slot: None,\n','',1)
a='    fn load_prepared_source_impl(';b='    /// Force the device embed table resident'
old_body=block(old,a,b);new_body=block(new,a,b)
assert new.replace(new_body,'ROOT-LOAD-BODY\n',1)==old.replace(old_body,'ROOT-LOAD-BODY\n',1),'hybrid changed outside root load/field annotations'
assert new_body.index('root_trim::RootTrimLoad::begin(')<new_body.index('prepare_auto_parallel(')
assert new_body.index('let mut model = HybridModel')<new_body.index('pending.complete(')<new_body.index('capture_target_trim_rewrite_identity(')
assert 'rewrite_bundle.is_some() || trim_load.is_some()' in new_body
root_code=(root/'crates/memra-engine/src/hybrid/root_trim.rs').read_text();completion=block(root_code,'    pub(super) fn complete(','/// Private, linear proof')
assert completion.index('sync_stages_after_load(')<completion.index('slot.upload.install_into(')<completion.index('Ok(CompleteTargetTrimProof')
assert 'Arc::ptr_eq' in root_code and 'CUdeviceptr' not in root_code and '.device_ptr(' not in root_code
h=root/'research/modelplan-onboarding-bound-census-20260920/root-trim-20260922/consumer-harness'
root_packages={(p['name'],p['version']):p for p in tomllib.loads((root/'Cargo.lock').read_text())['package'] if 'source' in p}
packages=[p for p in tomllib.loads((h/'Cargo.lock').read_text())['package'] if 'source' in p]
for p in packages:assert all(root_packages[(p['name'],p['version'])].get(k)==p.get(k) for k in ['source','checksum']),p
report={'base':base,'protected_crate_files':protected,'ordinary_capture_sha256':sha(capture.encode()),'ordinary_capture_byte_equal':True,'public_upload_path_byte_equal_after_removing_private_install_checks':True,'hybrid_scope':'Only root load body, private embedded-block/reservation fields and their external constructor None initialization; all other hybrid behavior byte-equal.','ordering':'begin before auto parallel/upload; construct HybridModel before complete; complete calls actual sync_stages_after_load then moves exact owned tensors; capture afterward.','no_portable_cuda_pointer_identity':True,'strict_pending_without_bundle_for_proof_mode':True,'harness_registry_versions_checksums_match_root':len(packages),'retained_expert_registry_preserved':True}
(out/'preservation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'protected_crate_files':len(protected),'ordinary_capture_sha256':report['ordinary_capture_sha256'],'registry_packages':len(packages),'root_order_and_scoped_diff_verified':True}))
