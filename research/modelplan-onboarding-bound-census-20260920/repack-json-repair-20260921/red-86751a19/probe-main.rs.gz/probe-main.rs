use memra_gguf::{config::{HfConfig,ModelConfig},model_packs,tensor_contract::CheckpointDialect,source::{Hy3RepackSource,TensorSource},bound_source::BoundTensorSource,model_plan::OperationKind};
fn main(){
 let root=std::path::PathBuf::from(std::env::args_os().nth(1).unwrap());std::fs::create_dir_all(&root).unwrap();
 let config=r#"{"model_type":"qwen3_moe","num_hidden_layers":1,"hidden_size":32,"num_attention_heads":4,"num_key_value_heads":2,"head_dim":8,"intermediate_size":64,"vocab_size":16,"max_position_embeddings":32,"num_experts":4,"num_experts_per_tok":2,"moe_intermediate_size":32}"#;
 let cfg=ModelConfig::from_hf(&HfConfig::parse(config));let pack=model_packs::for_config(&cfg).unwrap();let plan=pack.compile_plan(&cfg).unwrap();let contract=pack.compile_tensor_contract(&cfg,&plan,CheckpointDialect::Gguf,pack.contract_options(&cfg)).unwrap();
 let mut bytes=vec![];let mut rows=vec![];
 for r in contract.requirements.iter().filter(|r|r.required){
  assert_eq!(r.match_mode,memra_gguf::tensor_contract::TensorMatch::OneOf);let n=r.shape.iter().product::<u64>() as usize;let start=bytes.len();bytes.extend(0.125f32.to_le_bytes().repeat(n));rows.push(format!("{:?}:{{\"file\":\"weights.bin\",\"offset\":{},\"qtype\":\"F32\",\"ne\":{:?},\"bytes\":{}}}",r.names[0],start,r.shape,n*4));
 }
 std::fs::write(root.join("config.json"),config).unwrap();std::fs::write(root.join("weights.bin"),bytes).unwrap();
 let cases=[
  ("ordinary_complete",r#""memra-repack-v1""#,""),
  ("literal_mask_uniform_bank",r#""memra-repack-v1""#,r#", "pruned_experts":{"0":[0,2]}"#),
  ("escaped_mask_uniform_bank",r#""memra-repack-v1""#,r#", "pruned\u005fexperts":{"0":[0,2]}"#),
  ("duplicate_escaped_mask",r#""memra-repack-v1""#,r#", "pruned_experts":{}, "pruned\u005fexperts":{"0":[0,2]}"#),
  ("literal_overlay_missing_source",r#""memra-expert-overlay-v2""#,""),
  ("escaped_overlay_missing_source",r#""memra-expert-overlay\u002dv2""#,""),
 ];
 for (name,format,extra) in cases {
  let manifest=format!("{{\"format\":{},\"tensors\":{{{}}}{}}}",format,rows.join(","),extra);std::fs::write(root.join("manifest.json"),&manifest).unwrap();std::fs::write(root.join(format!("{name}.manifest.json")),manifest).unwrap();
  match Hy3RepackSource::open(&root){Err(e)=>println!("{name}: open_refused={e}"),Ok(source)=>{
   let mask=source.active_experts(0).map(|x|x.to_vec());let identity=source.artifact_sha256().is_ok();
   match BoundTensorSource::compile(&source){Err(e)=>println!("{name}: mask={mask:?} identity_ok={identity} bind_refused={e}"),Ok(bound)=>println!("{name}: mask={mask:?} identity_ok={identity} bind_ok=true retained_operation={}",bound.plan().operations().contains(&OperationKind::RetainedExpertRouting))}
  }}
 }
}
