from pathlib import Path
import os,subprocess,json,time,hashlib
root=Path.cwd();out=root/'target/541-head-trim';harness=root/'research/modelplan-onboarding-bound-census-20260920/head-trim-20260921/consumer-harness'
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(root/'target'),CARGO_BUILD_JOBS='2')
commands=[('draft-compatibility',['cargo','test','--locked','--offline','-p','memra-gguf','--lib','bound_source::draft::tests','--','--nocapture'],{}),('consumer-clippy',['cargo','clippy','--locked','--offline','--manifest-path',str(harness/'Cargo.toml'),'--all-targets','--','-D','warnings'],{}),('engine-clippy',['cargo','clippy','--locked','--offline','--target','x86_64-unknown-linux-gnu','-p','memra-engine','--lib','--tests','--','-D','warnings'],{'DOCS_RS':'1'}),('format',['cargo','fmt','--all','--','--check'],{}),('consumer-format',['cargo','fmt','--manifest-path',str(harness/'Cargo.toml'),'--','--check'],{}),('diff',['git','diff','--check'],{})]
results=[]
for name,cmd,extra in commands:
    start=time.monotonic()
    with (out/(name+'.log')).open('wb') as log:r=subprocess.run(cmd,env=dict(env,**extra),stdout=log,stderr=subprocess.STDOUT)
    results.append({'name':name,'command':cmd,'environment':dict({k:env[k] for k in ['CARGO_INCREMENTAL','CARGO_TARGET_DIR','CARGO_BUILD_JOBS']},**extra),'exit_code':r.returncode,'wall_seconds':time.monotonic()-start})
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
    if r.returncode:raise SystemExit(r.returncode)
for p,digest in json.loads((out/'source-pin.json').read_text()).items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==digest,p
print('Pinned final checks PASS',flush=True)
