// Independent read-only metadata probe. No checkpoint payloads or BoundSource APIs.
use std::collections::BTreeMap;
use memra_gguf::config::{HfConfig,ModelConfig};
use memra_gguf::tensor_contract::{CheckpointDialect,ContractOptions,TensorId};
use memra_gguf::safetensors::parse_header_json_checked;
use memra_gguf::source::census_from_safetensors_headers;
fn main() -> Result<(), Box<dyn std::error::Error>> {
 let args:Vec<_>=std::env::args().collect();
 let dir=std::path::Path::new(&args[1]);
 let cfg=ModelConfig::from_hf(&HfConfig::parse(&std::fs::read_to_string(dir.join("config.json"))?));
 let pack=memra_gguf::model_packs::for_config(&cfg).ok_or("no pack")?;
 let plan=pack.compile_plan(&cfg)?;
 let contract=pack.compile_tensor_contract(&cfg,&plan,CheckpointDialect::HfSafetensors,ContractOptions::default())?;
 let mut headers=BTreeMap::new();
 for path in std::fs::read_dir(dir)? {
  let path=path?.path();
  if !path.to_string_lossy().ends_with(".safetensors.header.json") {continue}
  for (name, info) in parse_header_json_checked(&std::fs::read_to_string(path)?)? {
   if name.starts_with("model.layers.") || ["model.embed_tokens.weight","model.norm.weight","lm_head.weight"].contains(&name.as_str()) {
    assert!(headers.insert(name,info).is_none(), "duplicate physical name across headers");
   }
  }
 }
 let census=census_from_safetensors_headers(&headers)?;
 let entries:Vec<_>=census.tensors.iter().map(|r|r.entry.clone()).collect();
 let binding=contract.bind(&entries)?;
 eprintln!("pack={} support={:?} tokenizer_sources={:?}",pack.family,pack.support,pack.tokenizer_sources);
 eprintln!("text_header_tensors={} folded_census_rows={} bound_roles={}", headers.len(), entries.len(),binding.tensors.len());
 for r in contract.requirements {
  if matches!(r.id,TensorId::QuantAux{..}) {continue}
  for name in r.names {
   let physical=headers.get(&name).ok_or(format!("missing {name}"))?;
   println!("{}\t{:?}\t{:?}\t{:?}\t{:?}\t{}\t{:?}\t{}",name,r.id,r.shape,r.owner,r.transform,r.required,r.quant,physical.dtype);
  }
 }
 Ok(())
}
