pub(crate) fn quant_type_for_trim(ty: GgmlType) -> Result<i32, String> {
    Ok(match ty {
        GgmlType::Q8_0 => QT_Q8_0,
        GgmlType::Q4_K => QT_Q4_K,
        GgmlType::Q6_K => QT_Q6_K,
        GgmlType::Q5_K => QT_Q5_K,
        GgmlType::Q3_K => QT_Q3_K,
        GgmlType::IQ4_XS => QT_IQ4_XS,
        GgmlType::IQ3_S => QT_IQ3_S,
        GgmlType::NVFP4 => QT_NVFP4,
        GgmlType::Q4_0 => QT_Q4_0,
        other => return Err(format!("from_quant_bytes: unsupported dtype {other:?}")),
    })
}


pub fn repack_nvfp4_split(bytes: &[u8], out_f: usize) -> Vec<u8> {
    let row_bytes = bytes.len() / out_f;
    let nsb64 = row_bytes / 36;
    debug_assert_eq!(
        row_bytes % 36,
        0,
        "NVFP4 row_bytes must be a multiple of 36"
    );
    let qplane = out_f * nsb64 * 32;
    let mut rp = vec![0u8; bytes.len()];
    for o in 0..out_f {
        for s in 0..nsb64 {
            let src = &bytes[o * row_bytes + s * 36..o * row_bytes + s * 36 + 36];
            rp[qplane + (o * nsb64 + s) * 4..qplane + (o * nsb64 + s) * 4 + 4]
                .copy_from_slice(&src[0..4]);
            rp[(o * nsb64 + s) * 32..(o * nsb64 + s) * 32 + 32].copy_from_slice(&src[4..36]);
        }
    }
    rp
}


pub fn rp_enabled() -> bool {
    static ON: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *ON.get_or_init(|| std::env::var("MEMRA_RP").map(|v| v != "0").unwrap_or(true))
}


impl GpuTensor {
    pub fn from_quant_bytes(
        e: &Engine,
        bytes: &[u8],
        ty: GgmlType,
        ne0: u64,
        ne1: u64,
        scale: f32,
    ) -> Result<Self, Box<dyn std::error::Error>> {
        Ok(Self::from_quant_bytes_impl(e, bytes, ty, ne0, ne1, scale, false)?.0)
    }

    pub(crate) fn from_quant_bytes_recorded(
        e: &Engine,
        bytes: &[u8],
        ty: GgmlType,
        ne0: u64,
        ne1: u64,
        scale: f32,
    ) -> Result<(Self, final_upload::FinalUploadIdentity), Box<dyn std::error::Error>> {
        let (tensor, identity) = Self::from_quant_bytes_impl(e, bytes, ty, ne0, ne1, scale, true)?;
        Ok((
            tensor,
            identity.ok_or("recorded quant upload did not produce identity")?,
        ))
    }

    #[allow(clippy::too_many_arguments)] // allow: internal switch preserves the public constructor and opt-in capture path
    fn from_quant_bytes_impl(
        e: &Engine,
        bytes: &[u8],
        ty: GgmlType,
        ne0: u64,
        ne1: u64,
        scale: f32,
        record: bool,
    ) -> Result<(Self, Option<final_upload::FinalUploadIdentity>), Box<dyn std::error::Error>> {
        if record {
            final_upload::validate_input(bytes, ty, [ne0, ne1])?;
        }
        // Only the proof path copies the host input, so the exact submitted buffer cannot
        // change underneath hashing. Ordinary construction keeps its previous borrowing cost.
        let captured = record.then(|| bytes.to_vec());
        let bytes = captured.as_deref().unwrap_or(bytes);
        let qt = if record {
            quant_type_for_trim(ty)?
        } else {
            quant_type_for_trim(ty).unwrap_or_else(|error| panic!("{error}"))
        };
        let row_bytes = bytes.len() / ne1 as usize;
        let rp = qt == QT_NVFP4
            && ne0.is_multiple_of(64)
            && row_bytes.is_multiple_of(36)
            && rp_enabled();
        let repacked = rp.then(|| repack_nvfp4_split(bytes, ne1 as usize));
        let submitted = repacked.as_deref().unwrap_or(bytes);
        let dev = e.htod_bytes(submitted)?;
        let tensor = GpuTensor::Quant {
            bytes: dev,
            qtype: qt,
            row_bytes,
            ne: vec![ne0, ne1],
            scale,
            rp,
            #[cfg(memra_cutlass)]
            cutlass: None,
            fp8: None,
            blk: None,
            f16: None,
            a4: None,
            rp4: None,
        };
        let identity = record
            .then(|| {
                final_upload::FinalUploadIdentity::after_upload(
                    &tensor,
                    bytes,
                    submitted,
                    ty,
                    [ne0, ne1],
                    scale,
                )
            })
            .transpose()?;
        Ok((tensor, identity))
    }

}
