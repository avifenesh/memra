import pathlib,subprocess,json,hashlib,datetime
root=pathlib.Path.cwd();out=root/'target/541-loaded-trim';refs={'541':'57de5874a94a8a5b520373a5344adbff35e9a280','542':'24668af517c83f5bbee64de0a0f0a16c1f4dec74','main':'653c997f445ed46dade7cf79b3437894114ae49d'}
sha=lambda b:hashlib.sha256(b).hexdigest();fragments={}
for role,ref in refs.items():
 source=subprocess.check_output(['git','show',ref+':crates/memra-engine/src/model.rs']).decode();fragments[role]={}
 for name,a,b in [('constructor','    pub fn from_quant_bytes(','    pub fn load_opt('),('repack','pub fn repack_nvfp4_split(','/// Inverse of'),('switch','pub fn rp_enabled()','/// FULL-PRECISION LOADER MODE')]:
  i=source.index(a);j=source.index(b,i);fragments[role][name]=sha(source[i:j].encode())
assert fragments['541']==fragments['542']==fragments['main']
patch=subprocess.check_output(['git','diff','HEAD','--','crates/memra-engine/src/model.rs']);(out/'model-upload.patch').write_bytes(patch)
parts=patch.decode().split('\n@@ ');header=parts[0];hunks=['@@ '+x for x in parts[1:]]
registration=[h for h in hunks if '+pub mod final_upload;' in h];assert len(registration)==1
numeric=(header+'\n'+'\n'.join(h for h in hunks if h not in registration)).encode();(out/'model-upload-numeric-hunks.patch').write_bytes(numeric)
checks=[]
for role,ref in refs.items():
 base=out/'compatibility'/role;file=base/'crates/memra-engine/src/model.rs';file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(subprocess.check_output(['git','show',ref+':crates/memra-engine/src/model.rs']))
 for name in ['model-upload.patch','model-upload-numeric-hunks.patch']:
  p=subprocess.run(['git','apply','--check','--directory='+str(base.relative_to(root)),str(out/name)],capture_output=True,text=True)
  checks.append({'ref':ref,'role':role,'patch':name,'exit_code':p.returncode,'output':p.stdout+p.stderr})
  if name=='model-upload-numeric-hunks.patch' or role=='541':assert p.returncode==0,checks[-1]
receipt={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'refs':refs,'unchanged_original_fragments_sha256':fragments,'patch_sha256':sha(patch),'numeric_patch_sha256':sha(numeric),'dry_run_patch_checks':checks,'registration_prerequisite':'The whole model.rs patch intentionally expects the reviewed541 nvfp4_scale module.542/main do not have this prerequisite; direct whole-patch checks fail at registration context, while original numeric constructor/repack/switch bytes match and all numeric hunks apply cleanly. Parent must compose the reviewed541 series.','limits':'Pinned constructor-level compatibility only. No broad intake, main/542 build or native-equivalence claim; final_upload also requires reviewed541 source/host types.'}
(out/'upload-compatibility.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'fragments_equal':True,'checks':[{k:r[k] for k in ['role','patch','exit_code']} for r in checks]},indent=2))
