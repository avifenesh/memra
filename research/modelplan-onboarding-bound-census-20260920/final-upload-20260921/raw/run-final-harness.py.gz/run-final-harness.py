import hashlib,json,os,pathlib,subprocess,time,sys
root=pathlib.Path.cwd();out=root/'target/541-loaded-trim';h=root/'research/modelplan-onboarding-bound-census-20260920/final-upload-20260921/consumer-harness'
old=json.loads((out/'source-pin.json').read_text()); files=set(old)|{str((h/'src/baseline_quant_upload.rs').relative_to(root))}
for p in old:
 if not p.startswith(str(h.relative_to(root))):assert hashlib.sha256((root/p).read_bytes()).hexdigest()==old[p]
pin={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(files)};(out/'source-pin.json').write_text(json.dumps(pin,indent=2)+'\n')
env={'CARGO_INCREMENTAL':'0','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target')}
checks=[]
for rp in ['0','1']:checks.append(('upload-rp'+rp+'-tests',['cargo','test','--locked','--offline','--manifest-path',str(h/'Cargo.toml'),'--','--nocapture'],{'MEMRA_RP':rp}))
checks.extend([('harness-clippy',['cargo','clippy','--locked','--offline','--manifest-path',str(h/'Cargo.toml'),'--all-targets','--','-D','warnings'],{}),('harness-format',['cargo','fmt','--manifest-path',str(h/'Cargo.toml'),'--','--check'],{}),('diff',['git','diff','--check'],{})])
results=[r for r in json.loads((out/'check-results.json').read_text()) if r['name'] in ['engine-clippy','format']];assert len(results)==2 and all(r['exit_code']==0 for r in results)
for name,command,extra in checks:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:p=subprocess.run(command,env=os.environ|env|extra,stdout=f,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':command,'environment':env|extra,'exit_code':p.returncode,'wall_seconds':time.monotonic()-start});(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==v for p,v in pin.items())
(out/'source-stability.json').write_text(json.dumps({'verified':True,'source_files':len(pin),'retained_checks':'engine-clippy/format use unchanged production source; only host harness gained frozen-baseline comparison'},indent=2)+'\n')
with (out/'toolchain.txt').open('w') as f:
 for c in [['cargo','--version'],['rustc','--version']]:subprocess.run(c,stdout=f,stderr=subprocess.STDOUT,check=True)
