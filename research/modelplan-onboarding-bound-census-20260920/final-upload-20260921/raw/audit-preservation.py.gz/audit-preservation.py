import hashlib,json,pathlib,subprocess,tomllib,re
root=pathlib.Path.cwd();out=root/'target/541-loaded-trim';base='57de5874a94a8a5b520373a5344adbff35e9a280';sha=lambda b:hashlib.sha256(b).hexdigest()
protected={}
for row in subprocess.check_output(['git','ls-tree','-r',base,'crates']).decode().splitlines():
 meta,path=row.split('\t');mode,kind,oid=meta.split()
 if path=='crates/memra-engine/src/model.rs':continue
 data=(root/path).read_bytes();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid,path
 current_mode='100755' if (root/path).stat().st_mode&0o111 else '100644';assert mode==current_mode,path
 protected[path]={'git_blob':oid,'sha256':sha(data),'mode':mode}
p='crates/memra-engine/src/model.rs';old=subprocess.check_output(['git','show',base+':'+p]).decode();new=(root/p).read_text()
start=old.index('    pub fn from_quant_bytes(');end=old.index('    pub fn load_opt(',start);old_ctor=old[start:end]
reconstructed=new.replace('pub mod final_upload;\n','',1)
a=reconstructed.index('pub(crate) fn quant_type_for_trim(');b=reconstructed.index('/// Host-side split-plane repack',a);reconstructed=reconstructed[:a]+reconstructed[b:]
a=reconstructed.index('    pub fn from_quant_bytes(');b=reconstructed.index('    pub fn load_opt(',a);reconstructed=reconstructed[:a]+old_ctor+reconstructed[b:]
assert reconstructed==old,'model.rs changed outside module/qtype helper/constructor'
h=root/'research/modelplan-onboarding-bound-census-20260920/final-upload-20260921/consumer-harness'
baseline=(h/'src/baseline_quant_upload.rs').read_text();a=baseline.index('    pub fn from_quant_bytes_baseline(');b=baseline.rfind('\n}')
assert baseline[a:b].strip().replace('pub fn from_quant_bytes_baseline(','pub fn from_quant_bytes(',1)==old_ctor.strip()
def section(s,a,b):
 i=s.index(a);return s[i:s.index(b,i)]
expected=section(new,'pub(crate) fn quant_type_for_trim(','/// Host-side split-plane repack')+'\n'+section(new,'pub fn repack_nvfp4_split(','/// Inverse of')+'\n'+section(new,'pub fn rp_enabled()','/// FULL-PRECISION LOADER MODE')+'\nimpl GpuTensor {\n'+section(new,'    pub fn from_quant_bytes(','    pub fn load_opt(')+'}\n'
paths=list((root/'target/debug/build').glob('memra-final-upload-host-*/out/quant-upload.rs'));assert paths
for path in paths:assert path.read_text()==expected,path
(out/'extracted-quant-upload.rs').write_text(expected)
root_packages={(p['name'],p['version']):p for p in tomllib.loads((root/'Cargo.lock').read_text())['package'] if 'source' in p}
packages=[p for p in tomllib.loads((h/'Cargo.lock').read_text())['package'] if 'source' in p]
for p in packages:
 candidate=root_packages[(p['name'],p['version'])];assert all(candidate.get(k)==p.get(k) for k in ['source','checksum']),p
qtypes={'QT_Q8_0':0,'QT_Q4_K':1,'QT_Q6_K':2,'QT_Q5_K':3,'QT_Q3_K':4,'QT_IQ4_XS':5,'QT_IQ3_S':6,'QT_NVFP4':7,'QT_Q4_0':12}
for ref in [base,'24668af517c83f5bbee64de0a0f0a16c1f4dec74','653c997f445ed46dade7cf79b3437894114ae49d']:
 lib=subprocess.check_output(['git','show',ref+':crates/memra-engine/src/lib.rs']).decode()
 for key,value in qtypes.items():assert re.search(r'pub const '+key+r': i32 = '+str(value)+r';',lib),(ref,key)
receipt={'base':base,'protected_crate_files':protected,'model_delta':'Removing final_upload module registration/qtype helper and restoring only original constructor reproduces model.rs exactly. All other constructor/loader/cache and numerical behavior outside this seam unchanged.','baseline_constructor_sha256':sha(old_ctor.strip().encode()),'baseline_test_method':'Exact old body; only method name changed for coexistence. Both old and new constructors execute in RP0/RP1 tests.','extracted_production_sha256':sha(expected.encode()),'harness_registry_versions_checksums_match_root':len(packages),'qtype_constants_verified_at_all_three_pins':qtypes,'shared_admission_files_untouched':True}
(out/'preservation.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'unchanged_crate_files':len(protected),'registry_packages':len(packages),'baseline_body_verified':True,'production_extraction_verified':True}))
