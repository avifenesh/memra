import hashlib,json,os,pathlib,subprocess,time,sys
root=pathlib.Path.cwd();out=root/'target/541-loaded-trim';harness=root/'research/modelplan-onboarding-bound-census-20260920/final-upload-20260921/consumer-harness'
files=['crates/memra-engine/src/model.rs','crates/memra-engine/src/model/final_upload.rs','crates/memra-engine/src/head_trim.rs','crates/memra-engine/src/lib.rs','crates/memra-gguf/src/bound_source/draft_pair.rs','crates/memra-gguf/src/bound_source/head_trim.rs','research/modelplan-onboarding-bound-census-20260920/head-trim-20260921/consumer-harness/src/fixture.rs']+[str(p.relative_to(root)) for p in harness.rglob('*') if p.is_file()]
pin={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files};(out/'source-pin.json').write_text(json.dumps(pin,indent=2)+'\n')
env={'CARGO_INCREMENTAL':'0','CARGO_TARGET_DIR':str(root/'target'),'CARGO_BUILD_JOBS':'2'}
checks=[('harness-clippy',['cargo','clippy','--locked','--offline','--manifest-path',str(harness/'Cargo.toml'),'--all-targets','--','-D','warnings'],{}),('engine-clippy',['cargo','clippy','--locked','--offline','--target','x86_64-unknown-linux-gnu','-p','memra-engine','--lib','--tests','--','-D','warnings'],{'DOCS_RS':'1'}),('format',['cargo','fmt','--all','--','--check'],{}),('harness-format',['cargo','fmt','--manifest-path',str(harness/'Cargo.toml'),'--','--check'],{}),('diff',['git','diff','--check'],{})]
results=[]
for name,command,extra in checks:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:p=subprocess.run(command,env=os.environ|env|extra,stdout=f,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':command,'environment':env|extra,'exit_code':p.returncode,'wall_seconds':time.monotonic()-start});(out/'check-results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in pin.items())
