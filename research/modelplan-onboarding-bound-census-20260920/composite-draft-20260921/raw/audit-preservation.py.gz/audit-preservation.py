import hashlib,json,pathlib,subprocess,os,tomllib
root=pathlib.Path.cwd(); out=root/'target/541-composite-draft'; base='231a5a12ee8e161515ec9683bcefc57b893f0eb4'
changed={'crates/memra-gguf/src/bound_source/draft.rs','crates/memra-engine/src/hybrid.rs'}
rows=subprocess.check_output(['git','ls-tree','-r',base,'crates']).decode().splitlines()
protected={}
for row in rows:
    meta,path=row.split('\t');mode,kind,oid=meta.split()
    if path in changed:continue
    data=(root/path).read_bytes()
    actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    assert actual==oid,path
    actual_mode='100755' if (root/path).stat().st_mode&0o111 else '100644'
    assert actual_mode==mode,path
    protected[path]={'git_blob':oid,'sha256':hashlib.sha256(data).hexdigest(),'mode':mode}
hybrid='crates/memra-engine/src/hybrid.rs'
old=subprocess.check_output(['git','show',base+':'+hybrid]).decode();new=(root/hybrid).read_text()
start=new.index('    /// Typed composite intake;')
end=new.index('    pub fn external_source_identity(',start)
assert new[:start]+new[end:]==old,'hybrid changed outside new method'
entry=new[start:end]
assert 'input.with_runtime(main_cfg, |prepared, source|' in entry
assert 'Self::load_prepared_draft(e, source, prepared, main_cfg)' in entry
body=old[old.index('    fn load_prepared_draft('):old.index('    fn load_prepared_draft(')+20000]
assert body.index('let external_source_identity = prepared.artifact_identity()?;')<body.index('let head = load_t(e, src, head_name)?;')
harness=root/'research/modelplan-onboarding-bound-census-20260920/composite-draft-20260921/consumer-harness'
root_lock=tomllib.loads((root/'Cargo.lock').read_text())
harness_lock=tomllib.loads((harness/'Cargo.lock').read_text())
registry=lambda lock:{(p['name'],p['version']):p for p in lock['package'] if 'source' in p}
rl=registry(root_lock);hl=registry(harness_lock)
for key,p in hl.items():
    assert all(rl[key].get(field)==p.get(field) for field in ['name','version','source','checksum']),key
other_preserved={}
for path in ['Cargo.toml','Cargo.lock','crates/memra-engine/src/plan_backend.rs','crates/memra-gguf/src/config.rs','research/modelplan-onboarding-bound-census-20260920/draft-repair-20260921/consumer-harness/src/fixture.rs']:
    data=(root/path).read_bytes();assert data==subprocess.check_output(['git','show',base+':'+path]),path
    other_preserved[path]=hashlib.sha256(data).hexdigest()
receipt={'base':base,'protected_crate_files':protected,'other_preserved':other_preserved,'engine_delta':'Removing only the new load_composite_draft method and its documentation restores hybrid.rs byte-for-byte to base; existing standalone/prepared consumer bodies, public layouts and four trim sites unchanged.','consumer_trace':'New typed method invokes input.with_runtime then existing load_prepared_draft; existing consumer captures prepared.artifact_identity before allocation and stores external_source_identity unchanged.','new_method_sha256':hashlib.sha256(entry.encode()).hexdigest(),'harness_registry_versions_checksums_equal_to_root':len(hl)}
(out/'preservation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'protected_crate_files':len(protected),'harness_registry_packages':len(hl),'engine_delta_only_new_typed_method':True}))
