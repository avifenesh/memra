import hashlib,json,os,pathlib,subprocess,time,sys
root=pathlib.Path.cwd()
out=root/'target/541-draft-pair'
harness=root/'research/modelplan-onboarding-bound-census-20260920/draft-pair-20260921/consumer-harness'
files=['crates/memra-gguf/src/bound_source.rs','crates/memra-gguf/src/bound_source/draft_pair.rs','crates/memra-gguf/src/bound_source/tests.rs','crates/memra-gguf/src/bound_source/tests/draft_pair.rs','crates/memra-engine/src/hybrid.rs']+[str(p.relative_to(root)) for p in sorted(harness.rglob('*')) if p.is_file()]+['research/modelplan-onboarding-bound-census-20260920/draft-repair-20260921/consumer-harness/src/fixture.rs','research/modelplan-onboarding-bound-census-20260920/head-trim-20260921/consumer-harness/src/fixture.rs','crates/memra-engine/src/model/nvfp4_scale.rs','crates/memra-engine/src/head_trim.rs','crates/memra-engine/src/trim_ranks.rs']
source={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}
(out/'source-pin.json').write_text(json.dumps(source,indent=2)+'\n')
env_values={'CARGO_INCREMENTAL':'0','CARGO_TARGET_DIR':str(root/'target'),'CARGO_BUILD_JOBS':'2'}
checks=[
 ('consumer-tests',['cargo','test','--locked','--offline','--manifest-path',str(harness/'Cargo.toml'),'--','--nocapture'],{}),
 ('source-tests',['cargo','test','--locked','--offline','-p','memra-gguf','--lib','bound_source::tests::draft_pair','--','--nocapture'],{}),
 ('source-clippy',['cargo','clippy','--locked','--offline','-p','memra-gguf','--all-targets','--','-D','warnings'],{}),
 ('consumer-clippy',['cargo','clippy','--locked','--offline','--manifest-path',str(harness/'Cargo.toml'),'--all-targets','--','-D','warnings'],{}),
 ('engine-clippy',['cargo','clippy','--locked','--offline','--target','x86_64-unknown-linux-gnu','-p','memra-engine','--lib','--tests','--','-D','warnings'],{'DOCS_RS':'1'}),
 ('format',['cargo','fmt','--all','--','--check'],{}),
 ('consumer-format',['cargo','fmt','--manifest-path',str(harness/'Cargo.toml'),'--','--check'],{}),
 ('diff',['git','diff','--check'],{}),
]
results=[]
for name,command,extra in checks:
    start=time.monotonic(); effective=env_values|extra
    with (out/(name+'-final.log')).open('w') as f:
        p=subprocess.run(command,env=os.environ|effective,stdout=f,stderr=subprocess.STDOUT)
    results.append(dict(name=name,command=command,environment=effective,exit_code=p.returncode,wall_seconds=time.monotonic()-start))
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(name,p.returncode,flush=True)
    if p.returncode: sys.exit(p.returncode)
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in source.items()),'source changed during validation'
(out/'source-stability.json').write_text(json.dumps({'source_pin_verified':True,'files':len(source)},indent=2)+'\n')
with (out/'toolchain.txt').open('w') as f:
    for command in [['rustc','--version'],['cargo','--version']]:subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=True)
