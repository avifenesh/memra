import hashlib,json,os,pathlib,subprocess,time,sys
root=pathlib.Path.cwd();out=root/'target/541-draft-pair';harness=root/'research/modelplan-onboarding-bound-census-20260920/draft-pair-20260921/consumer-harness'
old=json.loads((out/'source-pin.json').read_text());source={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in old}
assert {p for p in old if old[p]!=source[p]}=={str((harness/'src/lib.rs').relative_to(root))}
(out/'source-pin.json').write_text(json.dumps(source,indent=2)+'\n')
results=[r for r in json.loads((out/'results.json').read_text()) if r['name'] in ['source-tests','source-clippy','engine-clippy','format']];assert len(results)==4 and all(r['exit_code']==0 for r in results)
env_values={'CARGO_INCREMENTAL':'0','CARGO_TARGET_DIR':str(root/'target'),'CARGO_BUILD_JOBS':'2'}
checks=[
 ('consumer-tests',['cargo','test','--locked','--offline','--manifest-path',str(harness/'Cargo.toml'),'--','--nocapture'],{}),
 ('consumer-clippy',['cargo','clippy','--locked','--offline','--manifest-path',str(harness/'Cargo.toml'),'--all-targets','--','-D','warnings'],{}),
 ('consumer-format',['cargo','fmt','--manifest-path',str(harness/'Cargo.toml'),'--','--check'],{}),
 ('diff',['git','diff','--check'],{}),
]
for name,command,extra in checks:
 start=time.monotonic();effective=env_values|extra
 with (out/(name+'-final.log')).open('w') as f:p=subprocess.run(command,env=os.environ|effective,stdout=f,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=command,environment=effective,exit_code=p.returncode,wall_seconds=time.monotonic()-start))
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in source.items())
(out/'source-stability.json').write_text(json.dumps({'source_pin_verified':True,'files':len(source),'source_tests_and_source_clippy':'Retained from unchanged production/source-test bytes; Only harness formatting changed; source and engine bytes unchanged.'},indent=2)+'\n')
with (out/'toolchain.txt').open('w') as f:
 for command in [['rustc','--version'],['cargo','--version']]:subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=True)
