impl MtpHead {
    /// Opt-in paired source receipt; shared rewrite admission still refuses external drafts.
    pub fn load_paired_draft(
        e: &Engine,
        target: &dyn TensorSource,
        draft: &GgufFile,
    ) -> Result<
        (
            Self,
            memra_gguf::bound_source::draft_pair::DraftSourcePairIdentity,
        ),
        Box<dyn std::error::Error>,
    > {
        let target = memra_gguf::bound_source::draft_pair::PreparedDraftTarget::bind(target)?;
        let (loaded, identity) = target.with_external(draft, |prepared, source| {
            Self::load_prepared_draft(e, source, prepared, target.config())
        })?;
        Ok((loaded?, identity))
    }

    /// Ordered-component counterpart of load_paired_draft, with the same source-only scope.
    pub fn load_paired_composite_draft(
        e: &Engine,
        target: &dyn TensorSource,
        draft: &memra_gguf::bound_source::draft::composite::CompositeExternalDraftInput,
    ) -> Result<
        (
            Self,
            memra_gguf::bound_source::draft_pair::DraftSourcePairIdentity,
        ),
        Box<dyn std::error::Error>,
    > {
        let target = memra_gguf::bound_source::draft_pair::PreparedDraftTarget::bind(target)?;
        let (loaded, identity) = target.with_composite_external(draft, |prepared, source| {
            Self::load_prepared_draft(e, source, prepared, target.config())
        })?;
        Ok((loaded?, identity))
    }

}
