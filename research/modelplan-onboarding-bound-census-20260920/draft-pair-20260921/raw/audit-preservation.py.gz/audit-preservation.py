import hashlib,json,pathlib,subprocess,os,tomllib
root=pathlib.Path.cwd(); out=root/'target/541-draft-pair'; base='ab9dcfc00853d40c76bc842b77696e15d4509f73'
changed={'crates/memra-gguf/src/bound_source.rs','crates/memra-gguf/src/bound_source/tests.rs','crates/memra-engine/src/hybrid.rs'}
rows=subprocess.check_output(['git','ls-tree','-r',base,'crates']).decode().splitlines()
protected={}
for row in rows:
    meta,path=row.split('\t');mode,kind,oid=meta.split()
    if path in changed:continue
    data=(root/path).read_bytes()
    actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    assert actual==oid,path
    actual_mode='100755' if (root/path).stat().st_mode&0o111 else '100644'
    assert actual_mode==mode,path
    protected[path]={'git_blob':oid,'sha256':hashlib.sha256(data).hexdigest(),'mode':mode}
hybrid='crates/memra-engine/src/hybrid.rs'
old=subprocess.check_output(['git','show',base+':'+hybrid]).decode();new=(root/hybrid).read_text()
start=new.index('    /// Opt-in paired source receipt;')
end=new.index('    /// Typed composite intake;',start)
assert new[:start]+new[end:]==old,'hybrid changed outside new method'
entry=new[start:end]
assert 'target.with_external(draft, |prepared, source|' in entry
assert 'target.with_composite_external(draft, |prepared, source|' in entry
assert entry.count('Self::load_prepared_draft(e, source, prepared, target.config())')==2
body=old[old.index('    fn load_prepared_draft('):old.index('    fn load_prepared_draft(')+20000]
assert body.index('let external_source_identity = prepared.artifact_identity()?;')<body.index('let head = load_t(e, src, head_name)?;')
harness=root/'research/modelplan-onboarding-bound-census-20260920/draft-pair-20260921/consumer-harness'
root_lock=tomllib.loads((root/'Cargo.lock').read_text())
harness_lock=tomllib.loads((harness/'Cargo.lock').read_text())
registry=lambda lock:{(p['name'],p['version']):p for p in lock['package'] if 'source' in p}
rl=registry(root_lock);hl=registry(harness_lock)
for key,p in hl.items():
    assert all(rl[key].get(field)==p.get(field) for field in ['name','version','source','checksum']),key
other_preserved={}
for path in ['Cargo.toml','Cargo.lock','crates/memra-engine/src/plan_backend.rs','crates/memra-gguf/src/config.rs','research/modelplan-onboarding-bound-census-20260920/draft-repair-20260921/consumer-harness/src/fixture.rs']:
    data=(root/path).read_bytes();assert data==subprocess.check_output(['git','show',base+':'+path]),path
    other_preserved[path]=hashlib.sha256(data).hexdigest()

for path,addition in [('crates/memra-gguf/src/bound_source.rs','pub mod draft_pair;\n'),('crates/memra-gguf/src/bound_source/tests.rs','mod draft_pair;\n')]:
    original=subprocess.check_output(['git','show',base+':'+path]).decode()
    assert (root/path).read_text().replace(addition,'',1)==original,path
matches=list((root/'target/debug/build').glob('memra-draft-pair-host-*/out/paired-entry.rs'))
expected='impl MtpHead {\n'+entry+'}\n'
assert matches
for path in matches:assert path.read_text()==expected,path
(out/'extracted-paired-entry.rs').write_text(expected)

receipt={'base':base,'protected_crate_files':protected,'other_preserved':other_preserved,'engine_delta':'Removing only the two new paired source methods and its documentation restores hybrid.rs byte-for-byte to base; existing standalone/prepared consumer bodies, public layouts and four trim sites unchanged.','consumer_trace':'The two new typed methods invoke PreparedDraftTarget with_external/with_composite_external then existing load_prepared_draft; existing consumer captures prepared.artifact_identity before allocation and stores external_source_identity unchanged.','new_method_sha256':hashlib.sha256(entry.encode()).hexdigest(),'harness_registry_versions_checksums_equal_to_root':len(hl)}
(out/'preservation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'protected_crate_files':len(protected),'harness_registry_packages':len(hl),'engine_delta_only_two_new_typed_methods':True}))
