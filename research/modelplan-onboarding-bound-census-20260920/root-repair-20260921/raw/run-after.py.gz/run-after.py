from pathlib import Path
import subprocess,os,json,time,shutil,hashlib
root=Path.cwd();out=root/'target/541-root-repair';probe=root/'target/541-root-repair-probe'
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(root/'target'),CARGO_BUILD_JOBS='2')
commands=[]
for name,binary,fixture in [('after-moe','reviewer-root-gemma-moe','fixture'),('after-dense','dense','fixture-dense')]:
    commands.append((name,['cargo','run','--locked','--offline','--manifest-path',str(probe/'Cargo.toml'),'--bin',binary,'--',str(probe/fixture)],binary))
for name,selector in [('gemma-controls','gemma_runtime'),('existing-runtime-controls','runtime_adapter'),('existing-composite-controls','prepared_root_composite'),('existing-draft-controls','bound_source::draft::tests')]:
    commands.append((name,['cargo','test','--locked','--offline','-p','memra-gguf','--lib',selector,'--','--nocapture'],None))
commands.extend([('source-clippy',['cargo','clippy','--locked','--offline','-p','memra-gguf','--all-targets','--','-D','warnings'],None),('format',['cargo','fmt','--all','--','--check'],None),('diff',['git','diff','--check'],None)])
results=[]
for name,cmd,binary in commands:
    start=time.monotonic()
    with (out/f'{name}.log').open('wb') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
    results.append({'name':name,'command':cmd,'environment':{'CARGO_INCREMENTAL':'0','CARGO_TARGET_DIR':str(root/'target'),'CARGO_BUILD_JOBS':'2'},'exit_code':r.returncode,'wall_seconds':time.monotonic()-start})
    if binary and r.returncode==0:
        executable=root/'target/debug'/binary;dest=out/f'{name}-cpu';shutil.copyfile(executable,dest);dest.chmod(executable.stat().st_mode&0o777)
        results[-1]['binary_sha256']=hashlib.sha256(dest.read_bytes()).hexdigest()
    (out/'after-results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(name,r.returncode,flush=True)
    if r.returncode:raise SystemExit(r.returncode)
for path,digest in json.loads((out/'source-pin.json').read_text()).items():assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,path
print('All pinned affected checks passed.',flush=True)
