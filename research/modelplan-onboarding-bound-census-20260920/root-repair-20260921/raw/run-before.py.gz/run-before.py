from pathlib import Path
import subprocess,os,json,time,shutil,hashlib
root=Path.cwd();out=root/'target/541-root-repair';probe=root/'target/541-root-repair-probe'
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(root/'target'),CARGO_BUILD_JOBS='2')
results=[]
for name,binary,fixture in [('moe','reviewer-root-gemma-moe','fixture'),('dense','dense','fixture-dense')]:
    cmd=['cargo','run','--locked','--offline','--manifest-path',str(probe/'Cargo.toml'),'--bin',binary,'--',str(probe/fixture)]
    with (out/f'before-{name}.log').open('wb') as log:
        start=time.monotonic();r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
    results.append({'phase':'before','name':name,'command':cmd,'exit_code':r.returncode,'wall_seconds':time.monotonic()-start})
    assert r.returncode==101,(name,r.returncode)
    executable=root/'target/debug'/binary;dest=out/f'before-{name}-cpu';shutil.copyfile(executable,dest);dest.chmod(executable.stat().st_mode&0o777)
    results[-1]['binary_sha256']=hashlib.sha256(dest.read_bytes()).hexdigest()
(out/'before-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
