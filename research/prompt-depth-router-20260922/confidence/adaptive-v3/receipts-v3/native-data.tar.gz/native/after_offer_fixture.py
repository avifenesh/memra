"""GPU small-vocabulary check of the after-offer acceptance law."""

import json
import torch


def trial(target, proposal, cutoff, trials):
    device = "cuda"
    p = torch.tensor(target, dtype=torch.float64, device=device)
    q = torch.tensor(proposal, dtype=torch.float64, device=device)
    picks = torch.multinomial(q, trials, replacement=True)
    uniforms = torch.rand(trials, device=device, dtype=torch.float64)
    accepts = uniforms < torch.minimum(torch.ones_like(picks, dtype=torch.float64), p[picks] / q[picks])
    residual = torch.maximum(p - q, torch.zeros_like(p))
    residual = residual / residual.sum() if residual.sum() > 0 else p
    replacements = torch.multinomial(residual, trials, replacement=True)
    corrected = torch.where(accepts, picks, replacements)
    # Model the old chosen-token censor with a fresh target draw.
    censored = q[picks] < cutoff
    target_draw = torch.multinomial(p, trials, replacement=True)
    old = torch.where(censored, target_draw, corrected)
    new_freq = torch.bincount(corrected, minlength=len(target)).double() / trials
    old_freq = torch.bincount(old, minlength=len(target)).double() / trials
    return {
        "target": target,
        "proposal": proposal,
        "cutoff": cutoff,
        "new": new_freq.cpu().tolist(),
        "old": old_freq.cpu().tolist(),
    }


torch.manual_seed(20771000)
cases = (
    ([0.8, 0.2], [0.8, 0.2], 0.5),
    ([0.5, 0.5], [0.9, 0.1], 0.7),
)
results = [trial(*case, 1_000_000) for case in cases]
for result in results:
    if any(abs(actual - target) > 0.003 for actual, target in zip(result["new"], result["target"])):
        raise SystemExit("GPU after-offer law differed from target")
if abs(results[0]["old"][0] - 0.96) > 0.003:
    raise SystemExit("GPU fixture did not reproduce chosen-token censoring")
print(json.dumps({"device": torch.cuda.get_device_name(0), "cases": results}, sort_keys=True))
