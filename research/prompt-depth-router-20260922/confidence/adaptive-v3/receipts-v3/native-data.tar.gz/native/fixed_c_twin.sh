#!/bin/bash
set -euo pipefail
root=/root/qwen-adaptive-v3-results
binary=/root/qwen-adaptive-v3-source/repo/target/release/mtp-depth-study
model=/root/qwen-adaptive-v3-model/Qwen3.8-27B-NVFP4-Q5K-mtp.gguf
workload=/root/qwen-adaptive-v3-stage/confidence/adaptive-v3/workloads-v3/heldout-0.txt
cp /root/qwen-adaptive-v3-stage/fixed_c_twin.sh "$root/fixed_c_twin.sh"
export MEMRA_SPEC_ADAPT=0
export MEMRA_SPEC_ADAPT_FLOOR=1
export MEMRA_SPEC_CAPMAX=7
export MEMRA_SPEC_PMIN=0
export MEMRA_SPEC_PMIN0=0
export MEMRA_SPEC_PMIN_INROUND=0
export MEMRA_SPEC_STATS=1
"$binary" "$model" embedded "$workload" "$root/fixed-c3-twin" \
    fixed-c3 20773000 8192 65536 0.7 \
    confidence-fixed=0.43497753143310547,0.850344181060791 \
    > "$root/fixed-c3-twin.stdout.log" 2> "$root/fixed-c3-twin.stderr.log"
for turn in {1..8}; do
    cmp "$root/fixed-c3-twin/turn-$turn.output.ids" \
        "$root/heldout-0-fixed-c3/turn-$turn.output.ids"
done
printf '%s\n' "positive-C sampled twin matched all eight token tapes"
