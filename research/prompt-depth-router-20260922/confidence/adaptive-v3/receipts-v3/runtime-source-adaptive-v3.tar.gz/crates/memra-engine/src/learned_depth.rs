//! Explicit study policies: a fixed control or a persistent contextual controller.
use std::sync::Arc;
use std::time::Duration;

#[derive(Clone, Debug)]
pub struct DepthStats {
    /// Verification rows, including the bonus token (K + 1).
    pub depth: usize,
    pub rounds: u64,
    pub tokens: u64,
    pub elapsed: Duration,
    pub blocks: u64,
    pub tokens_per_second: Option<f64>,
}

#[derive(Clone, Debug)]
pub struct LearnedDepth {
    context: Option<Box<crate::context_depth::ContextDepth>>,
    stats: Vec<DepthStats>,
    fixed_depth: usize,
}

fn stat(depth: usize) -> DepthStats {
    DepthStats {
        depth,
        rounds: 0,
        tokens: 0,
        elapsed: Duration::ZERO,
        blocks: 0,
        tokens_per_second: None,
    }
}

impl LearnedDepth {
    pub fn fixed(depth: usize) -> Result<Self, &'static str> {
        if !(2..=crate::context_depth::MAX_K + 1).contains(&depth) {
            return Err("fixed verification depth is out of range");
        }
        Ok(Self {
            context: None,
            stats: vec![stat(depth)],
            fixed_depth: depth,
        })
    }

    pub fn contextual(
        priors: crate::context_depth::Priors,
        token_bytes: Arc<Vec<Vec<u8>>>,
        online: bool,
    ) -> Result<Self, &'static str> {
        if !(1..=crate::context_depth::MAX_K).contains(&priors.cap)
            || !(1..=priors.cap).contains(&priors.global_k)
        {
            return Err("invalid contextual depth range");
        }
        Ok(Self {
            stats: (2..=priors.cap + 1).map(stat).collect(),
            fixed_depth: priors.global_k + 1,
            context: Some(Box::new(crate::context_depth::ContextDepth::new(
                priors,
                token_bytes,
                online,
            ))),
        })
    }

    pub fn depth(&self) -> usize {
        self.context
            .as_ref()
            .map_or(self.fixed_depth, |c| c.depth())
    }
    pub fn stats(&self) -> &[DepthStats] {
        &self.stats
    }
    pub fn switches(&self) -> u64 {
        self.context.as_ref().map_or(0, |c| c.switches())
    }
    pub fn context(&self) -> Option<&crate::context_depth::ContextDepth> {
        self.context.as_deref()
    }
    pub fn begin_request(&mut self, prompt: &str) {
        if let Some(c) = &mut self.context {
            c.begin_request(prompt);
        }
    }
    pub fn prepare_output(&mut self, output: &[u32]) -> Result<(), &'static str> {
        if let Some(c) = &mut self.context {
            c.prepare_output(output)?;
        }
        Ok(())
    }
    pub fn observe_output(
        &mut self,
        depth: usize,
        output_start: usize,
        output: &[u32],
        elapsed: Duration,
        eligible: bool,
    ) -> Result<(), &'static str> {
        if depth != self.depth() || output_start > output.len() || elapsed.is_zero() {
            return Err("invalid depth observation");
        }
        let emitted = output.len() - output_start;
        if eligible && (emitted == 0 || emitted > depth) {
            return Err("invalid committed-token count");
        }
        if let Some(context) = &mut self.context {
            context.observe(depth, output_start, output, elapsed, eligible)?;
        }
        if eligible {
            let s = self
                .stats
                .iter_mut()
                .find(|s| s.depth == depth)
                .ok_or("unknown observed depth")?;
            s.rounds += 1;
            s.tokens += emitted as u64;
            s.elapsed += elapsed;
            s.blocks = s.rounds / 8;
            s.tokens_per_second = Some(s.tokens as f64 / s.elapsed.as_secs_f64());
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn controls_do_not_reserve_inline_context_learning_state() {
        assert!(std::mem::size_of::<LearnedDepth>() <= 64);
    }
    #[test]
    fn fixed_control_refuses_bad_observations_and_excludes_terminal_rounds() {
        assert!(LearnedDepth::fixed(1).is_err());
        let mut p = LearnedDepth::fixed(3).unwrap();
        assert!(
            p.observe_output(2, 0, &[1], Duration::from_millis(1), true)
                .is_err()
        );
        assert!(
            p.observe_output(3, 0, &[1, 2, 3, 4], Duration::from_millis(1), true)
                .is_err()
        );
        assert_eq!(p.stats()[0].rounds, 0);
        p.observe_output(3, 0, &[1], Duration::from_millis(1), true)
            .unwrap();
        p.observe_output(3, 1, &[1, 2], Duration::from_millis(1), false)
            .unwrap();
        assert_eq!(p.stats()[0].rounds, 1);
        assert_eq!(p.stats()[0].tokens, 1);
        assert_eq!(p.depth(), 3);
    }
}
