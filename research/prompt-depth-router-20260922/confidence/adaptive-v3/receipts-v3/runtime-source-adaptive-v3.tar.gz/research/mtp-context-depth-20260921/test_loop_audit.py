import unittest
from loop_audit import loop_candidate


class RepeatScreenTests(unittest.TestCase):
    def test_long_exact_cycle_is_flagged(self):
        result = loop_candidate(list(range(48)) * 8)
        self.assertIsNotNone(result)
        self.assertGreaterEqual(result["repeated_tokens"], 256)

    def test_changing_numeric_rows_are_not_an_exact_loop(self):
        ids = [value for row in range(100) for value in [999, row, 998, row * row]]
        self.assertIsNone(loop_candidate(ids))

    def test_short_repetition_is_not_a_long_loop(self):
        self.assertIsNone(loop_candidate([1, 2, 3] * 20))


if __name__ == "__main__":
    unittest.main()
