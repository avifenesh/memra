"""Freeze global and context-conditioned controls from disjoint calibration only."""
import collections
import json
from pathlib import Path
from audit_context import audit_run


def freeze(root, family, groups, maximum):
    root = Path(root)
    totals = collections.defaultdict(lambda: [0, 0, 0])
    rates = {}
    for k in range(1, maximum + 1):
        arm = f"k{k}"
        records = [next(r for r in g["records"] if r["arm"] == arm) for g in groups]
        rates[k] = sum(r["tokens"] for r in records) / sum(r["elapsed_s"] for r in records)
        for group in groups:
            run = root / group["receipt_dir"] / f'{group["seed"]}-{arm}'
            audit = audit_run(run, arm, maximum)
            for label, values in audit["observations"].items():
                kind, observed_k = label.split(":")
                if int(observed_k) != k:
                    raise ValueError("fixed-depth calibration did not hold its K")
                for context in [kind, "all"]:
                    cell = totals[context, k]
                    for j, value in enumerate(values): cell[j] += value
    winner = min(rates, key=lambda k: (-rates[k], k))
    path = root / f"{family}-priors.tsv"
    with path.open("x") as f:
        f.write(f"global_k\t{winner}\ncontext\tk\trounds\ttokens\telapsed_ns\n")
        for context in ["all", "prose", "code", "numeric"]:
            for k in range(1, maximum + 1):
                n, tokens, ns = totals[context, k]
                if context == "all" and not n:
                    raise ValueError("empty fixed-depth calibration")
                f.write(f"{context}\t{k}\t{n}\t{tokens}\t{ns}\n")
    coverage = {c: {k: totals[c, k][0] for k in rates} for c in ("prose", "code", "numeric")}
    return winner, path, {"pooled_calibration_tok_s": rates, "context_rounds": coverage,
                          "calibration": groups,
                          "rule": "global pooled request throughput; context round cost with measured global backoff below 32 rounds"}
