import csv
import tempfile
import unittest
from pathlib import Path
from audit_context import audit_pairs


class PairedEvidenceTests(unittest.TestCase):
    def fixture(self, root):
        priors = root / "priors.tsv"
        text = "global_k\t2\ncontext\tk\trounds\ttokens\telapsed_ns\n"
        for kind in ("all", "prose", "code", "numeric"):
            for k in (1, 2):
                text += f"{kind}\t{k}\t64\t64\t{64000 if k == 2 else 66560}\n"
        priors.write_text(text)
        for turn in range(1, 9):
            (root / f"turn-{turn}.user.txt").write_text("Explain.")
        fields = ["turn", "context", "incumbent", "candidate", "before_start", "end_round",
                  "before_tokens", "before_ns", "trial_tokens", "trial_ns",
                  "after_tokens", "after_ns", "gain", "stable", "confirmations", "adopted"]
        pairs = []
        events = []
        for turn in (1, 2):
            pairs.append(dict(zip(fields, map(str, [
                turn, "prose", 2, 1, 1, 20, 8, 8000, 4, 2000, 8, 8000, 1.0,
                "true", turn, "true" if turn == 2 else "false",
            ]))))
            for i in range(1, 21):
                trial = 9 <= i <= 12
                k = 1 if trial else 2
                reason = "probe" if i == 8 else "probe_return" if i == 12 else "hold"
                next_k = 1 if i == 8 or 9 <= i < 12 else 2
                if i == 20:
                    reason = "adopt" if turn == 2 else "pair_complete"
                    next_k = 1 if turn == 2 else 2
                events.append({"turn": str(turn), "k": str(k), "next_k": str(next_k),
                               "reason": reason, "eligible": "true",
                               "context_before": "prose", "context_after": "prose",
                               "output_start": str(i - 1), "output_end": str(i),
                               "elapsed_ns": str(500 if trial else 1000)})
        self.write_pairs(root, fields, pairs)
        return priors, fields, pairs, events

    def write_pairs(self, root, fields, pairs):
        with (root / "context-pairs.tsv").open("w") as f:
            w = csv.DictWriter(f, fields, delimiter="\t")
            w.writeheader(); w.writerows(pairs)

    def test_two_distinct_prompt_comparisons_support_one_adoption(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d); priors, _, _, events = self.fixture(p)
            result = audit_pairs(p, events, 2, priors)
            self.assertEqual(result["adoptions"], 1)
            self.assertEqual(result["final_preferred_k"]["prose"], 1)

    def test_one_prompt_cannot_claim_two_confirmations(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d); priors, fields, pairs, events = self.fixture(p)
            pairs[0]["confirmations"] = "2"; pairs[0]["adopted"] = "true"
            self.write_pairs(p, fields, pairs)
            with self.assertRaisesRegex(ValueError, "two prompts"):
                audit_pairs(p, events, 2, priors)

    def test_costs_must_match_the_actual_bracketing_rounds(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d); priors, _, _, events = self.fixture(p)
            events[0]["elapsed_ns"] = "2000"
            with self.assertRaisesRegex(ValueError, "actual round costs"):
                audit_pairs(p, events, 2, priors)

    def test_context_crossing_is_not_a_valid_local_comparison(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d); priors, _, _, events = self.fixture(p)
            events[9]["context_after"] = "code"
            with self.assertRaisesRegex(ValueError, "context or terminal"):
                audit_pairs(p, events, 2, priors)


if __name__ == "__main__":
    unittest.main()
