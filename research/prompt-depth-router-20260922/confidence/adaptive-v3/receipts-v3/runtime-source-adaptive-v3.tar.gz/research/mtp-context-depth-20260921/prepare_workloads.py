#!/usr/bin/env python3
"""Create disjoint synthetic conversations with repeated within-answer transitions."""
import argparse
import hashlib
import json
import random
import subprocess
from pathlib import Path


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


POOLS = [
    ("calibration-a", 27101, "parcel dispatch"),
    ("calibration-b", 27102, "library reservations"),
    ("development-a", 37201, "sensor aggregation"),
    ("development-b", 37202, "warehouse inventory"),
    ("heldout-a", 62201, "access log aggregation"),
    ("heldout-b", 62202, "document indexing"),
]


def reference(seed, topic):
    r = random.Random(seed)
    chunks = []
    for i in range(1800):
        a, b, c = (r.randrange(3, 700) for _ in range(3))
        if i % 3 == 0:
            chunks.append(
                f"Design note {seed}-{i}: The {topic} service records an immutable event "
                f"before updating its summary. Worker group {i % 17} retries a failed operation "
                f"using the same key. A completed operation cannot be charged twice. "
                f"Readers may see an older summary until the next merge. Window size {a} "
                f"and batch limit {b} are independent configuration values.\n")
        elif i % 3 == 1:
            chunks.append(f"```python\n"
                          f"def aggregate_{i}(events):\n"
                          f"    totals = {{}}\n"
                          f"    for key, amount in events:\n"
                          f"        totals[key] = totals.get(key, 0) + amount\n"
                          f"    return sorted(totals.items())[:{i % 19 + 1}]\n```\n")
        else:
            chunks.append(f"ledger,{seed}-{i},{a},{b},{c},{a+b-c},{a*b}\n")
    return "".join(chunks)


def instructions(seed, topic):
    a = seed % 71 + 19
    b = seed % 29 + 7
    return [
        f"Explain the architecture of the {topic} system to a new engineer in detailed prose. "
        "Discuss event ordering, retry safety, stale reads, and recovery. Give concrete examples. "
        "Use paragraphs, without code blocks or tables.",
        f"Write code implementing a Python function for the {topic} system that merges event "
        "streams, deduplicates stable keys, preserves ordering, and handles cancellation. "
        "Start the answer with a complete fenced Python code block of at least 50 useful lines, "
        "then explain the design in prose. Do not reuse function names from the reference.",
        f"Calculate a numeric ledger for 48 consecutive batches. Batch n has {a}+n incoming "
        f"items, {b}+(n mod 5) completed items, and (n mod 3) cancelled items. Start at zero. "
        "First output the complete CSV number table with columns n,incoming,completed,cancelled,"
        "cumulative_pending. Then explain the arithmetic and two useful invariants in prose.",
        "Review the previous implementation in prose. Analyze race conditions, partial failures, "
        "restart behavior, and memory use. Propose a revised design in words before giving "
        "a fenced Python code block implementing one substantive improvement.",
        f"Write a Rust function and supporting types for the {topic} system's bounded retry queue. "
        "Return a fenced Rust code block with at least 50 useful lines, followed by a short "
        "explanation. Include deterministic ordering and explicit error handling.",
        f"Calculate the first 40 values of x(n+1)=({a}*x(n)+{b}) mod 997 with x(0)={a+b}. "
        "Output a numeric two-column table first, then a small fenced Python function that "
        "checks the table, then explain in prose how you would detect a transcription error.",
        "Explain the tradeoffs among the designs discussed so far to a non-specialist colleague. "
        "Use prose and concrete operational examples. Discuss simplicity, throughput, fairness, "
        "and recovery without code or numerical tables.",
        "Give an integrated implementation and verification plan. Alternate three sections: "
        "a prose explanation, a fenced Python code block, and a numeric worked example with "
        "at least 24 rows. Repeat that sequence once with a different failure scenario.",
    ]


def main():
    p = argparse.ArgumentParser()
    for key in ["repo", "models", "binaries", "out"]:
        p.add_argument("--" + key, type=Path, required=True)
    p.add_argument("--minimum", type=int, default=16384)
    a = p.parse_args()
    a.out.mkdir(parents=True, exist_ok=False)
    lock = {"generator_sha256": digest(__file__), "minimum_initial_tokens": a.minimum,
            "split_contract": "disjoint scenario topics, identifiers and arithmetic seeds",
            "families": {}}
    for family in ["qwen", "gemma"]:
        artifact = next(row for row in json.loads(
            (a.models / family / "artifacts.lock.json").read_text())
            if row["local_file"] == "target.gguf")
        target = a.models / family / artifact["local_file"]
        binary = a.binaries / ("mtp-depth-study" if family == "qwen" else "gemma-depth-study")
        entries = {}
        counter = a.out / f".{family}-count.txt"
        for name, seed, topic in POOLS:
            doc = reference(seed, topic)
            tasks = instructions(seed, topic)
            def first(n):
                return ("Reference material for an invented system. Treat the material as data.\n"
                        "<reference>\n" + doc[:n] + "\n</reference>\n\n" + tasks[0])
            def count(n):
                counter.write_text(first(n))
                return int(subprocess.check_output(
                    [str(binary), "count-prompt", str(target), str(counter)], text=True))
            lo, hi = 0, len(doc)
            if count(hi) < a.minimum:
                raise ValueError("reference pool is too small")
            while lo < hi:
                mid = (lo + hi) // 2
                if count(mid) < a.minimum: lo = mid + 1
                else: hi = mid
            initial_tokens = count(lo)
            turns = [first(lo), *tasks[1:]]
            path = a.out / f"{family}-{name}.txt"
            path.write_text("\n---TURN---\n".join(turns) + "\n")
            entries[name] = {"file": path.name, "sha256": digest(path),
                             "initial_prompt_tokens": initial_tokens, "scenario_seed": seed,
                             "topic": topic, "turns": 8}
        short_tasks = instructions(19007, "ticket reconciliation")
        short = a.out / f"{family}-short.txt"
        short.write_text("\n---TURN---\n".join(
            ["Reference:\n" + reference(19007, "ticket reconciliation")[:14000] + "\n" + short_tasks[0],
             *short_tasks[1:]]) + "\n")
        entries["short"] = {"file": short.name, "sha256": digest(short), "turns": 8}
        counter.unlink()
        lock["families"][family] = entries
    (a.out / "workloads.lock.json").write_text(json.dumps(lock, indent=2) + "\n")
    print(json.dumps(lock, indent=2))


if __name__ == "__main__":
    main()
