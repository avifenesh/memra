import csv
import tempfile
import unittest
from pathlib import Path
from audit_context import audit_run


class CausalAuditTests(unittest.TestCase):
    def fixture(self, root):
        (root / "token-bytes.tsv").write_text(
            "id\thex\n" + "".join(f"{i}\t{b.hex()}\n" for i, b in enumerate(
                [b"word " * 30, b"```python\n", b"return value\n"])))
        (root / "context-events.tsv").write_text("turn\tround\n")
        with (root / "turns.tsv").open("w") as turns, (root / "spans.tsv").open("w") as spans:
            turns.write("turn\tpolicy_rounds\n")
            spans.write("turn\tround\tcontext_before\tcontext_after\tk\toutput_start\toutput_end\telapsed_ns\teligible\n")
            for t in range(1, 9):
                turns.write(f"{t}\t2\n")
                spans.write(f"{t}\t1\tprose\tprose\t2\t0\t1\t1000\ttrue\n")
                spans.write(f"{t}\t2\tprose\tcode\t2\t1\t3\t2000\ttrue\n")
                (root / f"turn-{t}.user.txt").write_text("Explain this.")
                for suffix in ("output", "committed"):
                    (root / f"turn-{t}.{suffix}.ids").write_text("0\n1\n2\n")

    def test_accepts_a_causal_tape(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d); self.fixture(p)
            result = audit_run(p, "k2", 3)
            self.assertEqual(result["rounds"], 16)
            self.assertEqual(result["context_transitions"], 8)
            self.assertEqual(result["observations"]["prose:2"], [16, 24, 24000])

    def test_rejects_using_the_next_span_to_label_the_current_action(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d); self.fixture(p)
            f = p / "spans.tsv"
            f.write_text(f.read_text().replace("1\t2\tprose\tcode", "1\t2\tcode\tcode", 1))
            with self.assertRaisesRegex(ValueError, "committed byte prefix"):
                audit_run(p, "k2", 3)

    def test_rejects_learning_from_unreturned_output(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d); self.fixture(p)
            (p / "turn-1.output.ids").write_text("0\n")
            with self.assertRaisesRegex(ValueError, "terminal overshoot"):
                audit_run(p, "k2", 3)


if __name__ == "__main__":
    unittest.main()
