# Context-conditioned MTP depth

This experiment tests whether the useful draft depth changes with generated
content, and whether learning that relationship across a conversation improves
complete-request throughput.

The controller observes the current prompt and committed output. It retains
separate cost estimates for prose, code and numeric spans, with calibration as
the shared starting prior. These are measured contexts, not rules that prescribe
a larger K for code or numbers. A familiar context can immediately reuse its
preferred depth; new information updates that preference within and across
requests.

Controls are native adaptation, a calibrated global fixed K, and a calibrated
context-conditioned policy with its estimates frozen. The online policy uses the
same calibration. Every scored arm uses the same native prompt-checkpoint reuse
contract. The primary metric is total returned output tokens divided by total
native request seconds, including classification, adaptation, suffix processing,
generation and detokenization.

Calibration, development and held-out workload pools are disjoint. Policy choices
are frozen before held-out scoring. Conversations exercise prose, code, numeric
work and transitions within replies. Context decisions never consume benchmark
labels or future output.

Work is in progress. There is no performance verdict or runtime default change.

The current implementation uses a 128-byte window of committed output, Markdown
fence state, and a short prompt-derived hint. Dense numeric runs take precedence
over fences, so a CSV table inside a fence can be distinguished from code. These
are inexpensive observable features, not a semantic classifier or a prescribed
ordering of depths.

The calibration file contains measured tokens, rounds and time for every allowed
K, globally and by context. Contexts with fewer than 32 calibration rounds at a
depth use the measured global curve for that depth. Both context policies start
their first round at the globally calibrated K.

The revised online policy keeps a preferred K for each context. A familiar
context reuses that preference immediately. Changing the preference requires
an adjacent-depth comparison: eight incumbent rounds, four candidate rounds,
and eight more incumbent rounds, all within the same context and request.
The before/after incumbent rates must agree within 10%, and the candidate must
improve the pooled local rate by more than 2%. Two distinct prompts must support
the same move. Multiple comparisons in one prompt count only once.

Probes are considered after 128 eligible rounds in a context when a neighboring
calibration is close or observed cost has changed. Ordinary timing estimates
remain diagnostics; they are not compared against stale untried rates to change
K. Incomplete comparisons are abandoned at context/request boundaries, while
all observed counts, established preferences and confirmation history persist.
Terminally truncated rounds never update the learner; their time remains in
the request denominator. Every completed comparison is recorded and independently
reconstructed from its actual 8/4/8 round costs.

The frozen-context control uses the same calibration and classifier but never
updates the cost estimates. Native and fixed controls reconstruct span labels
after their request clocks stop. They therefore do not pay for a classifier
that their policies do not need. Online policy events must agree with an
independent replay from exact token bytes and committed output offsets.

The planned scored matrix has ten balanced five-policy sets per model, each
containing one eight-turn conversation. The two model families are reported
separately. Model loading, token-byte table construction, warmup and receipt I/O
are outside request timing. This is a native-session study with temperature
0.7, top-k 20, top-p 0.95 and a 2,048-token output cap; it does not establish an
HTTP, concurrency or vendor-default serving result.

The first forward calibration set was excluded after one sampled response
repeated a 48-token numeric cycle over at least 288 tokens. The entire seven-arm
set is retained as excluded evidence. Its replacement seed, 20271100, was
recorded before running the replacement. The valid reverse calibration and
fixed-depth gates are reused only after verifying the same binary, source,
workload and audit hashes. Any further exact-repeat candidate in a sampled
matched set stops advancement for review. There is no throughput-based,
minimum-duration or response-length filtering.

The initial controller's development results were banked before revising its
update rule. No held-out outcome was used to choose this revision. The revised
study uses fresh held-out topics and seeds; the earlier partial held-out run is
retained separately and is not part of the new score.
