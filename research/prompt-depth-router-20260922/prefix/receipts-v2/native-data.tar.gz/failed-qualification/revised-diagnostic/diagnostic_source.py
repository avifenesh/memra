"""Check final prose/code coverage at the registered prompt lengths."""

import csv
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


ROOT = Path("/opt/adaptive")
OUT = ROOT / "receipts/diagnostic-length-coverage-v2"
OUT.mkdir(parents=True, exist_ok=False)
(OUT / "diagnostic_source.py").write_bytes(Path(__file__).read_bytes())
sys.path.insert(0, str(ROOT / "lane/prefix"))
from audit import coverage  # noqa: E402
from workloads import Counter, reference, sized_prompt  # noqa: E402

LENGTHS = (256, 1024, 4096, 16384)
TASKS = {
    "code": (
        "Write a Python module with four simple functions: "
        "add_numbers(a: int, b: int) -> int returns their sum; "
        "subtract_numbers(a: int, b: int) -> int returns their difference; "
        "multiply_numbers(a: int, b: int) -> int returns their product; "
        "is_even(n: int) -> bool reports whether n is even. "
        "Use straightforward implementations. Return one fenced Python code "
        "block only, without a prose explanation."
    ),
    "prose": (
        "Explain in prose what four arithmetic helpers do: addition, subtraction, "
        "multiplication and checking whether an integer is even. Give a worked "
        "example and one edge case for each. Use paragraphs only, without source "
        "code or a table."
    ),
}
SETTINGS = {
    "MEMRA_SPEC_ADAPT": "1",
    "MEMRA_SPEC_ADAPT_FLOOR": "1",
    "MEMRA_SPEC_CAPMAX": "7",
    "MEMRA_SPEC_PMIN": "0",
    "MEMRA_SPEC_PMIN_INROUND": "0",
}


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")


save("status.json", {"state": "preparing", "start_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
started = time.monotonic()
try:
    context = reference(970000, "simple arithmetic utilities")
    prompts = []
    cells = []
    counter = Counter(
        ROOT / "binaries/qwen-prefix-study",
        ROOT / "models/qwen/target.gguf",
        OUT / "tokenizer.stderr",
    )
    try:
        for length in LENGTHS:
            for kind in ("prose", "code"):
                prompt, measured = sized_prompt(counter, TASKS[kind], context, length)
                prompts.append(prompt)
                cells.append(
                    {
                        "kind": kind,
                        "length_target": length,
                        "user_sha256": hashlib.sha256(prompt.encode()).hexdigest(),
                        **measured,
                    }
                )
    finally:
        counter.close()
    workload = OUT / "prompt.txt"
    workload.write_text("\n---TURN---\n".join(prompts) + "\n")
    save("cells.json", cells)
    command = [
        str(ROOT / "binaries/qwen-prefix-study"),
        str(ROOT / "models/qwen/target.gguf"),
        "embedded",
        str(workload),
        str(OUT / "run"),
        "fixed:3",
        "20730003",
        "4096",
        "32768",
        "0.7",
    ]
    save(
        "command.json",
        {
            "argv": command,
            "settings": SETTINGS,
            "workload_sha256": hashlib.sha256(workload.read_bytes()).hexdigest(),
            "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "scope": "separate qualification diagnostic, no scored comparison",
        },
    )
    save("status.json", {"state": "running", "prepared_cells": len(cells)})
    with open("/tmp/memra-gpu.lock", "a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        environment = {
            **os.environ,
            **SETTINGS,
            "LD_LIBRARY_PATH": "/usr/local/cuda-13.1/lib64:"
            + os.environ.get("LD_LIBRARY_PATH", ""),
        }
        with (OUT / "run.log").open("w") as log:
            result = subprocess.run(
                command,
                cwd=ROOT,
                env=environment,
                stdout=log,
                stderr=subprocess.STDOUT,
                timeout=900,
                check=False,
            )
    if result.returncode:
        raise RuntimeError(f"native driver exited {result.returncode}")
    with (OUT / "run/turns.tsv").open() as stream:
        turns = list(csv.DictReader(stream, delimiter="\t"))
    if len(turns) != 8:
        raise ValueError("native driver did not return eight turns")
    checks = []
    for index, (cell, row) in enumerate(zip(cells, turns), 1):
        found = coverage(OUT / "run", index, cell["kind"])
        checks.append(
            {
                "turn": index,
                "kind": cell["kind"],
                "length_target": cell["length_target"],
                "user_tokens": cell["user_tokens"],
                "output_tokens": int(row["output_tokens"]),
                "finish_reason": row["finish_reason"],
                "format_covered": found["requested_format_covered"],
                "answer_bytes": found["answer_bytes"],
                "python_blocks": found["python_blocks"],
            }
        )
    save(
        "status.json",
        {
            "state": "completed",
            "checks": checks,
            "format_covered": sum(row["format_covered"] for row in checks),
            "seconds": time.monotonic() - started,
            "finish_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        },
    )
except BaseException as error:
    save(
        "status.json",
        {
            "state": "failed",
            "error": f"{type(error).__name__}: {error}",
            "seconds": time.monotonic() - started,
            "finish_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        },
    )
    raise
