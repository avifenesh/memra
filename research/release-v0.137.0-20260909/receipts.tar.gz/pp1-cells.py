import fcntl, hashlib, json, os, signal, subprocess, time, urllib.request
from pathlib import Path
r=Path('/root/release-v0137-receipts')
lock=open('/tmp/memra-gpu.lock','a'); print('WAITING_GPU_LOCK',flush=True); fcntl.flock(lock,fcntl.LOCK_EX)
print('GPU_LOCK_ACQUIRED',time.strftime('%FT%TZ',time.gmtime()),flush=True)
binary=Path('/root/release-v0137-target/release/memra-server')
base='http://127.0.0.1:18987'
prompt='Review the following API migration plan. Explain three concrete risks and the checks that would catch them.\n'+('The service accepts streaming requests, tracks cancellation, limits queue wait, and preserves cached conversation prefixes. A deployment must drain active requests and retain accounting records.\n'*32)
results=[]
for shape in ['plain','dflash2']:
 d=r/('pp1-'+shape);d.mkdir(exist_ok=True)
 env={k:v for k,v in os.environ.items() if not k.startswith('MEMRA_')}
 env.update(json.loads((r/'posture.json').read_text()))
 if shape=='plain':
  env.update(MEMRA_SERVE_SPEC='0',MEMRA_HYPER_BATCH='0',MEMRA_GLM5_SPEC='0')
  env.pop('MEMRA_GLM5_DFLASH',None)
 (d/'env.json').write_text(json.dumps({k:v for k,v in env.items() if k.startswith('MEMRA_')},indent=2))
 (d/'source.sha').write_text(subprocess.check_output(['git','-C','/root/wt-release-v0137','rev-parse','HEAD']).decode())
 (d/'binary.sha256').write_text(hashlib.sha256(binary.read_bytes()).hexdigest())
 log=(d/'server.log').open('wb'); start=time.monotonic()
 server=subprocess.Popen([str(binary)],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (d/'pid').write_text(str(server.pid))
 try:
  for _ in range(900):
   if server.poll() is not None: raise RuntimeError(f'server exited {server.returncode}')
   try:
    with urllib.request.urlopen(base+'/readyz',timeout=2) as res:
     if res.status==200:break
   except Exception:time.sleep(1)
  else:raise RuntimeError('readiness timeout')
  print(shape,'READY',time.monotonic()-start,flush=True)
  messages=[{'role':'user','content':prompt}]
  for label in ['cold','repeat','continuation']:
   if label=='continuation':messages += [{'role':'assistant','content':'Check cancellation, cache ownership, and accounting consistency.'},{'role':'user','content':'Give one concrete test for each risk.'}]
   body={'model':'zai/glm-5.3-flash','messages':messages,'max_tokens':256,'stream':True,'stream_options':{'include_usage':True}}
   payload=json.dumps(body).encode();(d/(label+'-request.json')).write_bytes(payload)
   before=time.monotonic()
   req=urllib.request.Request(base+'/v1/chat/completions',data=payload,headers={'Content-Type':'application/json'})
   with urllib.request.urlopen(req,timeout=600) as res:status=res.status;data=res.read()
   (d/(label+'-response.sse')).write_bytes(data)
   events=[json.loads(x[6:]) for x in data.decode().splitlines() if x.startswith('data: {')]
   usage=[e['usage'] for e in events if e.get('usage')]
   row={'shape':shape,'cell':label,'http':status,'wall_s':time.monotonic()-before,'done':b'data: [DONE]' in data,'usage':usage[-1] if usage else None}
   assert status==200 and row['done'] and usage and usage[-1]['completion_tokens']>0,row
   results.append(row);print(json.dumps(row),flush=True)
 except Exception as e:
  row={'shape':shape,'error':str(e)};results.append(row);print(json.dumps(row),flush=True)
 finally:
  if server.poll() is None:
   os.killpg(server.pid,signal.SIGTERM)
   try:server.wait(timeout=40)
   except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait()
  log.close()
  time.sleep(3)
(r/'pp1-results.json').write_text(json.dumps(results,indent=2)+'\n')
print('PP1_DONE',flush=True)
