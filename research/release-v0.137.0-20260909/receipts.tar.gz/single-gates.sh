#!/bin/bash
set -uo pipefail
source /root/tunebox/env.sh
R=/root/release-v0137-receipts
cd /root/wt-release-v0137
cell() { local n=$1; shift; date -u +%FT%TZ > "$R/$n.start"; /usr/bin/time -p "$@" > "$R/$n.log" 2>&1; echo $? > "$R/$n.exit"; date -u +%FT%TZ > "$R/$n.end"; tail -n 6 "$R/$n.log"; }
echo WAITING_GPU_LOCK
exec 9>/tmp/memra-gpu.lock
flock 9
cell cuda-allocation /root/tunebox/accept
cell host-generic /root/release-v0137-target/release/deps/memra_server-a42fd7a1b9cdd766 host_generic_arena_all_planes_and_handoff --ignored --nocapture --test-threads=1
cell gpu-overlay /root/release-v0137-target/release/deps/memra_engine-38136f5f2c1329a0 a_foreign_context_overlay_is_refused_not_dereferenced --ignored --nocapture --test-threads=1
cell gpu-qgate /root/release-v0137-target/release/deps/memra_engine-38136f5f2c1329a0 q_gate_split_refuses_a_separate_gate_wq_instead_of_reading_past_it --ignored --nocapture --test-threads=1
cell gpu-spill /root/release-v0137-target/release/deps/memra_engine-38136f5f2c1329a0 worker_positioned_reads_preserve_exact_bytes_and_reuse_after_short_read --ignored --nocapture --test-threads=1
ln -s /root/release-v0137-target target
cell release-battery bash tools/release-battery.sh
unlink target
echo DONE > "$R/single-gates.done"
