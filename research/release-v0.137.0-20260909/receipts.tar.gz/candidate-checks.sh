#!/bin/bash
set -uo pipefail
source /root/tunebox/env.sh
R=/root/release-v0137-receipts
cd /root/wt-release-v0137-candidate
export CARGO_TARGET_DIR=/root/release-v0137-target
cell() { local n=$1; shift; date -u +%FT%TZ > "$R/$n.start"; /usr/bin/time -p "$@" > "$R/$n.log" 2>&1; echo $? > "$R/$n.exit"; date -u +%FT%TZ > "$R/$n.end"; tail -n 6 "$R/$n.log"; }
cell candidate-fmt cargo fmt --all -- --check
cell candidate-flags bash tools/check-flags.sh
cell candidate-guard bash tools/release-guard.sh v0.137.0 Cargo.toml origin
cell candidate-diff git diff --check
cell candidate-boundary python3 tools/check-public-boundary.py check
while [ ! -f "$R/main-checks.done" ]; do sleep 5; done
cell candidate-lock cargo update --workspace --offline
cell candidate-clippy cargo clippy --release --all-targets -- -D warnings
echo DONE > "$R/candidate-checks.done"
