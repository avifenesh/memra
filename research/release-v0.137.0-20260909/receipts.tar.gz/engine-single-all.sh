#!/bin/bash
set -uo pipefail
source /root/tunebox/env.sh
R=/root/release-v0137-receipts
exec 9>/tmp/memra-gpu.lock
flock 9
date -u +%FT%TZ > "$R/engine-single-all.start"
/usr/bin/time -p /root/release-v0137-target/release/deps/memra_engine-38136f5f2c1329a0 --ignored --skip replay_rust_partial_submission_and_capture_cleanup --nocapture --test-threads=1 > "$R/engine-single-all.log" 2>&1
echo $? > "$R/engine-single-all.exit"
date -u +%FT%TZ > "$R/engine-single-all.end"
