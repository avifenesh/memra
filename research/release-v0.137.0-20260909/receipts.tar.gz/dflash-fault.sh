#!/bin/bash
R=/root/release-v0137-receipts
exec 9>/tmp/memra-gpu.lock
flock 9
date -u +%FT%TZ > "$R/dflash-fault.start"
/usr/bin/time -p env MEMRA_DSPARK_PREFIX_RESTORE=1 MEMRA_DSPARK_PARTIAL_RESTORE=1 /root/release-v0137-target/release/deps/memra_server-a42fd7a1b9cdd766 dflash_retained_gpu_plan_fault_matrix --ignored --nocapture --test-threads=1 > "$R/dflash-fault.log" 2>&1
echo $? > "$R/dflash-fault.exit"
date -u +%FT%TZ > "$R/dflash-fault.end"
