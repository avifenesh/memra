#!/bin/bash
set -uo pipefail
source /root/tunebox/env.sh
cd /root/wt-release-v0137
export CARGO_TARGET_DIR=/root/release-v0137-target
R=/root/release-v0137-receipts
cell() { local n=$1; shift; date -u +%FT%TZ > "$R/$n.start"; /usr/bin/time -p "$@" > "$R/$n.log" 2>&1; local rc=$?; echo $rc > "$R/$n.exit"; date -u +%FT%TZ > "$R/$n.end"; tail -n 6 "$R/$n.log"; }
git rev-parse HEAD > "$R/main.sha"
cell build cargo build --release --bins
if [ "$(cat "$R/build.exit")" != 0 ]; then exit 1; fi
sha256sum "$CARGO_TARGET_DIR/release/memra-server" > "$R/main-binary.sha256"
cell fmt cargo fmt --all -- --check
cell clippy cargo clippy --release --all-targets -- -D warnings
cell server-tests cargo test --release -p memra-server
cell engine-lib python3 tools/skip-census.py run --budget-var MEMRA_ENGINE_SKIP_BUDGET --min-passed 300 -- cargo test --release -p memra-engine --lib
cell flags bash tools/check-flags.sh
cell arch-census bash tools/arch-matrix-census.sh
cell stub-census python3 tools/stub-abi-census.py
cell workspace-census bash tools/workspace-publish-census.sh
cell release-guard-tests bash tools/test_release_guard.sh
cell battery-structure bash tools/test_release_battery_roster.sh
echo DONE > "$R/main-checks.done"
