Changes since v0.136.0:

## Fixes
- include validated DFlash restores in retained-prefix admission (#377)

## Other
- release: prepare v0.137.0 host tier and pinned arena
- GLM host cache: preserve model-owned planes through demotion and promotion (#325)
- test(dsv4): flush completed timing rows before Rust pass output
- test(dsv4): bracket first AR and bind helper object contents
- test(dsv4): use CUDA 13 graph dependency API
- test(dsv4): measure unprofiled paired graph launch boundaries
- test(dsv4): fix profile census iteration and create dump directory
- test(dsv4): profile default replay policy and explicit rollback
- dsv4: default cadence and dense exact-tree transport ON with rollback (#374)

Boards + reproduction artifacts: https://huggingface.co/Avifenesh/memra-bench · full experiment log in research/tune-data/
