#!/bin/bash
source /root/tunebox/env.sh
R=/root/release-v0137-receipts
while [ ! -f "$R/build.exit" ]; do sleep 5; done
[ "$(cat "$R/build.exit")" = 0 ] || exit 1
python3 "$R/pp1-cells.py" > "$R/pp1.log" 2>&1
echo $? > "$R/pp1.exit"
