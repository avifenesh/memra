#!/bin/bash
set -uo pipefail
source /root/tunebox/env.sh
R=/root/release-v0137-rebase
cd /root/wt-release-v0137
export CARGO_TARGET_DIR=/root/release-v0137-target CARGO_BUILD_JOBS=12
git rev-parse HEAD > "$R/source.sha"
echo "72ff9600aa2b0de77a5b27041a84448c2ce88c7b2055529fc23b3cd5bf518fd3  /data/models/ornith15-gguf/Ornith-1.5-35B-A3B-NVFP4-Q5K-mtp.gguf" > "$R/models.sha256"
echo "1facf36c2db359dcf9c2475cf8f85fe84a528d10aaaaff20f7c0db3d561e024a  /data/models/qwen38-27b-nvfp4-mtp/Qwen3.8-27B-NVFP4-Q5K-mtp.gguf" >> "$R/models.sha256"
sha256sum -c "$R/models.sha256" > "$R/model-verify.log" 2>&1 || exit 1
date -u +%FT%TZ > "$R/build.start"
/usr/bin/time -p cargo build --release --bins > "$R/build.log" 2>&1
rc=$?; echo "$rc" > "$R/build.exit"; date -u +%FT%TZ > "$R/build.end"
[ "$rc" = 0 ] || exit "$rc"
sha256sum "$CARGO_TARGET_DIR"/release/{memra-server,kernel-check,argmax-margin-probe,run-spec} > "$R/binaries.sha256"
cargo fmt --all -- --check > "$R/fmt.log" 2>&1; echo $? > "$R/fmt.exit"
bash tools/check-flags.sh > "$R/flags.log" 2>&1; echo $? > "$R/flags.exit"
git diff --check > "$R/diff.log" 2>&1; echo $? > "$R/diff.exit"
exec 9>/tmp/memra-gpu.lock
flock 9
ln -s "$CARGO_TARGET_DIR" target
date -u +%FT%TZ > "$R/battery.start"
/usr/bin/time -p bash tools/release-battery.sh > "$R/battery.log" 2>&1
rc=$?; echo "$rc" > "$R/battery.exit"; date -u +%FT%TZ > "$R/battery.end"
unlink target
