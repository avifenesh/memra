#!/bin/bash
set -euo pipefail
R=/root/release-v0137-clear
trap 'echo $? > "$R/staging.exit"' EXIT
mkdir -p /data/models/ornith15-gguf /data/models/qwen38-27b-nvfp4-mtp
date -u +%FT%TZ > "$R/staging.start"
curl --fail -L --retry 3 --limit-rate 100M -o /data/models/ornith15-gguf/Ornith-1.5-35B-A3B-NVFP4-Q5K-mtp.gguf.partial https://huggingface.co/tiyuvta/Ornith-1.5-35B-A3B-NVFP4-MTP-GGUF/resolve/d37694817123d1d151ea7fcab53b7e7c6e08a003/Ornith-1.5-35B-A3B-NVFP4-Q5K-mtp.gguf > "$R/ornith-download.log" 2>&1 &
p1=$!
curl --fail -L --retry 3 --limit-rate 100M -o /data/models/qwen38-27b-nvfp4-mtp/Qwen3.8-27B-NVFP4-Q5K-mtp.gguf.partial https://huggingface.co/tiyuvta/Qwen3.8-27B-NVFP4-MTP-GGUF/resolve/c303a1b0bfb7a1e2a9852c2315b5752e8eda3a24/Qwen3.8-27B-NVFP4-Q5K-mtp.gguf > "$R/qwen-download.log" 2>&1 &
p2=$!
wait "$p1"
wait "$p2"
echo "72ff9600aa2b0de77a5b27041a84448c2ce88c7b2055529fc23b3cd5bf518fd3  /data/models/ornith15-gguf/Ornith-1.5-35B-A3B-NVFP4-Q5K-mtp.gguf.partial" > "$R/models.sha256"
echo "1facf36c2db359dcf9c2475cf8f85fe84a528d10aaaaff20f7c0db3d561e024a  /data/models/qwen38-27b-nvfp4-mtp/Qwen3.8-27B-NVFP4-Q5K-mtp.gguf.partial" >> "$R/models.sha256"
sha256sum -c "$R/models.sha256" | tee "$R/staging-verify.log"
mv /data/models/ornith15-gguf/Ornith-1.5-35B-A3B-NVFP4-Q5K-mtp.gguf{.partial,}
mv /data/models/qwen38-27b-nvfp4-mtp/Qwen3.8-27B-NVFP4-Q5K-mtp.gguf{.partial,}
sed -i s/\.partial// "$R/models.sha256"
stat -c "%s %n" /data/models/ornith15-gguf/*.gguf /data/models/qwen38-27b-nvfp4-mtp/*.gguf > "$R/models.size"
mkdir -p /data/ai-ml/hf-models
ln -s /data/models/ornith15-gguf /data/ai-ml/hf-models/ornith15-gguf
ln -s /data/models/qwen38-27b-nvfp4-mtp /data/ai-ml/hf-models/qwen38-27b-nvfp4-mtp
date -u +%FT%TZ > "$R/staging.end"
