#!/bin/bash
set -euo pipefail
source /root/tunebox/env.sh
R=/root/release-v0137-clear
cd /root/wt-release-v0137
export CARGO_TARGET_DIR=/root/release-v0137-target
export CARGO_BUILD_JOBS=12
git rev-parse HEAD > "$R/source.sha"
date -u +%FT%TZ > "$R/build.start"
/usr/bin/time -p cargo build --release --bins > "$R/build.log" 2>&1
date -u +%FT%TZ > "$R/build.end"
sha256sum "$CARGO_TARGET_DIR"/release/{memra-server,kernel-check,argmax-margin-probe,run-spec} > "$R/binaries.sha256"
while [ ! -f "$R/staging.exit" ]; do sleep 5; done
[ "$(cat "$R/staging.exit")" = 0 ]
exec 9>/tmp/memra-gpu.lock
flock 9
ln -s "$CARGO_TARGET_DIR" target
date -u +%FT%TZ > "$R/battery.start"
set +e
/usr/bin/time -p bash tools/release-battery.sh > "$R/battery.log" 2>&1
rc=$?
set -e
echo "$rc" > "$R/battery.exit"
date -u +%FT%TZ > "$R/battery.end"
unlink target
